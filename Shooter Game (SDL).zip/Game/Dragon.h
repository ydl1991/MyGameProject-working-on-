#pragma once
#include "Enemy.h"
class Dragon :
	public Enemy
{

public:
	Dragon( float x, float y, EventSystem* pEventSystem, TextureSpriteSheet* pSpriteSheet, CollisionManager* pCManager);
	~Dragon();

	virtual void Tick(float deltaTime, GameRunningState* pGameRunningState) override;
	virtual void HandleBeginOverlap(CollisionComponent* pOtherCollider) override;
	virtual void Render(SDL_Renderer* pRenderer) override;

	// Getter
	float GetHealth() override;
private:
	virtual void PositionUpdate(float deltaTime) override;
	virtual void ChangeDirection() override;
};

