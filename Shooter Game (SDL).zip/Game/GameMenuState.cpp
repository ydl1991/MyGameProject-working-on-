#include "GameMenuState.h"
#include "SDL.h"
#include "SDL_ttf.h"
#include "SDL_render.h"
#include "AnimationComponent.h"
#include "MenuBackground.h"
#include "TextureSpriteSheet.h"
#include "EventSystem.h"
#include "ImageLoadingSystem.h"
#include "SimpleSDLGame.h"

GameMenuState::GameMenuState(SimpleSDLGame* pGameWorld)
	: m_messageRect{ 200, 200, 100, 200 }
	, m_animationOneRect{ 200.f, 400.f, 100.f, 120.f }
	, m_animationTwoRect{ 600.f, 400.f, 100.f, 120.f }
	, m_pTexture{ nullptr }
	, m_pAnimationOne{ nullptr }
	, m_pGameWorld{ pGameWorld }
{
	LoadBackground();
	LoadText();
	LoadAnimations();
}

GameMenuState::~GameMenuState()
{
	SDL_DestroyTexture(m_pTexture);
	m_pTexture = nullptr;

	delete m_pMenuBackground;
	m_pMenuBackground = nullptr;

	delete m_pAnimationOne;
	delete m_pAnimationTwo;
	m_pAnimationOne = nullptr;
	m_pAnimationTwo = nullptr;
}

void GameMenuState::EnterState()
{
	// human character
	m_pAnimationOne->AddAnimationSequence("Idle", 0, 0);
	m_pAnimationOne->AddAnimationSequence("Move", 0, 3);
	m_pAnimationOne->PlayAnimation("Idle");

	// warplan character
	m_pAnimationTwo->AddAnimationSequence("Idle", 0, 0);
	m_pAnimationTwo->AddAnimationSequence("Fly", 0, 1);
	m_pAnimationTwo->PlayAnimation("Idle");
}

void GameMenuState::Update(float deltaTime)
{
	m_pAnimationOne->Update(deltaTime);
	m_pAnimationTwo->Update(deltaTime);
}

void GameMenuState::ExitState()
{
}

bool GameMenuState::ProcessEvents()
{
	return m_pGameWorld->GetEventSystem()->ProcessMainMenuEvents(this);
}

void GameMenuState::RenderCurrentState(SDL_Renderer* pRenderer)
{
	// render background
	m_pMenuBackground->Render(pRenderer);
	// render text
	SDL_RenderCopy(pRenderer, m_pTexture, nullptr, &m_messageRect);
	// render character one
	m_pAnimationOne->Render(pRenderer,m_animationOneRect.x, m_animationOneRect.y, m_animationOneRect.w, m_animationOneRect.h, 0);
	// render character two
	m_pAnimationTwo->Render(pRenderer,m_animationTwoRect.x, m_animationTwoRect.y, m_animationTwoRect.w, m_animationTwoRect.h, 0);
	// present on screen
	SDL_RenderPresent(pRenderer);
}

void GameMenuState::LoadBackground()
{
	// load texture
	SDL_Texture* pBackground = nullptr;
	m_pGameWorld->GetImageLoadingSystem()->Load(m_pGameWorld->GetRenderer(), "Assets/mainMenu.jpg", pBackground);
	// create background
	m_pMenuBackground = new MenuBackground(pBackground);
}

void GameMenuState::LoadText()
{
	//this opens a font style and sets a size
	TTF_Font* Sans = TTF_OpenFont("Sans.ttf", 24);
	// this is the color in rgb format, maxing out all would give you the color white, and it will be your text's color
	SDL_Color Red = { 255, 0, 0, 255 };  
	// create surface
	SDL_Surface* surfaceMessage = TTF_RenderText_Solid(Sans, "Choose Your Character", Red);
	// create texture
	SDL_Texture* Message = SDL_CreateTextureFromSurface(GetWorld()->GetRenderer(), surfaceMessage);
	m_pTexture = Message;

	SDL_FreeSurface(surfaceMessage);
}

void GameMenuState::LoadAnimations()
{
	// texture variable
	TextureSpriteSheet* pPlayerOne = nullptr;
	TextureSpriteSheet* pPlayerTwo = nullptr;
	// get renderer
	SDL_Renderer* pRenderer = GetWorld()->GetRenderer();
	// load sprite sheet
	GetWorld()->GetImageLoadingSystem()->Load(pRenderer,"Assets/CharacterAnimation/animation.png", pPlayerOne);
	GetWorld()->GetImageLoadingSystem()->Load(pRenderer, "Assets/CharacterAnimation/warplane.png", pPlayerTwo);
	// create animation components
	m_pAnimationOne = new AnimationComponent(pPlayerOne, 6.f, 60, 84, 4);
	m_pAnimationTwo = new AnimationComponent(pPlayerTwo, 6.f, 100, 117, 2);
}