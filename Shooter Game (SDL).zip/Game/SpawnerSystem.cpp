#include "SpawnerSystem.h"
#include "TextureSpriteSheet.h"
#include "GameRunningState.h"
#include "AnimationComponent.h"
#include "CollisionComponent.h"
#include "ImageLoadingSystem.h"
#include "WorldBackground.h"
#include "Player.h"
#include "DamageZone.h"
#include "HealingZone.h"
#include "Dragon.h"
#include "Tree.h"
#include "Zombie.h"
#include "Projectile.h"
#include "Wall.h"
#include "SimpleSDLGame.h"
#include "EventSystem.h"
#include <time.h>
#include <iostream>
#include <SDL.h>

SpawnerSystem::SpawnerSystem(GameRunningState* pGameRunningState, float enemyTimer, float projectileTimer, float wallTimer, float zoneTimer)
	: m_pGameRunningState(pGameRunningState)
	, m_enemySpawnTimer(enemyTimer)
	, m_projectileSpawnTimer(projectileTimer)
	, m_wallSpawnTimer(wallTimer)
	, m_zoneSpawnTimer(zoneTimer)
{
	//
}

SpawnerSystem::~SpawnerSystem()
{
	//
}

//////////////////////////////////////////////////////////////////////////
// Spawn function one
// Spawns object that do not require to pass in a event system pointer
// Parameters:
//	coordinate x, coordinate y, object spritesheet
//////////////////////////////////////////////////////////////////////////
template<class SpawnType>
void SpawnerSystem::SpawnObject(float x, float y, TextureSpriteSheet* pSpriteSheet)
{
	// create object
	SpawnType* pTemp = new SpawnType(x, y, pSpriteSheet, m_pGameRunningState->GetWorld()->GetCollisionManager());
	pTemp->Init();

	// emplace back to object list
	m_pGameRunningState->AddObject(pTemp);

	// set temporary pointers to nullptr
	pTemp = nullptr;
}

//////////////////////////////////////////////////////////////////////////
// Spawn function two
// Spawns object that do require to pass in a event system pointer
// Parameters:
//	coordinate x, coordinate y, event system pointer, object spritesheet
//////////////////////////////////////////////////////////////////////////
template<class SpawnType>
void SpawnerSystem::SpawnObject(float x, float y, EventSystem* pEventSystem, TextureSpriteSheet* pSpriteSheet)
{
	// spawn object
	SpawnType* pTemp = new SpawnType(x, y, pEventSystem, pSpriteSheet, m_pGameRunningState->GetWorld()->GetCollisionManager());
	pTemp->Init();

	// emplace back to object list
	m_pGameRunningState->AddObject(pTemp);

	// set temporary pointers to nullptr
	pTemp = nullptr;
}

void SpawnerSystem::Update(float deltaTime)
{
	srand((unsigned int)time(nullptr));

	// calculate time to spawn
	m_enemySpawnTimer -= deltaTime;
	m_projectileSpawnTimer -= deltaTime;
	m_wallSpawnTimer -= deltaTime;
	m_zoneSpawnTimer -= deltaTime;
	
	// check spawn enemy
	CheckSpawnEnemy();

	// check spawn projectile
	CheckSpawnProjectile();

	// check spawn walls
	CheckSpawnWall();

	// check spawn zones
	CheckSpawnZone();
}

void SpawnerSystem::CheckSpawnEnemy()
{
	if (m_enemySpawnTimer <= 0 && m_pGameRunningState->GetBackground()->GetCameraDimention().y > 100.f)
	{
		const int worldWidth = m_pGameRunningState->GetWorld()->GetWidth();
		SDL_Renderer* pRenderer = m_pGameRunningState->GetWorld()->GetRenderer();
		EventSystem* pESystem = m_pGameRunningState->GetWorld()->GetEventSystem();

		// store enemy filename
		const char* enemyImages[3] = { "Assets/EnemyAnimation/Dragon/dragon.png"
										, "Assets/EnemyAnimation/Tree/tree.png"
										, "Assets/EnemyAnimation/Zombie/zombie.png" };

		// randomly selete spawn enemy type
		int type = rand() % 3;
		// set random X coordinate
		int xCoordinates = 10 + (rand() % (worldWidth - 100));
		// create animation sprite shee and animation component
		TextureSpriteSheet* pSpriteSheet = nullptr;
		m_pGameRunningState->GetWorld()->GetImageLoadingSystem()->Load(pRenderer, enemyImages[type], pSpriteSheet);

		// Spawn enemy
		switch (type)
		{
		case 0:
		{
			SpawnObject<Dragon>(static_cast<float>(xCoordinates), -100.f, pESystem, pSpriteSheet);
			break;
		}
		case 1:
		{
			SpawnObject<Tree>(static_cast<float>(xCoordinates), -100.f, pESystem, pSpriteSheet);
			break;
		}
		case 2:
		{
			SpawnObject<Zombie>(static_cast<float>(xCoordinates), -100.f, pESystem, pSpriteSheet);
			break;
		}
		default:
			break;
		}

		// reset timer
		SetEnemySpawnTimer((float)(1 + rand() % 3));
	}
}

void SpawnerSystem::CheckSpawnProjectile()
{
	Player* pPlayer = m_pGameRunningState->GetPlayer();

	if (m_projectileSpawnTimer <= 0 && pPlayer->GetFireStatus())
	{
		SDL_Renderer* pRenderer = m_pGameRunningState->GetWorld()->GetRenderer();


		TextureSpriteSheet* pSpriteSheet = nullptr;
		m_pGameRunningState->GetWorld()->GetImageLoadingSystem()->Load(pRenderer, "Assets/projectile.jpg", pSpriteSheet);
		
		// Spawn Projectile
		SpawnObject<Projectile>(pPlayer->GetX() + 25, pPlayer->GetY() - 21, pSpriteSheet);
	
		// reset timer
		SetProjectileSpawnTimer((float)(1/pPlayer->GetFireRate()));
	}
}

void SpawnerSystem::CheckSpawnWall()
{
	if (m_wallSpawnTimer <= 0 && (m_pGameRunningState->GetBackground()->GetCameraDimention().y > 1000.f))
	{
		const int worldWidth = m_pGameRunningState->GetWorld()->GetWidth();
		SDL_Renderer* pRenderer = m_pGameRunningState->GetWorld()->GetRenderer();
		
		// get sprite sheet
		TextureSpriteSheet* pSpriteSheet = nullptr;
		m_pGameRunningState->GetWorld()->GetImageLoadingSystem()->Load(pRenderer, "Assets/wall.png", pSpriteSheet);
		
		// get y coordinate
		int y = -56;

		// set random x
		int x = rand() % (worldWidth - 200);

		// create wall and store in object list
		SpawnObject<Wall>(static_cast<float>(x), static_cast<float>(y), pSpriteSheet);

		// reset timer
		SetWallSpawnTimer(5.f);
	}
}

void SpawnerSystem::CheckSpawnZone()
{
	if (m_zoneSpawnTimer <= 0 && m_pGameRunningState->GetBackground()->GetCameraDimention().y > 600.f)
	{
		const int worldWidth = m_pGameRunningState->GetWorld()->GetWidth();
		SDL_Renderer* pRenderer = m_pGameRunningState->GetWorld()->GetRenderer();

		// store zone filename
		const char* zoneImages[2] = { "Assets/ZoneAnimation/damageZone.png", "Assets/ZoneAnimation/healingZone.png" };

		int zoneType = rand() % 2;

		// get sprite sheet
		TextureSpriteSheet* pSpriteSheet = nullptr;
		m_pGameRunningState->GetWorld()->GetImageLoadingSystem()->Load(pRenderer, zoneImages[zoneType], pSpriteSheet);

		// Spawn zone
		switch (zoneType)
		{
		case 0:
		{
			// get y coordinate
			int y = -400;
			// set random X coordinate
			int xCoordinates = 10 + (rand() % (worldWidth - 410));
			// call spawn function
			SpawnObject<DamageZone>((float)(xCoordinates), (float)y, pSpriteSheet);
			break;
		}
		case 1:
		{
			// get y coordinate
			int y = -300;
			// set random X coordinate
			int xCoordinates = 10 + (rand() % (worldWidth - 310));
			// call spawn function
			SpawnObject<HealingZone>((float)(xCoordinates), (float)y, pSpriteSheet);
			break;
		}
		default:
			break;
		}

		// reset timer
		SetZoneSpawnTimer(7.f);
	}
}
