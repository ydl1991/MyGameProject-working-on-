#pragma once
class ObjectBase;

enum EventType
{
	kMoveDown = 0,
	kMoveUp,
	kMoveLeft,
	kMoveRight,
	kAttact,
	kGetHurt,
	kHeal
};

class Event
{
	ObjectBase* m_pEventOwner;
	EventType m_type;
public:
	Event(ObjectBase* pEventOwner, EventType type);
	~Event();

	ObjectBase* GetEventOwner() { return m_pEventOwner; };
	EventType GetEventType() { return m_type; };
};

