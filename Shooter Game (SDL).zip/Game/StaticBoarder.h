#pragma once
#include "Wall.h"
class StaticBoarder :
	public Wall
{
public:
	StaticBoarder(float x, float y);
	~StaticBoarder() {};

	void Render(SDL_Renderer* pRenderer) override;
	void Tick(float deltaTime, GameRunningState* pGameRunningState) override;
	virtual void HandleBeginOverlap(CollisionComponent* pOtherCollider) override;
};

