#include "ObjectBase.h"
#include "SDL.h"
#include "SDL_image.h"
#include "EventSystem.h"
#include <iostream>

ObjectBase::ObjectBase()
	: m_coordinates{0,0}
	, m_dimentions{0,0}
	, m_direction{0,0}
	, m_health{0}
	, m_speed{0}
	, m_pCollisionComponent{nullptr}
	, m_pAnimationComponent{nullptr}
	, m_isValid{true}
	, m_pName{""}
	, m_collisionBox{}
{
}

ObjectBase::~ObjectBase()
{
	// release memory for animation component
	delete m_pAnimationComponent;
	m_pAnimationComponent = nullptr;
	// release memory for collision component
	delete m_pCollisionComponent;
	m_pCollisionComponent = nullptr;
}

// call to check health
void ObjectBase::ChangeHealth(float delta)
{
	// change health
	m_health += delta;
	// check validation
	if (m_health <= 0)
	{
		Invalid();
	}
}

void ObjectBase::Init()
{
	//
}

void ObjectBase::Tick(float deltaTime, GameRunningState* pGameRunningState)
{
	//
}

void ObjectBase::HandleBeginOverlap(CollisionComponent* pOtherCollider)
{
	//
}

void ObjectBase::OverlapUpdate(CollisionComponent* pOtherCollider)
{
	//
}

void ObjectBase::HandleEndOverlap(CollisionComponent* pOtherCollider)
{
	//
}

void ObjectBase::Render(SDL_Renderer* pRenderer)
{
	//
}
