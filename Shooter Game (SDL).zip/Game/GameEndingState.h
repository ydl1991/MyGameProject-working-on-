#pragma once
#include "GameState.h"
#include "SDL_rect.h"

class SimpleSDLGame;
class EndingBackground;
class AnimationComponent;

class GameEndingState : public GameState
{
	// Game World reference
	SimpleSDLGame* m_pGameWorld;				// a reference of the Game world
	// background 
	EndingBackground* m_pEndingBackground;
	// exit button rect
	SDL_Texture* m_pButton;
	SDL_Rect m_exitButtonRect;

public:
	GameEndingState(SimpleSDLGame* pGameWorld);
	~GameEndingState();

	// Game State status
	virtual void EnterState() override;
	virtual void Update(float deltaTime) override;
	virtual void ExitState() override;
	// Function Overload, Event Processing
	virtual bool ProcessEvents() override;
	// Render
	virtual void RenderCurrentState(SDL_Renderer* pRenderer) override;

	// Getters
	SimpleSDLGame* GetWorld() const { return m_pGameWorld; };
	SDL_Rect GetAnimationButtonRect() { return m_exitButtonRect; };

private:
	void LoadBackground();
	void LoadTexture();
};

