#pragma once
#include "Event.h"
#include <queue>

class Player;
class Event;
class ObjectBase;
class SimpleSDLGame;
class GameMenuState;
class GameEndingState;
struct SDL_WindowEvent;
struct SDL_KeyboardEvent;
struct SDL_MouseButtonEvent;
struct SDL_MouseMotionEvent;

/***********************************************************/
// EventSystem that processes Normal event and SDL events and 
// take down info that affects the world
/***********************************************************/
class EventSystem
{
	/*******************************************************/
	//					Normal Event Related
	/*******************************************************/
	std::queue<Event*> m_eventQueue;

	/*******************************************************/
	//					SDL Event Related
	/*******************************************************/
	// Quit Condition
	bool m_pressCtrl;
	bool m_pressQ;
	// Mouse Event Variable
	bool m_mouseClick;
	bool m_mouseHolding;
	int m_mouseX;
	int m_mouseY;

public:
	// Constructor and destructor
	EventSystem();
	~EventSystem();

	/*******************************************************/
	//					Main Menu Event Related
	/*******************************************************/
	bool ProcessMainMenuEvents(GameMenuState* pGameMenu);

	/*******************************************************/
	//					Game Runing Event Related
	/*******************************************************/
	void AddEvent(ObjectBase* pEventOwner, EventType type);
	// process other object events
	void ProcessEvents();
	// process player events
	bool ProcessEvents(Player* eventListener);

	/*******************************************************/
	//					Post Game Event Related
	/*******************************************************/
	bool ProcessPostGameEvents(GameEndingState* pGameEnd);

	/* Mouse Event State Setting */
	bool GetClickState() { return m_mouseClick; };
	bool GetHoldingState() { return m_mouseHolding; };
	int GetMouseX() { return m_mouseX; };
	int GetMouseY() { return m_mouseY; };
	void SetMouseX(int newX) { m_mouseX = newX; };
	void SetMouseY(int newY) { m_mouseY = newY; };
	void ChangeMouseClickState() { (m_mouseClick) ? m_mouseClick = false : m_mouseClick = true; };
	void ChangeMouseHoldingState() { m_mouseHolding ? m_mouseHolding = false : m_mouseHolding = true; };

private:
	/*******************************************************/
	//					Pre Game Event Related
	/*******************************************************/
	void ProcessMenuClickEvent(GameMenuState* pGameMenu, SDL_MouseButtonEvent* pData);
	void ProcessMenuMouseMotionEvent(GameMenuState* pGameMenu, SDL_MouseMotionEvent* pData);

	/*******************************************************/
	//					In Game Event Related
	/*******************************************************/
	// objects action event
	void ProcessObjectMoveUp(ObjectBase* pEventOwner);
	void ProcessObjectMoveDown(ObjectBase* pEventOwner);
	void ProcessObjectMoveLeft(ObjectBase* pEventOwner);
	void ProcessObjectMoveRight(ObjectBase* pEventOwner);
	void ProcessObjectAttack(ObjectBase* pEventOwner);
	void ProcessObjectGetHurt(ObjectBase* pEventOwner);
	void ProcessObjectHeal(ObjectBase* pEventOwner);
	// player action event
	void ProcessPressKeyBoardEvent(Player* eventListener, SDL_KeyboardEvent* pData);
	void ProcessReleaseKeyBoardEvent(Player* eventListener, SDL_KeyboardEvent* pData);
	void ProcessMouseClickEvent(Player* eventListener, SDL_MouseButtonEvent* pData);
	void ProcessMouseReleaseEvent(Player* eventListener, SDL_MouseButtonEvent* pData);
	void ProcessMouseMotionEvent(Player* eventListener, SDL_MouseMotionEvent* pData);
	void ProcessWindowEvent(SDL_WindowEvent* pData);

	/*******************************************************/
	//					Post Game Event Related
	/*******************************************************/
	void ProcessEndClickEvent(GameEndingState* pGameMenu, SDL_MouseButtonEvent* pData);
};

