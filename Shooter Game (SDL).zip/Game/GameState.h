#pragma once
#include <SDL.h>

class GameState
{
public:
	// Game State status
	virtual void EnterState() = 0;
	virtual void Update(float deltaTime) = 0;
	virtual void ExitState() = 0;
	// Function Overload, Event Processing
	virtual bool ProcessEvents() = 0;
	// Render
	virtual void RenderCurrentState(SDL_Renderer* pRenderer) = 0;
};

