#pragma once
struct SDL_Renderer;
struct SDL_Window;
class EventSystem;
class ImageLoadingSystem;
class CollisionManager;
class StateMachine;

/***********************************************************/
// SimpleSDLGame is the Game World class that contains 
// game rules and perform Game State Update
/***********************************************************/
class SimpleSDLGame
{
private:
	/***************************************/
	// Private member variables declarition
	/***************************************/
	// Window Length
	const int m_kWindowWidth = 800;				// window size variable 
	const int m_kWindowHeight = 600;			// window size variable

	//// Background
	//SDL_FRect m_camaraOnBackground;

	// Systematic Variable
	SDL_Window* m_pWindow;						// window variable
	SDL_Renderer* m_pRenderer;					// renderer variable
	ImageLoadingSystem* m_pImageSystem;			// imageSystem that takes in file name and retrieves texture
	EventSystem* m_pEventSystem;				// event system that processes SDL keyboard, mouse and window event
	CollisionManager* m_pCollisionManager;		// a system that detects and handles object collision
	StateMachine* m_pStateMachine;				// a system that handles different game states

public:
	/***************************************/
	// Public member function declarition
	/***************************************/
	// con and destructor
	SimpleSDLGame();
	~SimpleSDLGame();

	void Init();								// initialization function
	void ShutDown();							// kill everything after finish output
	void Update();								// Game Update

	// Getter
	EventSystem* GetEventSystem() const { return m_pEventSystem; };
	SDL_Renderer* GetRenderer() const { return m_pRenderer; };
	CollisionManager* GetCollisionManager() const { return m_pCollisionManager; };
	ImageLoadingSystem* GetImageLoadingSystem() const { return m_pImageSystem; };
	StateMachine* GetStateMachine() const { return m_pStateMachine; };
	const int GetWidth() { return m_kWindowWidth; };
	const int GetHeight() { return m_kWindowHeight; };
};

