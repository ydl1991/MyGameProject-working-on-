#include "EventSystem.h"
#include "SimpleSDLGame.h"
#include "AnimationComponent.h"
#include "GameRunningState.h"
#include "StateMachine.h"
#include "GameState.h"
#include "Player.h"
#include "GameMenuState.h"
#include "GameEndingState.h"
#include <iostream>
#include <SDL.h>

extern SimpleSDLGame g_pGame;

EventSystem::EventSystem()
	: m_pressCtrl{ false }
	, m_pressQ{ false }
	, m_mouseClick{ false }
	, m_mouseHolding{ false }
	, m_mouseX{ 0 }
	, m_mouseY{ 0 }
{
}

EventSystem::~EventSystem()
{
	while (!m_eventQueue.empty())
	{
		delete m_eventQueue.front();
		m_eventQueue.pop();
	}
}

// process main menu events
bool EventSystem::ProcessMainMenuEvents(GameMenuState* pGameMenu)
{
	// create event variable
	SDL_Event evt;

	while (SDL_PollEvent(&evt))
	{
		switch (evt.type)
		{
			// mouse events
		case SDL_MOUSEBUTTONDOWN:
			ProcessMenuClickEvent(pGameMenu, &evt.button);
			break;
		case SDL_MOUSEMOTION:
			ProcessMenuMouseMotionEvent(pGameMenu, &evt.motion);
			break;
			// window events
		case SDL_WINDOWEVENT:
			ProcessWindowEvent(&evt.window);
			break;
		}

		// if quit
		if (m_pressCtrl && m_pressQ)
		{
			return true;
		}
	}

	return (m_pressCtrl && m_pressQ);
}

// call to add event to the event queue
void EventSystem::AddEvent(ObjectBase* pEventOwner, EventType type)
{
	if (pEventOwner)
	{
		m_eventQueue.emplace(new Event(pEventOwner, type));
	}
}

// call to process event 
void EventSystem::ProcessEvents()
{
	// if queue not empty
	while(!m_eventQueue.empty())
	{
		Event* pEvent = m_eventQueue.front();
		ObjectBase* pEventOwner = pEvent->GetEventOwner();

		// if event and owner are valid
		if (pEvent && pEventOwner->IsValid())
		{
			// process events
			switch (pEvent->GetEventType())
			{
			case EventType::kMoveUp:
				ProcessObjectMoveUp(pEventOwner);
				break;
			case EventType::kMoveDown:
				ProcessObjectMoveDown(pEventOwner);
				break;
			case EventType::kMoveLeft:
				ProcessObjectMoveLeft(pEventOwner);
				break;
			case EventType::kMoveRight:
				ProcessObjectMoveRight(pEventOwner);
				break;
			case EventType::kAttact:
				ProcessObjectAttack(pEventOwner);
				break;
			case EventType::kGetHurt:
				ProcessObjectGetHurt(pEventOwner);
				break;
			case EventType::kHeal:
				ProcessObjectHeal(pEventOwner);
				break;
			default:
				break;
			}
		}

		// remove front node
		delete pEvent;
		m_eventQueue.pop();
	}
}

// call to process events including keyboard event, mouse motion and click, and window event
bool EventSystem::ProcessEvents(Player* eventListener)
{
	// create event variable
	SDL_Event evt;

	while (SDL_PollEvent(&evt))
	{
		switch (evt.type)
		{
			// keyboard events
		case SDL_KEYDOWN:
			ProcessPressKeyBoardEvent(eventListener, &evt.key);
			break;
		case SDL_KEYUP:
			ProcessReleaseKeyBoardEvent(eventListener, &evt.key);
			break;
			// mouse events
		case SDL_MOUSEBUTTONDOWN:
			ProcessMouseClickEvent(eventListener, &evt.button);
			break;
		case SDL_MOUSEBUTTONUP:
			ProcessMouseReleaseEvent(eventListener, &evt.button);
			break;
		case SDL_MOUSEMOTION:
			ProcessMouseMotionEvent(eventListener, &evt.motion);
			break;
			// window events
		case SDL_WINDOWEVENT:
			ProcessWindowEvent(&evt.window);
			break;
		}

		if (m_pressCtrl && m_pressQ)
		{
			return true;
		}
	}
	return (m_pressCtrl && m_pressQ);
}

bool EventSystem::ProcessPostGameEvents(GameEndingState* pGameEnd)
{
	// create event variable
	SDL_Event evt;

	while (SDL_PollEvent(&evt))
	{
		switch (evt.type)
		{
			// mouse events
		case SDL_MOUSEBUTTONDOWN:
			ProcessEndClickEvent(pGameEnd, &evt.button);
			break;
			// window events
		case SDL_WINDOWEVENT:
			ProcessWindowEvent(&evt.window);
			break;
		}

		// if quit
		if (m_pressCtrl && m_pressQ)
		{
			return true;
		}
	}

	return (m_pressCtrl && m_pressQ);
}


// call to execute keyboard Press events
void EventSystem::ProcessPressKeyBoardEvent(Player* eventListener, SDL_KeyboardEvent* pData)
{
	//Log key name
	const char* keyName = SDL_GetKeyName(pData->keysym.sym);
	if (pData->repeat)
		return;

	switch (pData->keysym.scancode)
	{
		// movement input
	case SDL_SCANCODE_W:
		std::cout << "Successfully Pressed " << keyName << std::endl;
		eventListener->SetYDirection(-1.f);
		break;
	case SDL_SCANCODE_S:
		std::cout << "Successfully Pressed " << keyName << std::endl;
		eventListener->SetYDirection(1.f);
		break;
	case SDL_SCANCODE_A:
		std::cout << "Successfully Pressed " << keyName << std::endl;
		eventListener->SetXDirection(-1.f);
		break;
	case SDL_SCANCODE_D:
		std::cout << "Successfully Pressed " << keyName << std::endl;
		eventListener->SetXDirection(1.f);
		break;
	case SDL_SCANCODE_UP:
		// fire projectile
		std::cout << "Fireeeeeeeee!!!! " << std::endl;
		eventListener->FireSwitch();
		eventListener->GetCoordinateVector().m_rotation = 0;
		break;
	case SDL_SCANCODE_SPACE:
		// Sprint to boost speed to 1.5 multiplier
		eventListener->ChangePlayerSpeed();
		eventListener->GetAnimationComponent()->ChangeFrameRate(20.f);
		std::cout << "Successfully Pressed " << keyName << std::endl;
		std::cout << "Booster Activated!" << std::endl;
		break;
		// case to quit the game
	case SDL_SCANCODE_LCTRL:
		std::cout << "Successfully Pressed " << keyName << std::endl;
		m_pressCtrl = true;
		break;
	case SDL_SCANCODE_Q:
		std::cout << "Successfully Pressed " << keyName << std::endl;
		m_pressQ = true;
		break;
	default:
		break;
	}
}

// call to execute keyboard release events
void EventSystem::ProcessReleaseKeyBoardEvent(Player* eventListener, SDL_KeyboardEvent* pData)
{
	if (pData->repeat)
		return;

	switch (pData->keysym.scancode)
	{
		// stop moving
	case SDL_SCANCODE_W:
		eventListener->SetYDirection(0.f);
		break;
	case SDL_SCANCODE_S:
		eventListener->SetYDirection(0.f);
		break;
	case SDL_SCANCODE_A:
		eventListener->SetXDirection(0.f);
		break;
	case SDL_SCANCODE_D:
		eventListener->SetXDirection(0.f);
		break;
	case SDL_SCANCODE_UP:
		eventListener->FireSwitch();
		break;
	case SDL_SCANCODE_SPACE:
		// deactivate booster, multiplier back to origin
		eventListener->ChangePlayerSpeed();
		eventListener->GetAnimationComponent()->ChangeFrameRate(6.f);
		break;
		// reset quit conditions
	case SDL_SCANCODE_LCTRL:
		m_pressCtrl = false;
		break;
	case SDL_SCANCODE_Q:
		m_pressQ = false;
		break;
	default:
		break;
	}
}

// call to execute mouse clikc events
void EventSystem::ProcessMouseClickEvent(Player* eventListener, SDL_MouseButtonEvent* pData)
{
	switch (pData->button)
	{
		// motion moving condition
	case SDL_BUTTON_LEFT:
		if (!m_mouseClick)
			ChangeMouseClickState();

		if (!eventListener->GetMotionState())
			eventListener->ChangeMotionState();

		if (!m_mouseHolding)
			ChangeMouseHoldingState();

		SetMouseX(pData->x);
		SetMouseY(pData->y);

		break;
	default:
		break;
	}
}

// call to execute mouse release event
void EventSystem::ProcessMouseReleaseEvent(Player* eventListener, SDL_MouseButtonEvent* pData)
{
	switch (pData->button)
	{
		// reset motion moving, stop player move
	case SDL_BUTTON_LEFT:
		if (m_mouseClick)
			ChangeMouseClickState();

		if(m_mouseHolding)
			ChangeMouseHoldingState();

		break;
	default:
		break;
	}
}

// call to execute mouse motion events
void EventSystem::ProcessMouseMotionEvent(Player* eventListener, SDL_MouseMotionEvent* pData)
{
	// if not released, reactivate moving
	if (m_mouseClick)
	{
		if(!eventListener->GetMotionState())
			eventListener->ChangeMotionState();
	}

	// if still holding the click, record mouse coordinates for moving action
	if (eventListener->GetMotionState() && m_mouseHolding)
	{
		SetMouseX(pData->x);
		SetMouseY(pData->y);
	}
}

// call to execute window events
void EventSystem::ProcessWindowEvent(SDL_WindowEvent* pData)
{
	switch (pData->event)
	{
		// click the "x" on upper-right of the window to close window
	case SDL_WINDOWEVENT_CLOSE:
		std::cout << "Window Closing!" << std::endl;
		m_pressCtrl = true;
		m_pressQ = true;
		break;
	default:
		break;
	}
}

void EventSystem::ProcessEndClickEvent(GameEndingState* pGameMenu, SDL_MouseButtonEvent* pData)
{

}

void EventSystem::ProcessMenuClickEvent(GameMenuState* pGameMenu, SDL_MouseButtonEvent* pData)
{
	SDL_FRect rectOne = pGameMenu->GetAnimationOneRect();
	SDL_FRect rectTwo = pGameMenu->GetAnimationTwoRect();

	switch (pData->button)
	{
		// motion moving condition
	case SDL_BUTTON_LEFT:
	{
		if (pData->x > rectOne.x && pData->x < rectOne.x + rectOne.w && pData->y > rectOne.y && pData->y < rectOne.y + rectOne.h)
		{
			SimpleSDLGame* pWorld = pGameMenu->GetWorld();
			GameState* pState = new GameRunningState(pWorld, 0);
			pWorld->GetStateMachine()->SetCurrentState(pState);
			pState = nullptr;
		}

		if (pData->x > rectTwo.x && pData->x < rectTwo.x + rectTwo.w && pData->y > rectTwo.y && pData->y < rectTwo.y + rectTwo.h)
		{
			SimpleSDLGame* pWorld = pGameMenu->GetWorld();
			GameState* pState = new GameRunningState(pWorld, 1);
			pWorld->GetStateMachine()->SetCurrentState(pState);
			pState = nullptr;
		}

		break;
	}
	default:
		break;
	}
}

void EventSystem::ProcessMenuMouseMotionEvent(GameMenuState* pGameMenu, SDL_MouseMotionEvent* pData)
{
	SDL_FRect rectOne = pGameMenu->GetAnimationOneRect();
	SDL_FRect rectTwo = pGameMenu->GetAnimationTwoRect();

	if (pData->x > rectOne.x && pData->x < rectOne.x + rectOne.w && pData->y > rectOne.y && pData->y < rectOne.y + rectOne.h)
	{
		pGameMenu->GetAnimationOne()->PlayAnimation("Move");
	}
	else
		pGameMenu->GetAnimationOne()->PlayAnimation("Idle");

	if (pData->x > rectTwo.x && pData->x < rectTwo.x + rectTwo.w && pData->y > rectTwo.y && pData->y < rectTwo.y + rectTwo.h)
	{
		pGameMenu->GetAnimationTwo()->PlayAnimation("Fly");
	}
	else
		pGameMenu->GetAnimationTwo()->PlayAnimation("Idle");
}

void EventSystem::ProcessObjectMoveUp(ObjectBase* pEventOwner)
{
	// 
	pEventOwner->SetXDirection(0);
	pEventOwner->SetYDirection(-1);
}

void EventSystem::ProcessObjectMoveDown(ObjectBase* pEventOwner)
{
	pEventOwner->SetXDirection(0);
	pEventOwner->SetYDirection(1);
}

void EventSystem::ProcessObjectMoveLeft(ObjectBase* pEventOwner)
{
	pEventOwner->SetXDirection(-1);
	pEventOwner->SetYDirection(0);
}

void EventSystem::ProcessObjectMoveRight(ObjectBase* pEventOwner)
{
	pEventOwner->SetXDirection(1);
	pEventOwner->SetYDirection(0);
}

void EventSystem::ProcessObjectAttack(ObjectBase* pEventOwner)
{
	//
}

void EventSystem::ProcessObjectGetHurt(ObjectBase* pEventOwner)
{
	pEventOwner->ChangeHealth(-50);
}

void EventSystem::ProcessObjectHeal(ObjectBase* pEventOwner)
{
	pEventOwner->ChangeHealth(10);
}
