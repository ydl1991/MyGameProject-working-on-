#include "Zombie.h"
#include "SimpleSDLGame.h"
#include "GameRunningState.h"
#include "WorldBackground.h"
#include "EventSystem.h"
#include "Projectile.h"
#include "Player.h"
#include "TextureSpriteSheet.h"
#include "CollisionManager.h"
Zombie::Zombie( float x, float y, EventSystem* pEventSystem, TextureSpriteSheet* pSpriteSheet, CollisionManager* pCManager)
{
	// set Enemy character Rect and dimention
	m_coordinates = { x,y };
	m_dimentions = { 100, 100 };
	m_speed = 70.f;
	m_health = 100.f;
	m_pEventSystem = pEventSystem;
	AddAnimationComponent(new AnimationComponent(pSpriteSheet, 6.f, 100, pSpriteSheet->m_h, 6));
	m_collisionBox = { (int)x, (int)y, (int)m_dimentions.m_x, (int)m_dimentions.m_y };
	AddCollisionComponent(new CollisionComponent(this, m_collisionBox, pCManager, CollisionState::kCanBeOverlap));
}

Zombie::~Zombie()
{
}

void Zombie::Tick(float deltaTime, GameRunningState* pGameRunningState)
{
	// check death
	if (!m_isValid)
	{
		return;
	}

	// update position
	if (pGameRunningState->GetBackground()->GetCameraDimention().y > 0)
		m_coordinates.m_y += 0.015f;

	// check for motion status
	if (m_isResting)
	{
		m_speed = 0;
		m_restTimer -= deltaTime;
		if (m_restTimer <= 0)
		{
			m_speed = 200.f;
			ResumeMoving();
			m_restTimer = 0.5f;
		}
	}

	// update new postion
	PositionUpdate(deltaTime);

	// check if enemy at boundary
	if (GetY() >= pGameRunningState->GetWorld()->GetHeight())
	{
		// if yes, set invalid
		this->Invalid();
		return;
	}

	// for things need to be checked every frame
	m_pAnimationComponent->Update(deltaTime);

	// update collision component
	m_pCollisionComponent->SetPosition(m_coordinates);
}

void Zombie::HandleBeginOverlap(CollisionComponent* pOtherCollider)
{
	// for things happen after collision
	// overlap with projectile
	if (pOtherCollider)
	{
		ObjectBase* pOther = pOtherCollider->GetOwner();
		if (pOther)
		{
			Projectile* pProjectile = dynamic_cast<Projectile*>(pOther);
			if (pProjectile)
			{
				m_pEventSystem->AddEvent(this, EventType::kGetHurt);
				GetHit();
				return;
			}

			// overlap with player
			Player* pPlayer = dynamic_cast<Player*>(pOther);
			if (pPlayer)
			{
				Invalid();
				return;
			}
		}
	}
}

void Zombie::Render(SDL_Renderer* pRenderer)
{
	m_pAnimationComponent->Render(pRenderer, GetX(), GetY(), GetWidth(), GetHeight(), 0.f);
}

float Zombie::GetHealth()
{
	if (m_health > 200.f)
		m_health = 200.f;
	return m_health;
}

void Zombie::PositionUpdate(float deltaTime)
{
	// calculate change in position
	float deltaX = GetXDirection() * GetSpeed() * deltaTime;
	float deltaY = GetYDirection() * GetSpeed() * deltaTime;

	// check collision and correct delta position
	Vector2D deltaPosition(deltaX, deltaY);
	bool canMove = m_pCollisionComponent->TryMoveAndCheckCollision(deltaPosition);

	// change direction if collide
	if (!canMove)
	{
		ChangeDirection();
	}

	if (m_direction.m_y != 1)
	{
		Vector2D tryDown{ 0, 2 };
		bool moveDown = m_pCollisionComponent->TryMoveAndCheckCollision(tryDown);
		if (moveDown)
			m_pEventSystem->AddEvent(this, EventType::kMoveDown);
	}

	ChangeX(deltaPosition.m_x);
	ChangeY(deltaPosition.m_y);
}

void Zombie::ChangeDirection()
{
	if (m_direction.m_x == 0 && m_direction.m_y == 1)
	{
		int randomDirection = rand() % 2;
		if (randomDirection == 0)
			m_pEventSystem->AddEvent(this, EventType::kMoveLeft);
		else
			m_pEventSystem->AddEvent(this, EventType::kMoveRight);
	}
	else
	{
		m_pEventSystem->AddEvent(this, EventType::kMoveDown);
	}
}
