#include "Enemy.h"
#include "SDL.h"
#include "SDL_image.h"
#include "Projectile.h"
#include "AnimationComponent.h"
#include "SimpleSDLGame.h"
#include "EventSystem.h"
#include "Player.h"

Enemy::Enemy()
	: m_isResting{false}
	, m_restTimer{0.5f}
	, m_pEventSystem{nullptr}
{
	// set Enemy character Rect and dimention
	m_direction = { 0,1 };
	m_isValid = true;
}

Enemy::~Enemy()
{
	//
}

void Enemy::Init()
{
	// for things need to be initialize out side constructor
	m_pAnimationComponent->AddAnimationSequence("Move", 0, 5);
	m_pAnimationComponent->AddAnimationSequence("Rest", 2, 3);
	m_pAnimationComponent->PlayAnimation("Move");
}

void Enemy::Tick(float deltaTime, GameRunningState* pGameRunningState)
{
	//
}

void Enemy::HandleBeginOverlap(CollisionComponent* pOtherCollider)
{
	//
}

void Enemy::Render(SDL_Renderer* pRenderer)
{
	//
}

// stop moving play resting animation
void Enemy::GetHit()
{
	m_pAnimationComponent->PlayAnimation("Rest");
	m_isResting = true;
}

// resume moving after resting time count down
void Enemy::ResumeMoving()
{
	m_pAnimationComponent->PlayAnimation("Move");
	m_isResting = false;
}

// call to update position
void Enemy::PositionUpdate(float deltaTime)
{
	//
}

void Enemy::ChangeDirection()
{
	//
}
