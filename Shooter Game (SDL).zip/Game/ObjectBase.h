#pragma once
#include "SDL_rect.h"
#include "Vector2D.h"
#include "CollisionComponent.h"
#include "AnimationComponent.h"

struct SDL_Renderer;
class GameRunningState;
class CollisionComponent;
class EventSystem;

// struct that stores float data;
struct FloatPoint { float m_x, m_y; };

/***********************************************************/
//              Base Class for Game Objects
/***********************************************************/
class ObjectBase
{
protected:
	ObjectBase();

	// Coordinates Variables
	Vector2D m_coordinates;
	FloatPoint m_dimentions;
	FloatPoint m_direction;
	SDL_Rect m_collisionBox;

	// component system
	CollisionComponent* m_pCollisionComponent;
	AnimationComponent* m_pAnimationComponent;

	// object property
	const char* m_pName;
	float m_speed;
	float m_health;
	bool m_isValid;

public:
	// public destructor
	~ObjectBase();

	// Get Object Name
	const char* GetName() const { return m_pName; };

	// Collision System related
	void AddCollisionComponent(CollisionComponent* pCollisionComponent) { m_pCollisionComponent = pCollisionComponent; };
	CollisionComponent* GetCollisionSystem() { return m_pCollisionComponent; };
	SDL_Rect& GetCollisionBox() { return m_collisionBox; };

	// Animation system related
	void AddAnimationComponent(AnimationComponent* pAnimationComponent) { m_pAnimationComponent = pAnimationComponent; };
	AnimationComponent* GetAnimationComponent() { return m_pAnimationComponent; };

	// Coordinate related functions
	Vector2D& GetCoordinateVector() { return m_coordinates; };
	float GetWidth() { return m_dimentions.m_x; };
	float GetHeight() { return m_dimentions.m_y; };
	float GetX() const { return m_coordinates.m_x; };
	float GetY() const { return m_coordinates.m_y; };
	void ChangeX(float deltaX) { m_coordinates.m_x += deltaX;};
	void ChangeY(float deltaY) { m_coordinates.m_y += deltaY; };

	// Direction Related Functions //
	float GetRotationAngle() { return m_coordinates.m_rotation; };
	float GetXDirection() const { return m_direction.m_x; };
	float GetYDirection() const { return m_direction.m_y; };
	void SetXDirection(float newX) { m_direction.m_x = newX; };
	void SetYDirection(float newY) { m_direction.m_y = newY; };

	// Speed Related Functions //
	float GetSpeed() const { return m_speed; };

	// health related
	virtual float GetHealth() { return m_health; };
	void ChangeHealth(float delta);

	// Object validation Related
	bool IsValid() const { return m_isValid; };
	void Invalid() { m_isValid = false; };

	// virtual 
	virtual void Init();
	virtual void Tick(float deltaTime, GameRunningState* pGameRunningState);
	virtual void HandleBeginOverlap(CollisionComponent* pOtherCollider);
	virtual void OverlapUpdate(CollisionComponent* pOtherCollider);
	virtual void HandleEndOverlap(CollisionComponent* pOtherCollider);
	virtual void Render(SDL_Renderer* pRenderer);
};

