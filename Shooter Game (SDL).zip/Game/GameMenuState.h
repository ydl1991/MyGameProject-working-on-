#pragma once
#include "GameState.h"
struct SDL_Texture;
struct SDL_Renderer;
struct TextureSpriteSheet;
class AnimationComponent;
class MenuBackground;
class SimpleSDLGame;

class GameMenuState : public GameState
{
	// Game World reference
	SimpleSDLGame* m_pGameWorld;				// a reference of the Game world
	// background 
	MenuBackground* m_pMenuBackground;
	// rect and texture
	SDL_Rect m_messageRect;
	SDL_Texture* m_pTexture;
	SDL_FRect m_animationOneRect;
	SDL_FRect m_animationTwoRect;
	// characters animations
	AnimationComponent* m_pAnimationOne;
	AnimationComponent* m_pAnimationTwo;
public:
	GameMenuState(SimpleSDLGame* pGameWorld);
	~GameMenuState();

	// Animation system related
	SDL_FRect GetAnimationOneRect() { return m_animationOneRect; };
	SDL_FRect GetAnimationTwoRect() { return m_animationTwoRect; };
	AnimationComponent* GetAnimationOne() { return m_pAnimationOne; };
	AnimationComponent* GetAnimationTwo() { return m_pAnimationTwo; };

	// Game State status
	virtual void EnterState() override;
	virtual void Update(float deltaTime) override;
	virtual void ExitState() override;
	// Function Overload, Event Processing
	virtual bool ProcessEvents() override;
	// Render
	virtual void RenderCurrentState(SDL_Renderer* pRenderer) override;

	// Getters
	SimpleSDLGame* GetWorld() const { return m_pGameWorld; };

private:
	void LoadBackground();
	void LoadText();
	void LoadAnimations();
};

