#include "StaticBoarder.h"

StaticBoarder::StaticBoarder(float x, float y)
{
	// set wall dimention
	m_coordinates = { x,y };
	m_dimentions = { 3, 3942 };
	m_isValid = true;
	m_collisionBox = { (int)x , (int)y, (int)m_dimentions.m_x, (int)m_dimentions.m_y };
}

void StaticBoarder::Render(SDL_Renderer* pRenderer)
{
}

void StaticBoarder::Tick(float deltaTime, GameRunningState* pGameRunningState)
{
		//
}

void StaticBoarder::HandleBeginOverlap(CollisionComponent* pOtherCollider)
{
	ObjectBase* pObject = pOtherCollider->GetOwner();
	if (pObject && m_isValid)
	{
		if (pObject->GetX() > m_coordinates.m_x)
		{
			pObject->GetCoordinateVector().m_x = m_coordinates.m_x + m_dimentions.m_x;
		}

		if (pObject->GetX() < m_coordinates.m_x)
		{
			pObject->GetCoordinateVector().m_x = m_coordinates.m_x - pObject->GetWidth();
		}
	}
}
