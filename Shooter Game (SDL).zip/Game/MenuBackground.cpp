#include "MenuBackground.h"
#include "SDL_render.h"

MenuBackground::MenuBackground(SDL_Texture* pBackground)
	: m_pTexture{ pBackground }
{
}

MenuBackground::~MenuBackground()
{	
}

void MenuBackground::Render(SDL_Renderer* pRenderer)
{
	// render background 
	SDL_RenderCopy(pRenderer, m_pTexture, nullptr, nullptr);
}
