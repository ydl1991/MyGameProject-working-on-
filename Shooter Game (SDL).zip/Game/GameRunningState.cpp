#include "GameRunningState.h"
#include "Player.h"
#include "SimpleSDLGame.h"
#include "ImageLoadingSystem.h"
#include "EventSystem.h"
#include "CollisionComponent.h"
#include "CollisionManager.h"
#include "StaticBoarder.h"
#include "SpawnerSystem.h"
#include "WorldBackground.h"
#include "GameEndingState.h"
#include "StateMachine.h"
#include "WinZone.h"
#include "SDL.h"

GameRunningState::GameRunningState(SimpleSDLGame* pGameWorld, int playerType)
	: m_pGameWorld{ pGameWorld }
	, m_pStateMachine{ m_pGameWorld->GetStateMachine()}
{
	CreatePlayer(playerType);
	CreateBackground();
	CreateWinZone();
	CreateBoarder();
	m_pSpawnerSystem = new SpawnerSystem(this, 2.f, 0, 2.f, 7.0f);
}

GameRunningState::~GameRunningState()
{
	//
	ClearAll();
}

void GameRunningState::EnterState()
{
	//
}

void GameRunningState::Update(float deltaTime)
{
	// check spawning
	m_pSpawnerSystem->Update(deltaTime);

	// update player
	m_pPlayer->Tick(deltaTime, this);

	//update all object in object lists
	for(auto it = m_allObjects.begin(); it != m_allObjects.end(); ++it)
	{
		(*it)->Tick(deltaTime, this);
	}

	// check and delete invalid object after new update
	RemoveInvalidObject();

	// process colliding pair
	m_pGameWorld->GetCollisionManager()->ProcessCollidingPair();
}

void GameRunningState::ExitState()
{
	//
}

bool GameRunningState::ProcessEvents()
{
	// process player related SDL events
	bool quit = m_pGameWorld->GetEventSystem()->ProcessEvents(m_pPlayer);
	m_pGameWorld->GetEventSystem()->ProcessEvents();

	return quit;
}

// render valid object and remove invalid object
void GameRunningState::RenderCurrentState(SDL_Renderer* pRenderer)
{
	// render background
	m_pWorldBackground->Render(pRenderer);

	// render player
	m_pPlayer->Render(pRenderer);

	// render all object
	auto it = m_allObjects.begin();
	while (it != m_allObjects.end())
	{
		if ((*it)->IsValid())
		{
			// if object is valid, render it
			(*it)->Render(pRenderer);
		}
		++it;
	}

	// present on screen
	SDL_RenderPresent(pRenderer);

	// if player die, end game
	if (!m_pPlayer || !m_pPlayer->IsValid())
	{
		GameState* pState = new GameEndingState(m_pGameWorld);
		m_pStateMachine->SetCurrentState(pState);
	}
}

void GameRunningState::AddObject(ObjectBase* pObject)
{
	m_allObjects.emplace_back(pObject);
}

void GameRunningState::RemoveInvalidObject()
{
	// check and delete invalid object after new update
	auto it = m_allObjects.begin();
	while (it != m_allObjects.end())
	{
		if ((*it)->IsValid() == false)
		{
			delete (*it);
			m_allObjects.erase(it++);
		}
		else
			++it;
	}
}

void GameRunningState::ClearAll()
{
	for (auto it = m_allObjects.begin(); it != m_allObjects.end(); ++it)
	{
		delete *it;
	}
	m_allObjects.clear();

	delete m_pPlayer;
	m_pPlayer = nullptr;

	delete m_pSpawnerSystem;
	m_pSpawnerSystem = nullptr;
	delete m_pWorldBackground;
	m_pWorldBackground = nullptr;
}

void GameRunningState::CreatePlayer(int playerType)
{
	// create player and initialize
	m_pPlayer = new Player(350.f, 500.f, 60.f, 84.f);

	TextureSpriteSheet* pSpriteSheet = nullptr;

	// store zone filename
	const char* playerImages[2] = { "Assets/CharacterAnimation/animation.png", "Assets/CharacterAnimation/warplane.png" };
	// choose character skin
	m_pGameWorld->GetImageLoadingSystem()->Load(m_pGameWorld->GetRenderer(), playerImages[playerType], pSpriteSheet);
	// create animation component and attach to player
	if (playerType == 0)
		m_pPlayer->AddAnimationComponent(new AnimationComponent(pSpriteSheet, 6.f, 60, 84, 4));
	else
		m_pPlayer->AddAnimationComponent(new AnimationComponent(pSpriteSheet, 6.f, 100, 117, 2));

	// add collision component
	m_pPlayer->AddCollisionComponent(new CollisionComponent(m_pPlayer, m_pPlayer->GetCollisionBox(), m_pGameWorld->GetCollisionManager(), CollisionState::kCanBeOverlap));

	// initialize animation
	m_pPlayer->Init();
}

void GameRunningState::CreateBackground()
{
	// load texture
	SDL_Texture* pBackground = nullptr;
	m_pGameWorld->GetImageLoadingSystem()->Load(m_pGameWorld->GetRenderer(), "Assets/background.bmp", pBackground);
	// create background
	m_pWorldBackground = new WorldBackground(pBackground, 0.f, 3342.f, (float)m_pGameWorld->GetWidth(), (float)m_pGameWorld->GetHeight());
}

// call to spawn win zone
void GameRunningState::CreateWinZone()
{
	TextureSpriteSheet* pSpriteSheet = nullptr;
	m_pGameWorld->GetImageLoadingSystem()->Load(m_pGameWorld->GetRenderer(), "Assets/ZoneAnimation/winZone.png", pSpriteSheet);

	// create win zone
	WinZone* pWinZone = new WinZone(300.f, -3300.f);

	// create animation component and attach to zone object
	pWinZone->AddAnimationComponent(new AnimationComponent(pSpriteSheet, 20.f, 320, 320, 8));

	// Collision Dimension
	pWinZone->AddCollisionComponent(new CollisionComponent(pWinZone, pWinZone->GetCollisionBox(), m_pGameWorld->GetCollisionManager(), CollisionState::kCanBeOverlap));

	// initialize animation
	pWinZone->Init();

	//emplace back to object list
	AddObject(pWinZone);
}

void GameRunningState::CreateBoarder()
{
	// set boarder walls to prevent go off boarder
	// create boarder walls and store in object list
	StaticBoarder* pWallLeft = new StaticBoarder(-3.f, 0);
	StaticBoarder* pWallRight = new StaticBoarder(float(m_pGameWorld->GetWidth()), 0);

	// create collision components
	pWallLeft->AddCollisionComponent(new CollisionComponent(pWallLeft, pWallLeft->GetCollisionBox(), m_pGameWorld->GetCollisionManager(), CollisionState::kPhysicallyCollidable));
	pWallRight->AddCollisionComponent(new CollisionComponent(pWallRight, pWallLeft->GetCollisionBox(), m_pGameWorld->GetCollisionManager(), CollisionState::kPhysicallyCollidable));

	// add to obejct list
	AddObject(pWallLeft);
	AddObject(pWallRight);
}

