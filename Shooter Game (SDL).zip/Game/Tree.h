#pragma once
#include "Enemy.h"
class Tree :
	public Enemy
{

public:
	Tree( float x, float y, EventSystem* pEventSystem, TextureSpriteSheet* pSpriteSheet, CollisionManager* pCManager);
	~Tree();

	virtual void Tick(float deltaTime, GameRunningState* pGameRunningState) override;
	virtual void HandleBeginOverlap(CollisionComponent* pOtherCollider) override;
	virtual void Render(SDL_Renderer* pRenderer) override;

	// getter
	float GetHealth() override;
private:
	virtual void PositionUpdate(float deltaTime) override;
	virtual void ChangeDirection() override;
};

