#include "Player.h"
#include "SDL.h"
#include "SimpleSDLGame.h"
#include "SDL_image.h"
#include "EventSystem.h"
#include "GameRunningState.h"
#include "WorldBackground.h"
#include "Enemy.h"
#include "TextureSpriteSheet.h"
#include "AnimationComponent.h"
#include "CollisionComponent.h"
#include "CollisionManager.h"
#include "Dragon.h"
#include "Tree.h"
#include "Zombie.h"
#include "Vector2D.h"
#include <iostream>

Player::Player(float x, float y, float w, float h)
	: m_fireRate{4.f}
	, m_mouseControlMotion{false}
	, m_readyToFire{false}
{
	// set player character Rect and dimention
	m_coordinates = { x,y };
	m_dimentions = { w, h };
	m_direction = { 0,0 };
	m_speed = 250.f;
	m_health = 100.f;
	m_collisionBox = { (int)x,(int)y, (int)w, (int)h };
}

Player::~Player()
{
	//

}

float Player::GetHealth()
{
	if (m_health > 100.f)
		m_health = 100.f;
	return m_health;
}

void Player::Init()
{
	// for things need to be initialize out side constructor
	// init animation sequence

	// human character
	//m_pAnimationComponent->AddAnimationSequence("Idle", 0, 0);
	//m_pAnimationComponent->AddAnimationSequence("Move", 0, 3);
	//m_pAnimationComponent->PlayAnimation("Idle");

	// warplan character
	m_pAnimationComponent->AddAnimationSequence("Fly", 0, 1);
	m_pAnimationComponent->PlayAnimation("Fly");
}

void Player::Tick(float deltaTime, GameRunningState* pGameRunningState)
{
	// check death
	if (!m_isValid)
	{
		return;
	}

	// check postion change
	MotionChange(deltaTime, pGameRunningState->GetWorld());

	// check animation property
	m_pAnimationComponent->Update(deltaTime);

	// check collision property
	m_pCollisionComponent->SetPosition(m_coordinates);
}

void Player::HandleBeginOverlap(CollisionComponent* pOtherCollider)
{
	if (m_isValid && pOtherCollider)
	{
		// overlap with enemy
		ObjectBase* pOther = pOtherCollider->GetOwner();
		if (pOther)
		{
			Dragon* pDragon = dynamic_cast<Dragon*>(pOther);
			if (pDragon)
			{
				ChangeHealth(-50);

				// log health after damage
				std::cout << "Player health reduce to " << m_health << "\n";

				if (m_health <= 0)
				{
					std::cout << "You are killed by monster!" << std::endl;
				}

				return;
			}

			Tree* pTree = dynamic_cast<Tree*>(pOther);
			if(pTree)
			{
				ChangeHealth(-10);

				// log health after damage
				std::cout << "Player health reduce to " << m_health << "\n";

				if (m_health <= 0)
				{
					std::cout << "You are killed by monster!" << std::endl;
				}

				return;
			}

			Zombie* pZombie = dynamic_cast<Zombie*>(pOther);
			if (pZombie)
			{
				ChangeHealth(-30);

				// log health after damage
				std::cout << "Player health reduce to " << m_health << "\n";

				if (m_health <= 0)
				{
					std::cout << "You are killed by monster!" << std::endl;
				}

				return;
			}

			// overlap with enemy projectile
			// later

			// overlap with items
			// later
		}
	}
}

// render sprite with rotation and animation
void Player::Render(SDL_Renderer* pRenderer)
{
	// calculate vector rotation
	CalculateRotation();
	// if firing projectile, rotation angle become 0
	float rotation = GetRotationAngle();
	if (m_readyToFire)
	{
		rotation = 0;
	}
	// render player
	m_pAnimationComponent->Render(pRenderer, GetX(), GetY(), GetWidth(), GetHeight(), rotation);
}

void Player::MotionChange(float deltaTime, SimpleSDLGame* pGameWorld)
{
	// normalize vector
	Vector2D tempUnitVector = m_coordinates.NormalizeVector(1
															, m_coordinates.m_x + m_direction.m_x
															, m_coordinates.m_y + m_direction.m_y);

	m_direction.m_x = tempUnitVector.m_x;
	m_direction.m_y = tempUnitVector.m_y;

//////////////////////////////////////////////////////////////////////
// if mouse event trigger, we will normalize vector for mouse moving action
// otherwise follow keyboard moving action
//////////////////////////////////////////////////////////////////////
	if (m_mouseControlMotion)
	{
		int mouseX = pGameWorld->GetEventSystem()->GetMouseX();
		int mouseY = pGameWorld->GetEventSystem()->GetMouseY();
		// move if distance more than 20.f
		if (m_coordinates.GetMagnitude(1, static_cast<float>(mouseX), static_cast<float>(mouseY)) > 20.f)
		{
			Vector2D tempUnitVector = m_coordinates.NormalizeVector(1
																	, static_cast<float>(mouseX)
																	, static_cast<float>(mouseY));
			m_direction.m_x = tempUnitVector.m_x;
			m_direction.m_y = tempUnitVector.m_y;
		}
		else
		{
			// stop moving if distance less than 20.f
			m_direction.m_x = 0.f;
			m_direction.m_y = 0.f;
			m_mouseControlMotion = false;
			return;
		}
	}

	// Set Animation 
	// For human character
	//if (m_direction.m_x == 0 && m_direction.m_y == 0)
	//{
	//	m_pAnimationComponent->PlayAnimation("Idle");
	//}
	//else
	//{
	//	m_pAnimationComponent->PlayAnimation("Move");
	//}

	// calculate player velocity
	float deltaX = m_direction.m_x * (GetSpeed()) * deltaTime;
	float deltaY = m_direction.m_y * (GetSpeed()) * deltaTime;

	// check collision, and correct delta position
	Vector2D deltaPosition(deltaX, deltaY);
	m_pCollisionComponent->TryMoveAndCheckCollision(deltaPosition);

	// window boundary check
	// if player coordinates not on window edge
	//update our player coordinates tracker (in double)
	ChangeX(deltaPosition.m_x);
	// if player coordinates not on window edge
	//update our player coordinates tracker (in double)
	ChangeY(deltaPosition.m_y);

	if ((m_coordinates.m_y + deltaPosition.m_y) > pGameWorld->GetHeight())
	{
		std::cout << "You Fall off and Die!\n";
		Invalid();
	}
}

/////////////////////////////////////////////////////////////////
// calculate rotation
// param:
// 1: unit vector x       2: unit vector y
// indicates player's moving direction
//////////////////////////////////////////////////////////////////
void Player::CalculateRotation()
{
	if (m_direction.m_x != 0 || m_direction.m_y != 0)
	{
		// if moving, calculate new rotation angle
		m_coordinates.Rotate(m_direction.m_x, m_direction.m_y);
	}
}
