#pragma once
#include "ObjectBase.h"
#include "SDL_rect.h"

/***********************************************************/
// Projectile is a weapon object that can be fired by player
// or enemy. It can collid with other object and make damage
/***********************************************************/
class Projectile : public ObjectBase
{
public:
	// constructor and destructor //
	Projectile(float x, float y, TextureSpriteSheet* pSpriteSheet, CollisionManager* pCManager);
	~Projectile();

	// virtual override
	void Init() override;
	void Tick(float deltaTime, GameRunningState* pGameRunningState) override;
	void HandleBeginOverlap(CollisionComponent* pOtherCollider) override;
	void Render(SDL_Renderer* pRenderer) override;

private:
	void UpdatePosition(float deltaTime);
};

