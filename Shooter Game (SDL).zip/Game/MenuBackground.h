#pragma once
#include "Background.h"
struct SDL_Texture;
struct SDL_Renderer;

class MenuBackground : public Background
{
	// texture and spritesheet
	SDL_Texture* m_pTexture;

public:
	MenuBackground(SDL_Texture* pBackground);
	~MenuBackground();

	// Renderer
	virtual void Render(SDL_Renderer* pRenderer) override;
};

