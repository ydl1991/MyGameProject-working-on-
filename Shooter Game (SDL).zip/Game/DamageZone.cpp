#include "DamageZone.h"
#include "SimpleSDLGame.h"
#include "CollisionManager.h"
#include "GameRunningState.h"
#include "WorldBackground.h"
#include<iostream>

DamageZone::DamageZone(float x, float y, TextureSpriteSheet* pSpriteSheet, CollisionManager* pCManager)
{
	// set wall dimention
	m_coordinates = { x,y };
	m_dimentions = { 400, 400 };
	m_isValid = true;
	AddAnimationComponent(new AnimationComponent(pSpriteSheet, 20.f, 400, 400, 60));
	m_collisionBox = { (int)x, (int)y, (int)m_dimentions.m_x, (int)m_dimentions.m_y };
	AddCollisionComponent(new CollisionComponent(this, m_collisionBox, pCManager, CollisionState::kCanBeOverlap));
}

DamageZone::~DamageZone()
{
}

void DamageZone::Init()
{
	// for things need to be initialize out side constructor
	// init animation sequence
	m_pAnimationComponent->AddAnimationSequence("Explosion", 0, 59);
	m_pAnimationComponent->PlayAnimation("Explosion");
}

void DamageZone::Tick(float deltaTime, GameRunningState* pGameRunningState)
{
	// check validation
	if (!m_isValid)
	{
		return;
	}

	// timer update
	if (m_effectTimer <= 0)
		m_effectTimer = 1.f;
	else
		m_effectTimer -= deltaTime;

	// update position
	if (pGameRunningState->GetBackground()->GetCameraDimention().y > 0)
		m_coordinates.m_y += 0.015f;

	// check if enemy at boundary
	if (GetY() >= pGameRunningState->GetWorld()->GetHeight())
	{
		// if yes, set invalid
		this->Invalid();
		return;
	}

	// for things need to be checked every frame
	m_pAnimationComponent->Update(deltaTime);

	// update collision component
	m_pCollisionComponent->SetPosition(m_coordinates);
}

void DamageZone::HandleBeginOverlap(CollisionComponent* pOtherCollider)
{
}

void DamageZone::OverlapUpdate(CollisionComponent* pOtherCollider)
{
	if (m_effectTimer <= 0)
	{
		pOtherCollider->GetOwner()->ChangeHealth(-15);
		std::cout << "Someone got burned! Runnnnnn! ... ...\n";
		std::cout << "Object's current health: " << pOtherCollider->GetOwner()->GetHealth() << "\n";
	}
}

void DamageZone::HandleEndOverlap(CollisionComponent* pOtherCollider)
{
}

void DamageZone::Render(SDL_Renderer* pRenderer)
{
	m_pAnimationComponent->Render(pRenderer, GetX(), GetY(), GetWidth(), GetHeight(), 0.f);
}
