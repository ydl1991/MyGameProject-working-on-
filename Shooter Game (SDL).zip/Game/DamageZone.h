#pragma once
#include "ZoneBase.h"
class DamageZone : public ZoneBase
{
public:

	DamageZone(float x, float y, TextureSpriteSheet* pSpriteSheet, CollisionManager* pCManager);
	~DamageZone();

	// virtual 
	virtual void Init() override;
	virtual void Tick(float deltaTime, GameRunningState* pGameRunningState) override;
	virtual void HandleBeginOverlap(CollisionComponent* pOtherCollider) override;
	virtual void OverlapUpdate(CollisionComponent* pOtherCollider) override;
	virtual void HandleEndOverlap(CollisionComponent* pOtherCollider) override;
	virtual void Render(SDL_Renderer* pRenderer) override;
};

