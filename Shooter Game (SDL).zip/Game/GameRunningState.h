#pragma once
#include "GameState.h"
#include <list>

class SimpleSDLGame;
class StateMachine;
class ImageLoadingSystem;
class AnimationComponent;
class CollisionManager;
class EventSystem;
class ObjectBase;
class Player;
class Projectile;
class Enemy;
class Wall;
class ZoneBase;
class WorldBackground;
class SpawnerSystem;

/***********************************************************/
// Game Running state that processes all objects update and 
// events
/***********************************************************/
class GameRunningState : public GameState
{
private:
	// Game Object Variables
	std::list<ObjectBase*> m_allObjects;		// a list that stores all objects
	Player* m_pPlayer;							// a reference of the player
	// Game World reference
	SimpleSDLGame* m_pGameWorld;				// a reference of the Game world
	// World Background
	WorldBackground* m_pWorldBackground;		// a reference of the game background
	// Spawner System
	SpawnerSystem* m_pSpawnerSystem;			// a reference of the spawner system
	// State Machine reference
	StateMachine* m_pStateMachine;				// a reference of the State Machine

public:
	GameRunningState(SimpleSDLGame* pGameWorld, int playerType);
	~GameRunningState();

	// virtual function to override
	// Game State status
	virtual void EnterState() override;
	virtual void Update(float deltaTime) override;
	virtual void ExitState() override;
	// Function Overload, Event Processing
	virtual bool ProcessEvents() override;
	// Render
	virtual void RenderCurrentState(SDL_Renderer* pRenderer) override;
	// Add Object
	void AddObject(ObjectBase* pObject);

	// Getters
	SimpleSDLGame* GetWorld() const { return m_pGameWorld; };
	WorldBackground* GetBackground() const { return m_pWorldBackground; };
	SpawnerSystem* GetSpawnerSystem() const { return m_pSpawnerSystem; };
	Player* GetPlayer() const { return m_pPlayer; };
	std::list<ObjectBase*>& GetObjectList() { return m_allObjects; };

private:
	// Cleanning
	void RemoveInvalidObject();
	void ClearAll();

	// object initialization functions
	void CreatePlayer(int playerType);
	void CreateBackground();
	void CreateWinZone();
	void CreateBoarder();
};

