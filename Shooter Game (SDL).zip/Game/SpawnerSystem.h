#pragma once

class GameRunningState;
class EventSystem;
struct TextureSpriteSheet;

class SpawnerSystem
{
	float m_enemySpawnTimer;							// timer that counts for enemy spawn duration
	float m_projectileSpawnTimer;						// timer that counts for projectile spawn duration
	float m_wallSpawnTimer;								// timer that counts for wall spawn duration
	float m_zoneSpawnTimer;								// timer that counts for zone spawn duration

	GameRunningState* m_pGameRunningState;				// Game running state reference

public:
	SpawnerSystem(GameRunningState* pGameRunningState, float enemyTimer, float projectileTimer, float wallTimer, float zoneTimer);
	~SpawnerSystem();

	// Setter for Spawn Timer 
	void SetEnemySpawnTimer(float time) { m_enemySpawnTimer = time; };
	void SetProjectileSpawnTimer(float time) { m_projectileSpawnTimer = time; };
	void SetWallSpawnTimer(float time) { m_wallSpawnTimer = time; };
	void SetZoneSpawnTimer(float time) { m_zoneSpawnTimer = time; };

	// template spawning function that responsible for spawning all object ( function overload)
	template<class SpawnType>
	void SpawnObject(float x, float y, TextureSpriteSheet* pSpriteSheet);
	template<class SpawnType>
	void SpawnObject(float x, float y, EventSystem* pEventSystem, TextureSpriteSheet* pSpriteSheet);

	// update function to spawn and count timer
	void Update(float deltaTime);

private:
	// check spawn functions
	void CheckSpawnEnemy();
	void CheckSpawnProjectile();
	void CheckSpawnWall();
	void CheckSpawnZone();
};
