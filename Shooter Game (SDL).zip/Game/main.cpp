#include <iostream>
#include <time.h>
#include "SimpleSDLGame.h"

/*****************************/
// Using a Visual Leak Deteck /
#include "vld.h"   ////////////
/*****************************/

SimpleSDLGame g_pGame;

int main(int argc, char** argv)
{
	g_pGame.Init();
	g_pGame.Update();
	g_pGame.ShutDown();
	return 0;
}

/*
///////////////////////////////////////////////////////////////////////////////

ASSIGNMENT DETAILS

*** Leak Detection ***
memory clean up if exit correctly (No memory leak)

*** Collision State Update ***
Added a state for Collision component including physicallyCollidable(collidable) and canBeOverlap(trigger)

*** Update Player Character ***
Added Collision Property, Added Health variable as required for all object 

*** New Object ***
Added Wall, Damage Zone, Healing Zone, Win Zone
mechanism:
Damage and healing Zones will be randomly spawned every 8 seconds.
You will see Win Zone at the end of the map, so just play it to the end. ( I have accelerated the map rolling speed just for you to quickly
get to the end point to see the win zone)

*** Enemy ***
Enemy class already exist, developed a simple movement AI

*** Event System ***
Implemented an event system that handles more than SDL Events.

*** Collision Event ***
Checking Collision function now can take in a vector2D to detect direction and correct delta x y.
create collision entry, update and exit functions

*** Additional ***
Added Map Rolling

////////////////////////////////////////////////////////////////////////////////
*/
