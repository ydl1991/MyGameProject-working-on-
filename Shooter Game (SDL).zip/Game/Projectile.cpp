#include "Projectile.h"
#include "SDL.h"
#include "SDL_image.h"
#include "AnimationComponent.h"
#include "ZoneBase.h"
#include "HealingZone.h"
#include "DamageZone.h"
#include "TextureSpriteSheet.h"
#include "CollisionManager.h"

Projectile::Projectile(float x, float y, TextureSpriteSheet* pSpriteSheet, CollisionManager* pCManager)
{
	// set projectile property
	m_coordinates = { x,y};
	m_dimentions = { 10, 20 };
	m_direction = { 0, -1 };
	m_speed = 1500.f;
	m_health = 1.f;
	AddAnimationComponent(new AnimationComponent(pSpriteSheet, std::numeric_limits<float>::min(), pSpriteSheet->m_w, pSpriteSheet->m_h, 1));
	m_collisionBox = { (int)x, (int)y, (int)m_dimentions.m_x, (int)m_dimentions.m_y };
	AddCollisionComponent(new CollisionComponent(this, m_collisionBox, pCManager, CollisionState::kCanBeOverlap));
}

Projectile::~Projectile()
{
	//
}

void Projectile::Init()
{
	// for things need to be initialize out side constructor
	m_pAnimationComponent->AddAnimationSequence("Idle", 0, 0);
	m_pAnimationComponent->PlayAnimation("Idle");
}

void Projectile::Tick(float deltaTime, GameRunningState* pGameRunningState)
{
	// for things need to be checked every frame
	// check validation
	if (!m_isValid)
	{
		return;
	}

	// update new postion
	UpdatePosition(deltaTime);

	// check if projectile at boundary
	if (GetY() <= 0)
	{
		// if yes, set invalid
		this->Invalid();
		return;
	}

	// update collision area position
	m_pCollisionComponent->SetPosition(m_coordinates);
}

void Projectile::HandleBeginOverlap(CollisionComponent* pOtherCollider)
{
	// for things happen after collision
	ObjectBase* pObject = pOtherCollider->GetOwner();
	if (pObject)
	{
		ZoneBase* pZone = dynamic_cast<ZoneBase*>(pObject);
		if(!pZone)
			this->Invalid();
	}
}

void Projectile::Render(SDL_Renderer* pRenderer)
{
	m_pAnimationComponent->Render(pRenderer, GetX(), GetY(), GetWidth(), GetHeight(), 0.f);
}

void Projectile::UpdatePosition(float deltaTime)
{
	// calculate changing position
	float deltaY = GetYDirection() * GetSpeed() * deltaTime;

	// check collision, and correct delta position
	Vector2D deltaPosition(0, deltaY);
	m_pCollisionComponent->TryMoveAndCheckCollision(deltaPosition);
	ChangeX(deltaPosition.m_x);
	ChangeY(deltaPosition.m_y);
}
