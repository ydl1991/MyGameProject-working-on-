#include "EndingBackground.h"

EndingBackground::EndingBackground(SDL_Texture* pBackground)
	: m_pTexture{ pBackground }
{
}

EndingBackground::~EndingBackground()
{
}

void EndingBackground::Render(SDL_Renderer* pRenderer)
{
	// render background 
	SDL_RenderCopy(pRenderer, m_pTexture, nullptr, nullptr);
}
