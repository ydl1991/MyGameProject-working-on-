#include "WorldBackground.h"
#include "SDL.h"
#include "SDL_rect.h"

WorldBackground::WorldBackground(SDL_Texture* pTexture, float x, float y, float w, float h)
	: m_camaraOnBackground{x, y, w, h}
	, m_pTexture{ pTexture }
	, m_cameraRollingRate{ 0.05f }
{
	//
}

WorldBackground::~WorldBackground()
{
	//
	m_pTexture = nullptr;
}

void WorldBackground::Render(SDL_Renderer* pRenderer)
{
	// check if reach the end of the world
	if (m_camaraOnBackground.y > 0)
		m_camaraOnBackground.y -= m_cameraRollingRate;
	else
		m_camaraOnBackground.y = 0;

	SDL_Rect rect = { (int)(m_camaraOnBackground.x), (int)(m_camaraOnBackground.y), (int)(m_camaraOnBackground.w), (int)(m_camaraOnBackground.h) };
	SDL_RenderCopy(pRenderer, m_pTexture, &rect, nullptr);
}
