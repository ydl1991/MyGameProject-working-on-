#pragma once
#include "ObjectBase.h"

struct SDL_Texture;

/***********************************************************/
// A static object that is unbreakable and cannot pass through
/***********************************************************/
class Wall : public ObjectBase
{
protected:
	Wall(){};
public:
	Wall(float x, float y, TextureSpriteSheet* pSpriteSheet, CollisionManager* pCManager);
	~Wall();

	// virtual override
	virtual void Init() override;
	virtual void Tick(float deltaTime, GameRunningState* pGameRunningState) override;
	virtual void HandleBeginOverlap(CollisionComponent* pOtherCollider) override;
	virtual void Render(SDL_Renderer* pRenderer) override;
};

