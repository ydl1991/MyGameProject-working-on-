#include "CollisionManager.h"
#include "CollisionComponent.h"
#include "SDL.h"
#include "ObjectBase.h"
#include "Vector2D.h"
#include <iostream>
#include <algorithm> 
#include <math.h>

CollisionManager::CollisionManager()
	: m_activeColliders{}
	, m_collidingPair{}
{
	//
}

CollisionManager::~CollisionManager()
{
	// clear
	m_activeColliders.clear();
	m_collidingPair.clear();
}

void CollisionManager::AddActiveCollider(CollisionComponent* pCollider)
{
	if (pCollider)
	{
		// make sure the object hasn't been added. if not, add to list of active colliders
		if ((std::find(m_activeColliders.begin(), m_activeColliders.end(), pCollider)) == m_activeColliders.end())
		{
			m_activeColliders.emplace_back(pCollider);
		}
	}
}

void CollisionManager::RemoveCollider(CollisionComponent* pCollider)
{
	if (pCollider)
	{
		// find the invalid collider and remove all the pairs related to it
		RemoveInvalidPair(pCollider);

		// find the collider and remove from active collider
		auto location = std::find(m_activeColliders.begin(), m_activeColliders.end(), pCollider);
		if (location != m_activeColliders.end())
		{
			m_activeColliders.erase(location, location);
		}
	}
}

bool CollisionManager::CheckForCollisionAndNotify(CollisionComponent* pColliderToCheck, Vector2D& deltaPosition)
{
	// track if can move
	bool canMove = true;
	
	if (pColliderToCheck)
	{
		// get the collider transform
		SDL_Rect colliderTransform = pColliderToCheck->GetTransform();

		// calculate bounds
		int left = colliderTransform.x;
		int right = colliderTransform.x + colliderTransform.w;
		int top = colliderTransform.y;
		int bottom = colliderTransform.y + colliderTransform.h;

		for (CollisionComponent* pOtherCollider : m_activeColliders)
		{
			// dont check against ourself!
			if (pColliderToCheck == pOtherCollider)
			{
				continue;
			}

			// get the transform from other collider
			SDL_Rect otherTransform = pOtherCollider->GetTransform();

			// calculate bounds for other collider
			int otherLeft = otherTransform.x;
			int otherRight = otherTransform.x + otherTransform.w;
			int otherTop = otherTransform.y;
			int otherBottom = otherTransform.y + otherTransform.h;

			// check collision
			bool xOverlap = left < otherRight && right > otherLeft;
			bool yOverlap = top < otherBottom && bottom > otherTop;

			if (xOverlap && yOverlap)
			{
				ObjectBase* pObject = pColliderToCheck->GetOwner();
				ObjectBase* pOther = pOtherCollider->GetOwner();

				// if both are valid objects
				if (pObject && pOther)
				{
					// handle begin overlap
					pObject->HandleBeginOverlap(pOtherCollider);
					pOther->HandleBeginOverlap(pColliderToCheck);

					// if other object is physically collidable, handle position correction, otherwise overlap through it
					if (pOtherCollider->GetCollisionState() == CollisionState::kPhysicallyCollidable)
					{
						canMove = false;
						// correct collision distance for x
						int overlapWidth = std::min(abs(left - otherRight), abs(right - otherLeft));
						int overlapHeight = std::min(abs(bottom - otherTop), abs(top - otherBottom));
						if (overlapWidth > overlapHeight)
						{
							// if object is moving up
							if (deltaPosition.m_y < 0)
								// offset overlap distance
								deltaPosition.m_y += overlapHeight;
							else
								deltaPosition.m_y -= overlapHeight;
							return canMove;
						}
						else
						{
							// if object is moving left
							if (deltaPosition.m_x < 0)
								// offset overlap distance
								deltaPosition.m_x += overlapWidth;
							else
								deltaPosition.m_x -= overlapWidth;
							return canMove;
						}
					}
					else
					{
						// add pair for collision update
						AddPair(pColliderToCheck, pOtherCollider);
					}
				}
			}
		}
	}
	return canMove;
}

// call to pair collision component
void CollisionManager::AddPair(CollisionComponent* pCollider, CollisionComponent* pOther)
{
	if (pCollider && pOther)
	{
		for (int i = 0; i < m_collidingPair.size(); ++i)
		{
			bool combination1 = (m_collidingPair[i].first == pCollider) && (m_collidingPair[i].second == pOther);
			bool combination2 = (m_collidingPair[i].first == pOther) && (m_collidingPair[i].second == pCollider);
			// if pair exist, do nothing
			if (combination1 || combination2)
			{
				return;
			}
		}

		m_collidingPair.emplace_back(std::make_pair(pCollider, pOther));
	}
}

// call to remove pair
void CollisionManager::RemoveInvalidPair(CollisionComponent* pCollider)
{
	if (pCollider)
	{
		for (auto it = m_collidingPair.begin(); it != m_collidingPair.end(); )
		{
			if (((*it).first == pCollider) || ((*it).second == pCollider))
			{
				it = m_collidingPair.erase(it);
			}
			else
			{
				++it;
			}
		}
	}
}

// call to process colliding pair
void CollisionManager::ProcessCollidingPair()
{
	// check pair overlap
	// get the collider transform
	for(auto it = m_collidingPair.begin(); it != m_collidingPair.end();)
	{
		CollisionComponent* pCollider = (*it).first;
		CollisionComponent* pOther = (*it).second;

		if (pCollider && pOther && pCollider->GetOwner()->IsValid() && pOther->GetOwner()->IsValid())
		{
			SDL_Rect colliderTransform = (*it).first->GetTransform();

			//  get the transform
			int left = colliderTransform.x;
			int right = colliderTransform.x + colliderTransform.w;
			int top = colliderTransform.y;
			int bottom = colliderTransform.y + colliderTransform.h;

			// get the transform from other collider
			SDL_Rect otherTransform = (*it).second->GetTransform();

			// calculate bounds for other collider
			int otherLeft = otherTransform.x;
			int otherRight = otherTransform.x + otherTransform.w;
			int otherTop = otherTransform.y;
			int otherBottom = otherTransform.y + otherTransform.h;

			// check collision
			bool xOverlap = left < otherRight && right > otherLeft;
			bool yOverlap = top < otherBottom && bottom > otherTop;

			if (xOverlap && yOverlap)
			{
				(*it).first->GetOwner()->OverlapUpdate((*it).second);
				(*it).second->GetOwner()->OverlapUpdate((*it).first);
				++it;
			}
			else
			{
				(*it).first->GetOwner()->HandleEndOverlap((*it).second);
				(*it).second->GetOwner()->HandleEndOverlap((*it).first);
				it = m_collidingPair.erase(it);
			}
		}
		else
		{
			it = m_collidingPair.erase(it);
		}
	}
}
