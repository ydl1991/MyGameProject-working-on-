#pragma once
#include <SDL.h>

class GameState;

/***********************************************************/
// State Machine that processes game states
/***********************************************************/
class StateMachine
{
public:
	StateMachine();
	~StateMachine();

	bool Init();

	void SetCurrentState(GameState* newState);
	bool ProcessEvents();
	void Update(float deltaTime);
	void RenderCurrentState(SDL_Renderer* pRenderer);

private:
	GameState* m_pCurrentState;
};

