#pragma once
#include "ObjectBase.h"
#include "SDL_rect.h"

class SimpleSDLGame;

/***********************************************************/
// Player is a input-controlled game object that can fire
// projectile, collid with others.
/***********************************************************/
class Player : public ObjectBase
{
	bool m_readyToFire;							// detect firing status		
	bool m_mouseControlMotion;					// detect moving status
	float m_fireRate;							// fire rate

public:
	// Constructor and destructor
	Player(float x, float y, float w, float h);
	~Player();

	// Action Related Functions //
	bool GetMotionState() { return m_mouseControlMotion; };
	void ChangeMotionState() { m_mouseControlMotion ? m_mouseControlMotion = false : m_mouseControlMotion = true; };

	// Speed Related Functions //
	void ChangePlayerSpeed() { (m_speed == 250.f) ? m_speed = 500.f : m_speed = 250.f; };

	// Fire Related Functions
	float GetFireRate() const { return m_fireRate; };
	void SetFireRate(float newRate) { m_fireRate = newRate; };
	void FireSwitch() { m_readyToFire = 1 - m_readyToFire; };
	bool GetFireStatus() { return m_readyToFire; };

	// health
	float GetHealth() override;

	// virtual override
	void Init() override;
	void Tick(float deltaTime, GameRunningState* pGameRunningState) override;
	void HandleBeginOverlap(CollisionComponent* pOtherCollider) override;
	void Render(SDL_Renderer* pRenderer) override;

private:

	void CalculateRotation();														// rotation angle calculation
	void MotionChange(float deltaTime, SimpleSDLGame* pGameWorld);					// moving action
};

