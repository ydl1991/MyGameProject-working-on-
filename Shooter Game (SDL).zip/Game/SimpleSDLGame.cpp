#include "ImageLoadingSystem.h"
#include "SimpleSDLGame.h"
#include "EventSystem.h"
#include "CollisionManager.h"
#include "StateMachine.h"
#include "GameState.h"
#include "GameRunningState.h"
#include "GameMenuState.h"
#include <SDL.h>
#include <time.h>
#include <SDL_image.h>
#include <chrono>
#include <cmath>
#include <random>
#include <iostream>

SimpleSDLGame::SimpleSDLGame()
	: m_pRenderer{ nullptr }
	, m_pWindow{ nullptr }
	, m_pImageSystem{ nullptr }
	, m_pEventSystem{ nullptr }
	, m_pCollisionManager{ nullptr }
	, m_pStateMachine{ nullptr }
{
	//
}

SimpleSDLGame::~SimpleSDLGame()
{
	//
}

// call to initialize SDL windows and renderer to draw the art
void SimpleSDLGame::Init()
{
	if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_AUDIO) != 0)
	{
		std::cout << "Failed to initialize SDL" << std::endl;
		return;
	}

	// create window
	m_pWindow = SDL_CreateWindow("Hello World", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, m_kWindowWidth, m_kWindowHeight, SDL_WINDOW_SHOWN);
	// check if window create successfully
	if (m_pWindow != nullptr)
	{
		std::cout << "SDL_CreateWindow() succeeded" << std::endl;
	}
	else
	{
		std::cout << "SDL_CreateWindow() failed. Error: " << SDL_GetError() << std::endl;
		SDL_Quit();
		return;
	}

	// create renderer
	m_pRenderer = SDL_CreateRenderer(m_pWindow, -1, SDL_RENDERER_ACCELERATED);
	// check if creation is succeeded
	if (m_pRenderer != nullptr)
	{
		std::cout << "SDL_CreateRenderer() succeeded" << std::endl;
	}
	else
	{
		std::cout << "SDL_CreateRenderer() failed" << SDL_GetError() << std::endl;
		SDL_DestroyWindow(m_pWindow);
		SDL_Quit();
		return;
	}	

	// initialize
	m_pImageSystem = new ImageLoadingSystem();
	m_pEventSystem = new EventSystem();
	m_pCollisionManager = new CollisionManager();
	m_pStateMachine = new StateMachine();

	/////////////////////////////////
	// create main menu state here
	/////////////////////////////////
	GameState* pState = new GameMenuState(this);
	m_pStateMachine->SetCurrentState(pState);
	pState = nullptr;

	std::cout << "Successfully initialized SDL!" << std::endl;
}

// call to shut down windows
void SimpleSDLGame::ShutDown()
{
	// distroy renderer when game end
	SDL_DestroyRenderer(m_pRenderer);
	m_pWindow = nullptr;

	// distroy window when game end
	SDL_DestroyWindow(m_pWindow);
	m_pRenderer = nullptr;

	// delete image system
	delete m_pImageSystem;
	m_pImageSystem = nullptr;

	// delete event system
	delete m_pEventSystem;
	m_pEventSystem = nullptr;

	// delete collision manager
	delete m_pCollisionManager;
	m_pCollisionManager = nullptr;

	delete m_pStateMachine;
	m_pStateMachine = nullptr;

	// quit window
	SDL_Quit();
}

/*******************************************************/
//                 Major Game Update
//	1. Delta time calculation
//  2. Game Object Positions Update
//  3. Render Game Object
/*******************************************************/
//call to update each frame
void SimpleSDLGame::Update()
{
	// seed random
	srand((unsigned int)time(nullptr));

	// variable determines end game event
	bool shouldQuit = false;
	// start frame count
	auto lastFrameTime = std::chrono::high_resolution_clock::now();

	while (!shouldQuit)
	{	
		/*******************************************************/
		//                 Set Time Duration
		/*******************************************************/
		// end frame count
		auto thisFrameTime = std::chrono::high_resolution_clock::now();
		// calculate frame duration
		std::chrono::duration<float> lastFrameDuration = thisFrameTime - lastFrameTime;
		float deltaTime = lastFrameDuration.count();
		// change frame starting time to the current frame ending time
		lastFrameTime = thisFrameTime;

		/*******************************************************/
		//					Process Events
		/*******************************************************/
		shouldQuit = m_pStateMachine->ProcessEvents();

		/*******************************************************/
		//                 Update Game World
		/*******************************************************/
		m_pStateMachine->Update(deltaTime);

		/*******************************************************/
		//              Render(Update Render Loop)
		/*******************************************************/
		m_pStateMachine->RenderCurrentState(m_pRenderer);
	}
}

