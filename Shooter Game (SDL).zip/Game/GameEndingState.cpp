#include "GameEndingState.h"
#include "SimpleSDLGame.h"
#include "SDL_render.h"
#include "AnimationComponent.h"
#include "EventSystem.h"
#include "ImageLoadingSystem.h"
#include "EndingBackground.h"

GameEndingState::GameEndingState(SimpleSDLGame* pGameWorld)
	: m_pGameWorld{ pGameWorld }
	, m_pEndingBackground{ nullptr }
{
	LoadBackground();
}

GameEndingState::~GameEndingState()
{
	delete m_pEndingBackground;
	m_pEndingBackground = nullptr;
}

void GameEndingState::EnterState()
{

}

void GameEndingState::Update(float deltaTime)
{
}

void GameEndingState::ExitState()
{
}

bool GameEndingState::ProcessEvents()
{
	return m_pGameWorld->GetEventSystem()->ProcessPostGameEvents(this);
}

void GameEndingState::RenderCurrentState(SDL_Renderer* pRenderer)
{
	// render background
	m_pEndingBackground->Render(pRenderer);
	// present on screen
	SDL_RenderPresent(pRenderer);
}

void GameEndingState::LoadBackground()
{
	// load texture
	SDL_Texture* pBackground = nullptr;
	m_pGameWorld->GetImageLoadingSystem()->Load(m_pGameWorld->GetRenderer(), "Assets/mainMenu.jpg", pBackground);
	// create background
	m_pEndingBackground = new EndingBackground(pBackground);
}

void GameEndingState::LoadTexture()
{
	SDL_Texture* pTexture = nullptr;
	// get renderer
	SDL_Renderer* pRenderer = GetWorld()->GetRenderer();
	// load sprite sheet
	GetWorld()->GetImageLoadingSystem()->Load(pRenderer, "Assets/exit.png", pTexture);
	m_pButton = pTexture;
}

