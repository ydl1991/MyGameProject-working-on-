#include "WinZone.h"
#include "SimpleSDLGame.h"
#include "Player.h"
#include "GameRunningState.h"
#include "WorldBackground.h"
#include <iostream>

WinZone::WinZone(float x, float y)
{
	// set wall dimention
	m_coordinates = { x,y };
	m_dimentions = { 200.f, 200.f };
	m_isValid = true;
	m_collisionBox = { (int)x + 50, (int)y + 10, (int)m_dimentions.m_x - 100, (int)m_dimentions.m_y - 20 };
}

WinZone::~WinZone()
{
}

void WinZone::Init()
{
	// for things need to be initialize out side constructor
	// init animation sequence
	m_pAnimationComponent->AddAnimationSequence("WinPortal", 0, 7);
	m_pAnimationComponent->PlayAnimation("WinPortal");
}

void WinZone::Tick(float deltaTime, GameRunningState* pGameRunningState)
{
	// check validation
	if (!m_isValid)
	{
		return;
	}

	// update position
	if (pGameRunningState->GetBackground()->GetCameraDimention().y > 0)
		m_coordinates.m_y += pGameRunningState->GetBackground()->GetCameraRollingRate();

	// check if enemy at boundary
	if (GetY() >= pGameRunningState->GetWorld()->GetHeight())
	{
		// if yes, set invalid
		this->Invalid();
		return;
	}

	// for things need to be checked every frame
	m_pAnimationComponent->Update(deltaTime);

	// update collision component
	Vector2D collisionPosition{ m_coordinates.m_x + 50, m_coordinates.m_y + 10 };
	m_pCollisionComponent->SetPosition(collisionPosition);
}

// call to handle overlap
void WinZone::HandleBeginOverlap(CollisionComponent* pOtherCollider)
{
	ObjectBase* pObject = pOtherCollider->GetOwner();
	if (pObject->IsValid())
	{
		Player* pPlayer = dynamic_cast<Player*>(pObject);
		if (pPlayer)
		{
			std::cout << "Congrats! You Win The Game!!!\n";
			pPlayer->Invalid();
		}
	}
}

void WinZone::Render(SDL_Renderer* pRenderer)
{
	m_pAnimationComponent->Render(pRenderer, GetX(), GetY(), GetWidth(), GetHeight(), 0.f);
}
