#pragma once
#include "Background.h"
struct SDL_Texture;
struct SDL_Renderer;

class EndingBackground : public Background
{
	// texture and spritesheet
	SDL_Texture* m_pTexture;
public:
	EndingBackground(SDL_Texture* pBackground);
	~EndingBackground();

	// Renderer
	virtual void Render(SDL_Renderer* pRenderer) override;
};

