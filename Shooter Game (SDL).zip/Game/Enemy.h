#pragma once
#include "ObjectBase.h"
#include "SDL_rect.h"

class EventSystem;

/***********************************************************/
// Enemy is a object that go against with player.
// it can collid with other object and make damage
/***********************************************************/
class Enemy : public ObjectBase
{
protected:
	bool m_isResting;
	float m_restTimer;
	EventSystem* m_pEventSystem;
public:
	Enemy();
	~Enemy();

	// virtual override
	virtual void Init() override;
	virtual void Tick(float deltaTime, GameRunningState* pGameRunningState) override;
	virtual void HandleBeginOverlap(CollisionComponent* pOtherCollider) override;
	virtual void Render(SDL_Renderer* pRenderer) override;

protected:
	virtual void GetHit();
	virtual void ResumeMoving();
	virtual void PositionUpdate(float deltaTime);
	virtual void ChangeDirection();
};

