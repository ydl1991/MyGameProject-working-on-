// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Components/BoxComponent.h"
#include "GameFramework/Actor.h"
#include "PingTrigger.generated.h"

DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FPingOverlapSigniture, AHopperPawn*, OtherActor);

UCLASS()
class HOPPER_API APingTrigger : public AActor
{
	GENERATED_BODY()

	/* The mesh component */
	UPROPERTY(Category = Mesh, VisibleDefaultsOnly, BlueprintReadOnly, meta = (AllowPrivateAccess = "true"))
	class UStaticMeshComponent* PingTriggerMeshComponent;
	
	// set last time
	float LastTime;

public:

	// collision component
	UPROPERTY(BlueprintReadWrite, EditAnywhere, category = Collision)
	class UBoxComponent* BoxCollision;

	FPingOverlapSigniture OnPingBeingOverlap;

	float GetLastTime() { return LastTime; };

protected:
	// Called when the game starts or when spawned
	virtual void BeginPlay() override;

public:	
	// Sets default values for this actor's properties
	APingTrigger();

	// Called every frame
	virtual void Tick(float DeltaTime) override;

	UFUNCTION(BlueprintCallable)
	void HandleBeginOverlap(AActor* Box, AActor* OtherActor);
	UFUNCTION()
	void Alarm(AHopperPawn* OverlapPlayer);

private:
};
