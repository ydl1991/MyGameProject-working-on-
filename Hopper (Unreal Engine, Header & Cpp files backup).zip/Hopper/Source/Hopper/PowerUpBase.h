// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "PowerUpManager.h"
#include "PowerUpBase.generated.h"

// Delegates
DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FPowerUpPickupSignature, AHopperPawn*, Player);
DECLARE_DYNAMIC_MULTICAST_DELEGATE(FPowerUpResetSignature);

UCLASS()
class HOPPER_API APowerUpBase : public AActor
{
	GENERATED_BODY()

private:
	float Timer;
	bool bIsCoolingDown;
	
public:

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "PowerUp")
	float RegenTime;

	UPROPERTY(BlueprintAssignable, Category = Delegate)
	FPowerUpPickupSignature OnPowerupPickUp;

	UPROPERTY(BlueprintAssignable, Category = Delegate)
	FPowerUpResetSignature OnPowerupReset;

	UPROPERTY(BlueprintReadWrite, Editanywhere, Category = Audio)
	class USoundBase* PowerupPickupSound;
	UPROPERTY(BlueprintReadWrite, EditAnywhere, Category = Audio)
	class USoundBase* PowerupSound;

protected:
	// Called when the game starts or when spawned
	virtual void BeginPlay() override;

public:	

	// Sets default values for this actor's properties
	APowerUpBase();

	DECLARE_EVENT(APowerUpBase, FOnPowerUpEvent)

	FOnPowerUpEvent PowerUpEvent;

	//FOnPowerUpEvent& OnPowerUpEvent() { return PowerUpEvent; }
	//FOnPowerUpEvent HandlePowerUpEvent;

	UFUNCTION(BlueprintNativeEvent)
	void HandlePowerUpEvent();

	// Called every frame
	virtual void Tick(float DeltaTime) override;

	// one way, another is using delegate
	/*UFUNCTION(BlueprintNativeEvent)
	void OnPickup(class AHopperPawn* Player);*/

	/*UFUNCTION(BlueprintNativeEvent)
	void OnReset();*/

	//Shared Ptr Crashes on deallocation
	//TSharedPtr<FPowerUpManager> ManagerRef;

	UFUNCTION()
	void HandleBeginOverlap(AActor* Overlapped, AActor* OtherObejct);

	UFUNCTION(BlueprintCallable)
	void SetMeshVisibilityAndCollision(UStaticMeshComponent* Mesh, bool bTurnOn);
};
