// Copyright 1998-2019 Epic Games, Inc. All Rights Reserve

#include "HopperProjectile.h"
#include "GameFramework/ProjectileMovementComponent.h"
#include "UObject/ConstructorHelpers.h"
#include "Components/StaticMeshComponent.h"
#include "GameFramework/ProjectileMovementComponent.h"
#include "Materials/MaterialInstanceDynamic.h"
#include "Engine/StaticMesh.h"
#include "HopperPawn.h"
#include "Hopper.h"
#include "HopperEnemy.h"
#include "Kismet/GameplayStatics.h"
#include "HopperWildCentaur.h"

AHopperProjectile::AHopperProjectile() 
{
	// Static reference to the mesh to use for the projectile
	static ConstructorHelpers::FObjectFinder<UStaticMesh> ProjectileMeshAsset(TEXT("/Game/TwinStick/Meshes/TwinStickProjectile.TwinStickProjectile"));

	// Create mesh component for the projectile sphere
	ProjectileMesh = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("ProjectileMesh0"));
	ProjectileMesh->SetStaticMesh(ProjectileMeshAsset.Object);
	ProjectileMesh->SetupAttachment(RootComponent);
	ProjectileMesh->BodyInstance.SetCollisionProfileName("Projectile");
	ProjectileMesh->OnComponentHit.AddDynamic(this, &AHopperProjectile::OnHit);		// set up a notification for when this component hits something
	RootComponent = ProjectileMesh;

	// material 
	static ConstructorHelpers::FObjectFinder<UMaterial>Material(TEXT("/Game/TwinStick/Material/Projectile_Mat.Projectile_Mat"));
	ProjectileMaterial = UMaterialInstanceDynamic::Create(Material.Object, Material.Object);

	static ConstructorHelpers::FObjectFinder<USoundBase> SoundBase(TEXT("/Game/TwinStick/Audio/GotHit.GotHit"));
	CollisionSound = SoundBase.Object;

	// Use a ProjectileMovementComponent to govern this projectile's movement
	ProjectileMovement = CreateDefaultSubobject<UProjectileMovementComponent>(TEXT("ProjectileMovement0"));
	ProjectileMovement->UpdatedComponent = ProjectileMesh;
	ProjectileMovement->InitialSpeed = 3000.f;
	ProjectileMovement->MaxSpeed = 3000.f;
	ProjectileMovement->bRotationFollowsVelocity = true;
	ProjectileMovement->bShouldBounce = false;
	ProjectileMovement->ProjectileGravityScale = 0.f; // No gravity

	// Die after 3 seconds by default
	InitialLifeSpan = 3.0f;

	PrimaryActorTick.bCanEverTick = true;
}

void AHopperProjectile::BeginPlay()
{

	// magic!
	Super::BeginPlay();

	// Log can be warninng or error or any other name
	UE_LOG(LogHopperProjectile, Log, TEXT("HopperProjectile::BeginPlay!"));
}

void AHopperProjectile::Tick(float DeltaSeconds)
{
	Super::Tick(DeltaSeconds);

	//UE_LOG(LogTemp, Log, TEXT("DeltaSeconds: %.3f"), DeltaSeconds);
}

void AHopperProjectile::OnHit(UPrimitiveComponent* HitComp, AActor* OtherActor, UPrimitiveComponent* OtherComp, FVector NormalImpulse, const FHitResult& Hit)
{
	//check if the object that this projectile hit was a hopper enemy...
	if (OtherActor->IsA<AHopperEnemy>())
	{
		UE_LOG(LogHopperProjectile, Log, TEXT("A projectile hit Enemy: %s"), *OtherActor->GetName());
		
		FDamageEvent DamageEvent;

		OtherActor->TakeDamage(20, DamageEvent, GetInstigator()->GetController(), GetOwner());

	}
	// check if projectile hit is a Centaur
	if (OtherActor->IsA<AHopperWildCentaur>())
	{
		UE_LOG(LogHopperProjectile, Log, TEXT("A projectile hit Enemy: %s"), *OtherActor->GetName());

		FDamageEvent DamageEvent;

		OtherActor->TakeDamage(20, DamageEvent, GetInstigator()->GetController(), GetOwner());
	}
	// Only add impulse and destroy projectile if we hit a physics
	if ((OtherActor != NULL) && (OtherActor != this) && (OtherComp != NULL) && OtherComp->IsSimulatingPhysics())
	{
		OtherComp->AddImpulseAtLocation(GetVelocity() * 20.0f, GetActorLocation());
	}

	// try and play the sound if specified
	if (CollisionSound != nullptr)
	{
		UGameplayStatics::PlaySoundAtLocation(this, CollisionSound, GetActorLocation());
	}

	Destroy();
}

// call to change weapon material to laser
void AHopperProjectile::ChangeWeapon()
{
	ProjectileMesh->SetMaterial(0, ProjectileMaterial);
}
