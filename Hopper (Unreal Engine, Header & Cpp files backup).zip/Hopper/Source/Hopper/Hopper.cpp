// Copyright 1998-2019 Epic Games, Inc. All Rights Reserved.

#include "Hopper.h"
#include "Modules/ModuleManager.h"

IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, Hopper, "Hopper" );

DEFINE_LOG_CATEGORY(LogHopper)
DEFINE_LOG_CATEGORY(LogHopperProjectile);
DEFINE_LOG_CATEGORY(LogHopperEnemy);
DEFINE_LOG_CATEGORY(LogHealthTrackingDevice);
 