// Copyright 1998-2019 Epic Games, Inc. All Rights Reserved.
#pragma once

#include "CoreMinimal.h"
#include "HopperGameMode.h"
#include "GameFramework/Character.h"
#include "HealthTrackingComponent.h"
#include "Containers/CircularQueue.h"
#include "PingTrigger.h"
#include "Templates/SharedPointer.h"
#include "HopperPawn.generated.h"

using PingQueue = TCircularQueue<class APingTrigger*>;

DECLARE_DELEGATE_TwoParams(FRespawnerSigniture, APawn*, AController*);

UCLASS(Blueprintable)
class AHopperPawn : public APawn
{
	GENERATED_BODY()

	/* The mesh component */
	UPROPERTY(Category = Mesh, VisibleDefaultsOnly, BlueprintReadOnly, meta = (AllowPrivateAccess = "true"))
	class UStaticMeshComponent* ShipMeshComponent;

	/** The camera */
	UPROPERTY(Category = Camera, VisibleAnywhere, BlueprintReadOnly, meta = (AllowPrivateAccess = "true"))
	class UCameraComponent* CameraComponent;

	/** Camera boom positioning the camera above the character */
	UPROPERTY(Category = Camera, VisibleAnywhere, BlueprintReadOnly, meta = (AllowPrivateAccess = "true"))
	class USpringArmComponent* CameraBoom;

private:

	/* Flag to control firing  */
	uint32 bCanFire : 1;

	// bool to activate laser weapon
	uint32 bLaserActivated : 1;

	/** Handle for efficient management of ShotTimerExpired timer */
	FTimerHandle TimerHandle_ShotTimerExpired;

	// count seconds
	float SecondCounter;

	// shared pointer of hopper game mode
	AHopperGameMode* HopperGameMode;

	/** Container that stores ping trigger */
	// TCircularQueue has no default constructor
	// So I have to use a pointer
	TSharedPtr<PingQueue, ESPMode::ThreadSafe> PingTriggerQueue;

	// a simple respawn timer
	float RespawnTimer;

	// special effect zone status
	bool bInIceZone;
	bool bInExplosionZone;

public:

	/** Offset from the ships location to spawn projectiles */
	UPROPERTY(Category = Gameplay, EditAnywhere, BlueprintReadWrite)
	FVector GunOffset;

	/* How fast the weapon will fire */
	UPROPERTY(Category = Gameplay, EditAnywhere, BlueprintReadWrite)
	float FireRate;

	/* The speed our ship moves around the level */
	UPROPERTY(Category = Gameplay, EditAnywhere, BlueprintReadWrite)
	float MoveSpeed;

	/** Sound to play each time we fire */
	UPROPERTY(Category = Audio, EditAnywhere, BlueprintReadWrite)
	class USoundBase* FireSound;
	UPROPERTY(Category = Audio, EditAnywhere, BlueprintReadWrite)
	class USoundBase* LaserFireSound;
	UPROPERTY(BlueprintReadWrite, Editanywhere, Category = Audio)
	class USoundBase* DropPingSound;

	// health tracking component
	UPROPERTY(BlueprintReadWrite, EditAnywhere, Category = "Health Tracking")
	UHealthTrackingComponent* HealthTrackingComponent;

	//Bullet counter
	UPROPERTY(BlueprintReadWrite, EditAnywhere, Category = "Bullet Tracking")
	TMap<FString, int32> BulletCounter;


	// Static names for axis bindings
	static const FName MoveForwardBinding;
	static const FName MoveRightBinding;
	static const FName FireForwardBinding;
	static const FName FireRightBinding;
	static const FName DropPingTriggerBinding;

	// respawn signiture
	FRespawnerSigniture RespawnWhenDead;

public:

	AHopperPawn();

	virtual void BeginPlay() override;

	// Begin Actor Interface
	virtual void Tick(float DeltaSeconds) override;
	virtual void SetupPlayerInputComponent(class UInputComponent* InputComponent) override;
	// End Actor Interface

	// apply Special effect
	float SlowEffect(float Multiplier, float Speed) { return bInExplosionZone ? (Speed * Multiplier) : Speed; }
	float SpeedingEffect(float Multiplier, float Speed) { return bInIceZone ? (Speed * Multiplier) : Speed; }
	void ZoneDamage(float Damage);

	/* Fire a shot in the specified direction */
	void FireShot(FVector FireDirection);

	/* Handler for the fire timer expiry */
	void ShotTimerExpired();

	/** Returns ShipMeshComponent subobject **/
	FORCEINLINE class UStaticMeshComponent* GetShipMeshComponent() const { return ShipMeshComponent; }
	/** Returns CameraComponent subobject **/
	FORCEINLINE class UCameraComponent* GetCameraComponent() const { return CameraComponent; }
	/** Returns CameraBoom subobject **/
	FORCEINLINE class USpringArmComponent* GetCameraBoom() const { return CameraBoom; }

	// getter and setter of laser weapon status
	UFUNCTION(BlueprintCallable)
	void SwitchInExplosionZone(bool bCondition) { bInExplosionZone = bCondition; };
	UFUNCTION(BlueprintCallable)
	void SwitchInIcyZone(bool bCondition) { bInIceZone = bCondition; };

private:

	UFUNCTION(BlueprintCallable)
	void TurnOffMeshVisibilityAndCollision(UStaticMeshComponent* Mesh);

	// getter and setter of laser weapon status
	UFUNCTION(BlueprintCallable)
	bool HasLaser() const { return bLaserActivated; }
	UFUNCTION(BlueprintCallable)
	void SetLaserStatus(bool Status) { bLaserActivated = Status; }

	// dropping function
	UFUNCTION(BlueprintCallable)
	void DropPingTrigger();

	// check ping triger expire
	void CheckPingTriggerExpire();
};