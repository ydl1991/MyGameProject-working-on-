// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "HealthTrackingComponent.generated.h"


UCLASS( ClassGroup=(Custom), meta=(BlueprintSpawnableComponent) )
class HOPPER_API UHealthTrackingComponent : public UActorComponent
{
	GENERATED_BODY()

public:	

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "HealthTracking")
		float Health;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "HealthTracking")
		bool bIsDead;

protected:

	// Called when the game starts
	virtual void BeginPlay() override;

public:	

	// Sets default values for this component's properties
	UHealthTrackingComponent();

	// Called every frame
	virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;

	// check death
	UFUNCTION(BlueprintCallable, Category = "HealthTracking")
	virtual void DeathCheck();

	UFUNCTION(BlueprintCallable, Category = "HealthTracking")
	virtual void HealthCheck(float Delta);

#if WITH_EDITOR
	virtual void PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent) override;
#endif
};
