// Fill out your copyright notice in the Description page of Project Settings.


#include "PowerUpManager.h"

FPowerUpManager::FPowerUpManager()
	:Test(52)
{
}

FPowerUpManager::~FPowerUpManager()
{
}

void FPowerUpManager::Tick(float DeltaSeconds)
{
	// Spawned a powerup base
	// set a shared ref on the power up
}
