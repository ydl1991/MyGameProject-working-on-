// Fill out your copyright notice in the Description page of Project Settings.


#include "HealthTrackingComponent.h"
#include "Hopper.h"

// Sets default values for this component's properties
UHealthTrackingComponent::UHealthTrackingComponent()
{
	Health = 100;
	bIsDead = false;

	// Set this component to be initialized when the game starts, and to be ticked every frame.  You can turn these features
	// off to improve performance if you don't need them.
	PrimaryComponentTick.bCanEverTick = true;

	// ...
}


// Called when the game starts
void UHealthTrackingComponent::BeginPlay()
{
	Super::BeginPlay();

	// ...
	
}

// Called every frame
void UHealthTrackingComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);
	// ...
}

void UHealthTrackingComponent::HealthCheck(float Delta)
{
	// Using log to test
	if (Delta > 0)
	{
		UE_LOG(LogHealthTrackingDevice, Log, TEXT("%f Health are Generated!"), Delta);
	}
	else
	{
		UE_LOG(LogHealthTrackingDevice, Log, TEXT("%f damage are taken!"), Delta);
	}

	Health += Delta;

	DeathCheck();
}


void UHealthTrackingComponent::DeathCheck()
{
	if (Health <= 0)
	{
		bIsDead = true;
	}
	else
	{
		bIsDead = false;
	}
}

#if WITH_EDITOR
// call to implement post edit change property
void UHealthTrackingComponent::PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent)
{
	bIsDead = false;
	Health = 100;

	Super::PostEditChangeProperty(PropertyChangedEvent);

	DeathCheck();
}

#endif

