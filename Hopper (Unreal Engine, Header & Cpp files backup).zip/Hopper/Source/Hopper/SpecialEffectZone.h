// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "SpecialEffectZone.generated.h"

UCLASS()
class HOPPER_API ASpecialEffectZone : public AActor
{
	GENERATED_BODY()

public:	
	UPROPERTY(BlueprintReadWrite, EditAnywhere, Category = "Multiplier")
	float EffectMultiplier;

protected:
	// Called when the game starts or when spawned
	virtual void BeginPlay() override;

public:	

	// Sets default values for this actor's properties
	ASpecialEffectZone();

	// Called every frame
	virtual void Tick(float DeltaTime) override;

	// On Overlap
	UFUNCTION(BlueprintNativeEvent)
	void OnStepIn(class AActor* OtherActor);
	UFUNCTION(BlueprintNativeEvent)
	void OnStepOut(class AActor* OtherActor);

	UFUNCTION()
	void HandleBeginOverlap(AActor* Overlapped, AActor* OtherActor);
	UFUNCTION()
	void HandleEndOverlap(AActor* Overlapped, AActor* OtherActor);
	UFUNCTION(BlueprintCallable)
	void SetMeshVisibilityAndCollision(UStaticMeshComponent* Mesh, bool bTurnOn);
};
