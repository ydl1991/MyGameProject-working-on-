// Copyright 1998-2019 Epic Games, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/GameMode.h"
#include "Misc/DateTime.h"
#include "PowerUpManager.h"
#include "HopperGameMode.generated.h"

UCLASS(MinimalAPI)
class AHopperGameMode : public AGameMode
{
	GENERATED_BODY()

private:
	FDateTime m_StartTime;
	//FPowerUpManager PowerUpManager;

public:
	FTransform PlayerOriginalTranform;

public:
	AHopperGameMode();

	virtual void HandleMatchHasStarted() override;
	void Tick(float DeltaTime) override;
	void RestartPlayer(AController* NewPlayer) override;
	UFUNCTION()
	void HandlePawnRespawn(APawn* RespawningActor, AController* PawnController);
	//TSharedPtr<FPowerUpManager> GetPowerUpManager();
};



