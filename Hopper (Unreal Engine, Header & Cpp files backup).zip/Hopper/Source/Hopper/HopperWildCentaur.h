// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Character.h"
#include "HealthTrackingComponent.h"
#include "HopperWildCentaur.generated.h"

UCLASS(Blueprintable)
class HOPPER_API AHopperWildCentaur : public ACharacter
{
	GENERATED_BODY()

	// count seconds
	float SecondCounter;

public:

	// health tracking component
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Health Tracking")
	class UHealthTrackingComponent* HealthTrackingComponent;

	// special effect zone status
	UPROPERTY(Category = "SpecialEffectZone", EditAnywhere, BlueprintReadWrite)
	bool bInIceZone;
	UPROPERTY(Category = "SpecialEffectZone", EditAnywhere, BlueprintReadWrite)
	bool bInExplosionZone;

public:
	// Sets default values for this character's properties
	AHopperWildCentaur();

protected:
	// Called when the game starts or when spawned
	virtual void BeginPlay() override;

public:	
	// Called every frame
	virtual void Tick(float DeltaTime) override;

	// Called to bind functionality to input
	virtual void SetupPlayerInputComponent(class UInputComponent* PlayerInputComponent) override;

	// override take damage function
	virtual float TakeDamage(float Damage, struct FDamageEvent const& DamageEvent, AController* EventInstigator, AActor* DamageCauser) override;

	void ZoneDamage(float Damage);
};
