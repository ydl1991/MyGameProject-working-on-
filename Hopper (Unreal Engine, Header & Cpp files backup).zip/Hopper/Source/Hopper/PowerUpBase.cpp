// Fill out your copyright notice in the Description page of Project Settings.


#include "PowerUpBase.h"
#include "HopperPawn.h"
#include "HopperGameMode.h"
#include "UObject/ConstructorHelpers.h"
#include "Kismet/GameplayStatics.h"
#include "Components/StaticMeshComponent.h"

// Sets default values
APowerUpBase::APowerUpBase()
{
 	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;
	bIsCoolingDown = false;

	PowerUpEvent.AddUObject(this, &APowerUpBase::HandlePowerUpEvent);

	static ConstructorHelpers::FObjectFinder<USoundBase> PicUpSound(TEXT("/Game/Twinstick/Audio/PickUpSound.PickUpSound"));
	PowerupPickupSound = PicUpSound.Object;
	static ConstructorHelpers::FObjectFinder<USoundBase> SoundWhenPowerUp(TEXT("/Game/Twinstick/Audio/PowerUpSound.PowerUpSound"));
	PowerupSound = SoundWhenPowerUp.Object;
}

// Called when the game starts or when spawned
void APowerUpBase::BeginPlay()
{
	Super::BeginPlay();
	
	// this transfers the function into delegate, it's slower than just create a delegate
	OnActorBeginOverlap.AddDynamic(this, &APowerUpBase::HandleBeginOverlap);

	//// get the game mode, and cast it
	//AHopperGameMode* Mode = GetWorld()->GetAuthGameMode<AHopperGameMode>();
	//// store a ref to the manager
	//ManagerRef = Mode->GetPowerUpManager();
}

void APowerUpBase::HandlePowerUpEvent_Implementation()
{
}

// Called every frame
void APowerUpBase::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

	if (bIsCoolingDown)
	{
		Timer -= DeltaTime;

		if (Timer <= 0)
		{
			OnPowerupReset.Broadcast();
			bIsCoolingDown = false;
		}
	}
}

//void APowerUpBase::OnReset_Implementation()
//{
//	UE_LOG(LogTemp, Log, TEXT("Reset........................"));
//}

void APowerUpBase::HandleBeginOverlap(AActor* Overlapped, AActor* OtherObejct)
{
	AHopperPawn* Player = Cast<AHopperPawn>(OtherObejct);
	if (Player)
	{
		// play sounds when pick up and power up
		if (PowerupPickupSound)
		{
			UGameplayStatics::PlaySoundAtLocation(this, PowerupPickupSound, GetActorLocation());
		}
		if (PowerupSound)
		{
			UGameplayStatics::PlaySoundAtLocation(Player, PowerupSound, Player->GetActorLocation());
		}
		// execute pick up event
		OnPowerupPickUp.Broadcast(Player);
		// send the event
		//OnPickup(Player);

		bIsCoolingDown = true;
		Timer = RegenTime;

		UE_LOG(LogTemp, Log, TEXT("Sending Onpickup event........................"));
	}

}

void APowerUpBase::SetMeshVisibilityAndCollision(UStaticMeshComponent* Mesh, bool bTurnOn)
{
	UE_LOG(LogTemp, Log, TEXT("reseting!!!........................"));
	Mesh->SetVisibility(bTurnOn);

	auto collisionType = bTurnOn ? ECollisionEnabled::QueryAndPhysics : ECollisionEnabled::NoCollision;
	Mesh->SetCollisionEnabled(collisionType);
}

//void APowerUpBase::OnPickup_Implementation(AHopperPawn* Player)
//{
//	UE_LOG(LogTemp, Log, TEXT("A powerup has been picked up........................"));
//}

