// Fill out your copyright notice in the Description page of Project Settings.

#include "SpecialEffectZone.h"
#include "HopperPawn.h"
#include "Components/StaticMeshComponent.h"

// Sets default values
ASpecialEffectZone::ASpecialEffectZone()
{
 	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;

	EffectMultiplier = 1.f;
}

// Called when the game starts or when spawned
void ASpecialEffectZone::BeginPlay()
{
	Super::BeginPlay();
	
	OnActorBeginOverlap.AddDynamic(this, &ASpecialEffectZone::HandleBeginOverlap);
	OnActorEndOverlap.AddDynamic(this, &ASpecialEffectZone::HandleEndOverlap);
}

// Called every frame
void ASpecialEffectZone::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

}

void ASpecialEffectZone::OnStepIn_Implementation(AActor* OtherActor)
{
	UE_LOG(LogTemp, Log, TEXT("Object Entering into a Special Effect Zone........................"));

}

void ASpecialEffectZone::OnStepOut_Implementation(AActor* OtherActor)
{
	UE_LOG(LogTemp, Log, TEXT("Object Stepping out of a Special Effect Zone........................"));
}

// call to handle overlap
void ASpecialEffectZone::HandleBeginOverlap(AActor* Overlapped, AActor* OtherActor)
{
	OnStepIn(OtherActor);
}

void ASpecialEffectZone::HandleEndOverlap(AActor* Overlapped, AActor* OtherActor)
{
	OnStepOut(OtherActor);
}

void ASpecialEffectZone::SetMeshVisibilityAndCollision(UStaticMeshComponent* Mesh, bool bTurnOn)
{
	Mesh->SetVisibility(bTurnOn);

	auto collisionType = bTurnOn ? ECollisionEnabled::QueryAndPhysics : ECollisionEnabled::NoCollision;
	Mesh->SetCollisionEnabled(collisionType);
}

