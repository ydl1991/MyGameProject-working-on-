// Fill out your copyright notice in the Description page of Project Settings.


#include "PingTrigger.h"
#include "UObject/ConstructorHelpers.h"
#include "HopperPawn.h"
#include "Components/StaticMeshComponent.h"
#include "Engine/StaticMesh.h"
#include "Engine/GameEngine.h"
#include "Materials/MaterialInstanceDynamic.h"
#include "HopperPawn.h"
#include <EngineGlobals.h>
#include <Runtime/Engine/Classes/Engine/Engine.h>

// Sets default values
APingTrigger::APingTrigger()
{
 	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;
	// set default scene component and static mesh
	static ConstructorHelpers::FObjectFinder<UStaticMesh> PingMesh(TEXT("/Game/StarterContent/Architecture/SM_AssetPlatform.SM_AssetPlatform"));
	PingTriggerMeshComponent = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("PingTrigger"));
	SetRootComponent(PingTriggerMeshComponent);
	PingTriggerMeshComponent->SetStaticMesh(PingMesh.Object);

	// set material
	static ConstructorHelpers::FObjectFinder<UMaterial> MatalicMaterial(TEXT("/Game/TwinStick/Material/PingTrigger_Mat.PingTrigger_Mat"));
	PingTriggerMeshComponent->SetMaterial(0, MatalicMaterial.Object);

	// set default collision component
	BoxCollision = CreateDefaultSubobject<UBoxComponent>(TEXT("BoxCollision"));
	BoxCollision->SetBoxExtent(FVector(600.f, 600.f, 10.f));
	BoxCollision->SetupAttachment(RootComponent);

	// initialize last time to 10 second
	LastTime = 5.f;
}

// Called when the game starts or when spawned
void APingTrigger::BeginPlay()
{
	Super::BeginPlay();
	
	OnActorBeginOverlap.AddDynamic(this, &APingTrigger::HandleBeginOverlap);
	OnPingBeingOverlap.AddDynamic(this, &APingTrigger::Alarm);
}

// Called every frame
void APingTrigger::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);
	// timer count down
	LastTime -= DeltaTime;
	
}

void APingTrigger::HandleBeginOverlap(AActor* Box, AActor* OtherActor)
{
	AHopperPawn* EnemyPlayer = Cast<AHopperPawn>(OtherActor);
	if (EnemyPlayer)
	{
		OnPingBeingOverlap.Broadcast(EnemyPlayer);
	}
}

void APingTrigger::Alarm(AHopperPawn* OverlapPlayer)
{
	UE_LOG(LogTemp, Log, TEXT("Invasion Detected!"));
	if (GEngine)
	{
		FVector EnemyLocation = OverlapPlayer->GetActorLocation();
		GEngine->AddOnScreenDebugMessage(-1, 15.0f, FColor::Red, FString::Printf(TEXT("Invader detected at location : %d %d %d"), static_cast<int>(EnemyLocation.X), static_cast<int>(EnemyLocation.Y), static_cast<int>(EnemyLocation.Z)));
	}
}

