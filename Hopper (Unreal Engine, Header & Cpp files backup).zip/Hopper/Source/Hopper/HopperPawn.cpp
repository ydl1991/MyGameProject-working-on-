// Copyright 1998-2019 Epic Games, Inc. All Rights Reserved.

#include "HopperPawn.h"
#include "HopperProjectile.h"
#include "TimerManager.h"
#include "UObject/ConstructorHelpers.h"
#include "Camera/CameraComponent.h"
#include "Components/StaticMeshComponent.h"
#include "Components/InputComponent.h"
#include "Engine/GameEngine.h"
#include "GameFramework/SpringArmComponent.h"
#include "Engine/CollisionProfile.h"
#include "Engine/StaticMesh.h"
#include "Kismet/GameplayStatics.h"
#include "Sound/SoundBase.h"

const FName AHopperPawn::MoveForwardBinding("MoveForward");
const FName AHopperPawn::MoveRightBinding("MoveRight");
const FName AHopperPawn::FireForwardBinding("FireForward");
const FName AHopperPawn::FireRightBinding("FireRight");
const FName AHopperPawn::DropPingTriggerBinding("DropPingTrigger");

AHopperPawn::AHopperPawn()
{	
	static ConstructorHelpers::FObjectFinder<UStaticMesh> ShipMesh(TEXT("/Game/TwinStick/Meshes/TwinStickUFO.TwinStickUFO"));
	// Create the mesh component
	ShipMeshComponent = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("ShipMesh"));
	RootComponent = ShipMeshComponent;
	ShipMeshComponent->SetCollisionProfileName(UCollisionProfile::Pawn_ProfileName);
	ShipMeshComponent->SetStaticMesh(ShipMesh.Object);
	
	// Cache our sound effect
	static ConstructorHelpers::FObjectFinder<USoundBase> FireAudio(TEXT("/Game/TwinStick/Audio/TwinStickFire.TwinStickFire"));
	FireSound = FireAudio.Object;
	static ConstructorHelpers::FObjectFinder<USoundBase> LaserFireAudio(TEXT("/Game/TwinStick/Audio/LaserFireSound.LaserFireSound"));
	LaserFireSound = LaserFireAudio.Object;
	static ConstructorHelpers::FObjectFinder<USoundBase> PingDropAudio(TEXT("/Game/TwinStick/Audio/PingDrop.PingDrop"));
	DropPingSound = PingDropAudio.Object;

	// Create a camera boom...
	CameraBoom = CreateDefaultSubobject<USpringArmComponent>(TEXT("CameraBoom"));
	CameraBoom->SetupAttachment(RootComponent);
	CameraBoom->bAbsoluteRotation = true; // Don't want arm to rotate when ship does
	CameraBoom->TargetArmLength = 1200.f;
	CameraBoom->RelativeRotation = FRotator(-80.f, 0.f, 0.f);
	CameraBoom->bDoCollisionTest = false; // Don't want to pull camera in when it collides with level

	// Create a camera...
	CameraComponent = CreateDefaultSubobject<UCameraComponent>(TEXT("TopDownCamera"));
	CameraComponent->SetupAttachment(CameraBoom, USpringArmComponent::SocketName);
	CameraComponent->bUsePawnControlRotation = false;	// Camera does not rotate relative to arm

	// Health Tracking
	HealthTrackingComponent = CreateDefaultSubobject<UHealthTrackingComponent>(TEXT("Health Tracking"));

	// Movement
	MoveSpeed = 1000.0f;

	// Weapon
	GunOffset = FVector(115.f, 0.f, 0.f);
	FireRate = 0.3f;
	bCanFire = true;
	bLaserActivated = false;

	//bullet count initializing
	BulletCounter.Emplace(TEXT("Normal Shot"), 0);
	BulletCounter.Emplace(TEXT("Laser Shot"), 0);

	// initialize special effect zone status
	bInIceZone = false;
	bInExplosionZone = false;

	// second counter initialization
	SecondCounter = 0;

	// set respawn timer to 2 second;
	RespawnTimer = 2.f;
	// TcircularQueue for ping trigger
	PingTriggerQueue = nullptr;
}

void AHopperPawn::BeginPlay()
{
	Super::BeginPlay();

	// set container
	PingTriggerQueue = MakeShareable(new PingQueue(6));

	// get game mode pointer
	if (GetWorld())
	{
		HopperGameMode = GetWorld()->GetAuthGameMode<AHopperGameMode>();
	}

	HopperGameMode->PlayerOriginalTranform = GetActorTransform();
	RespawnWhenDead.BindUObject(HopperGameMode, &AHopperGameMode::HandlePawnRespawn);
}

void AHopperPawn::SetupPlayerInputComponent(class UInputComponent* PlayerInputComponent)
{
	check(PlayerInputComponent);
	Super::SetupPlayerInputComponent(PlayerInputComponent);

	// set up gameplay key bindings
	PlayerInputComponent->BindAxis(MoveForwardBinding);
	PlayerInputComponent->BindAxis(MoveRightBinding);
	PlayerInputComponent->BindAxis(FireForwardBinding);
	PlayerInputComponent->BindAxis(FireRightBinding);
	PlayerInputComponent->BindAction(DropPingTriggerBinding, EInputEvent::IE_Pressed, this, &AHopperPawn::DropPingTrigger);
	
}

void AHopperPawn::Tick(float DeltaSeconds)
{
	// moving actor
	{
		// Find movement direction
		const float ForwardValue = GetInputAxisValue(MoveForwardBinding);
		const float RightValue = GetInputAxisValue(MoveRightBinding);

		// Clamp max size so that (X=1, Y=1) doesn't cause faster movement in diagonal directions
		const FVector MoveDirection = FVector(ForwardValue, RightValue, 0.f).GetClampedToMaxSize(1.0f);

		// Calculate  movement
		const FVector Movement = MoveDirection * MoveSpeed * DeltaSeconds;

		// If non-zero size, move this actor
		if (Movement.SizeSquared() > 0.0f)
		{
			const FRotator NewRotation = Movement.Rotation();
			FHitResult Hit(1.f);
			RootComponent->MoveComponent(Movement, NewRotation, true, &Hit);

			if (Hit.IsValidBlockingHit())
			{
				const FVector Normal2D = Hit.Normal.GetSafeNormal2D();
				const FVector Deflection = FVector::VectorPlaneProject(Movement, Normal2D) * (1.f - Hit.Time);
				RootComponent->MoveComponent(Deflection, NewRotation, true);
			}
		}
	}

	// firing projectile
	{
		// Create fire direction vector
		const float FireForwardValue = GetInputAxisValue(FireForwardBinding);
		const float FireRightValue = GetInputAxisValue(FireRightBinding);
		const FVector FireDirection = FVector(FireForwardValue, FireRightValue, 0.f);

		// Try and fire a shot
		FireShot(FireDirection);
	}

	// check zone speeding effects
	{
		const float OriginalSpeed = 1000.f;
		MoveSpeed = SlowEffect(0.5, OriginalSpeed);
		MoveSpeed = SpeedingEffect(2, MoveSpeed);

		// check zone damages apply
		SecondCounter += DeltaSeconds;
		if (SecondCounter > 1.f)
		{
			SecondCounter -= 1.f;
			ZoneDamage(10);
		}
	}

	// respawn new hopper pawn and destroy old hopper pawn if dead;
	{
		if (HealthTrackingComponent->bIsDead)
		{
			AController* Controller = GetController();
			// when pawm die, disable mash visibility, collision and input
			TurnOffMeshVisibilityAndCollision(this->ShipMeshComponent);
			DisableInput(Cast<APlayerController>(Controller));
			RespawnTimer -= DeltaSeconds;

			if (RespawnTimer <= 0)
			{
				// after respawn time, call function to respawn
				RespawnWhenDead.Execute(this, Controller);
				HopperGameMode = nullptr;
				Destroy();
			}
		}
	}

	// check if ping trigger device is expired
	CheckPingTriggerExpire();
}

void AHopperPawn::FireShot(FVector FireDirection)
{
	// If it's ok to fire again
	if (bCanFire == true)
	{
		// If we are pressing fire stick in a direction
		if (FireDirection.SizeSquared() > 0.0f)
		{
			const FRotator FireRotation = FireDirection.Rotation();

			UWorld* const World = GetWorld();
			if (World != NULL)
			{
				// spawn the projectile
				FActorSpawnParameters SpawnParams;
				SpawnParams.Instigator = this;
		
				if (HasLaser())
				{
					// Spawn projectiles at an offset from this pawn
					GunOffset = FVector(110.f, 65.f, 0.f);
					const FVector SpawnLocationOne = GetActorLocation() + FireRotation.RotateVector(GunOffset);
					GunOffset = FVector(110.f, -65.f, 0.f);
					const FVector SpawnLocationTwo = GetActorLocation() + FireRotation.RotateVector(GunOffset);

					AHopperProjectile* HopperProjectileOne = World->SpawnActor<AHopperProjectile>(SpawnLocationOne, FireRotation, SpawnParams);
					AHopperProjectile* HopperProjectileTwo = World->SpawnActor<AHopperProjectile>(SpawnLocationTwo, FireRotation, SpawnParams);

					// change projectile outlook
					HopperProjectileOne->ChangeWeapon();
					HopperProjectileTwo->ChangeWeapon();

					// strangthen the fire rate
					FireRate = 0.05f;

					// count bullet
					BulletCounter[TEXT("Laser Shot")] += 2;
					if (GEngine)
					{
						GEngine->AddOnScreenDebugMessage(-1, 5.0f, FColor::Yellow, FString::Printf(TEXT("Laser Bullet Fired: %d"), BulletCounter[TEXT("Laser Shot")]));
					}

					// try and play the sound if specified
					if (LaserFireSound != nullptr)
					{
						UGameplayStatics::PlaySoundAtLocation(this, LaserFireSound, GetActorLocation());
					}
				}
				else
				{
					// Spawn projectile at an offset from this pawn
					GunOffset = FVector(115.f, 0.f, 0.f);
					const FVector SpawnLocation = GetActorLocation() + FireRotation.RotateVector(GunOffset);

					World->SpawnActor<AHopperProjectile>(SpawnLocation, FireRotation, SpawnParams);
					FireRate = 0.3f;

					// count bullet
					BulletCounter[TEXT("Normal Shot")] += 1;
					if (GEngine)
					{
						GEngine->AddOnScreenDebugMessage(-1, 5.0f, FColor::Yellow, FString::Printf(TEXT("Normal Bullet Fired: %d"), BulletCounter[TEXT("Normal Shot")]));
					}

					// try and play the sound if specified
					if (FireSound != nullptr)
					{
						UGameplayStatics::PlaySoundAtLocation(this, FireSound, GetActorLocation());
					}
				}
			}

			bCanFire = false;
			World->GetTimerManager().SetTimer(TimerHandle_ShotTimerExpired, this, &AHopperPawn::ShotTimerExpired, FireRate);

			bCanFire = false;
		}
	}
}

void AHopperPawn::ShotTimerExpired()
{
	bCanFire = true;
}

// call to spawn a ping trigger on the map
void AHopperPawn::DropPingTrigger()
{
	// if Queue is full, delete the first ping
	if (PingTriggerQueue.Get()->Count() >= 5)
	{
		APingTrigger* Temp = nullptr;
		PingTriggerQueue.Get()->Dequeue(Temp);
		Temp->Destroy();
		Temp = nullptr;
	}

	// Spawning process
	{
		UE_LOG(LogTemp, Log, TEXT("Drop a ping trigger!!!!!!!!!"));
		UWorld* const World = GetWorld();
		const FVector SpawnLocation = this->GetActorLocation() + FVector{ 0.f, 0.f, -60.f };
		const FRotator SpawnRotation = this->GetActorRotation();
		const FVector Scaler = { .5f,0.5f, 3.f };
		FTransform TempTrans = FTransform{ SpawnRotation , SpawnLocation , Scaler };

		// spawn the Ping
		FActorSpawnParameters SpawnParams;
		SpawnParams.Instigator = this;
		PingTriggerQueue.Get()->Enqueue(World->SpawnActor<APingTrigger>(APingTrigger::StaticClass(), TempTrans, SpawnParams));

		// try and play the sound if specified
		if (DropPingSound != nullptr)
		{
			UGameplayStatics::PlaySoundAtLocation(this, DropPingSound, GetActorLocation());
		}
	}
}

//call to check expiration and delete expired ping trigger
void AHopperPawn::CheckPingTriggerExpire()
{
	APingTrigger* Temp = nullptr;
	bool bValid = PingTriggerQueue.Get()->Peek(Temp);
	if (bValid && (Temp->GetLastTime() <= 0))
	{
		PingTriggerQueue.Get()->Dequeue(Temp);
		Temp->Destroy();
		Temp = nullptr;
	}
}

// call to check if special zone damage applied
void AHopperPawn::ZoneDamage(float Damage)
{
	if (bInExplosionZone)
	{
		HealthTrackingComponent->HealthCheck(-Damage);
		if (GEngine)
		{
			GEngine->AddOnScreenDebugMessage(-1, 5.0f, FColor::Red, FString::Printf(TEXT("HopperPawn Health: %f"), HealthTrackingComponent->Health));
		}
	}
}

// call to turn off mesh and collision
void AHopperPawn::TurnOffMeshVisibilityAndCollision(UStaticMeshComponent* Mesh)
{
	// set mesh invisible and no collision at all
	Mesh->SetVisibility(false);
	Mesh->SetCollisionEnabled(ECollisionEnabled::NoCollision);
}
