// Fill out your copyright notice in the Description page of Project Settings.

#include "HopperEnemy.h"
#include "Hopper.h"
#include "HopperPawn.h"
#include "HopperProjectile.h"
#include "TimerManager.h"
#include "UObject/ConstructorHelpers.h"
#include "Camera/CameraComponent.h"
#include "Components/StaticMeshComponent.h"
#include "Components/InputComponent.h"
#include "Engine/GameEngine.h"
#include "GameFramework/SpringArmComponent.h"
#include "Engine/CollisionProfile.h"
#include "Engine/StaticMesh.h"
#include "Kismet/GameplayStatics.h"
#include "Sound/SoundBase.h"

// Sets default values
AHopperEnemy::AHopperEnemy()
{
	static ConstructorHelpers::FObjectFinder<UStaticMesh> ShipMesh(TEXT("/Game/TwinStick/Meshes/TwinStickUFO.TwinStickUFO"));
	// Create the mesh component
	ShipMeshComponent = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("ShipMesh"));
	RootComponent = ShipMeshComponent;
	ShipMeshComponent->SetCollisionProfileName(UCollisionProfile::Pawn_ProfileName);
	ShipMeshComponent->SetStaticMesh(ShipMesh.Object);

	// Health Component
	HealthTrackingComponent = CreateDefaultSubobject<UHealthTrackingComponent>(TEXT("HealthTrack"));
	
	//ShipMeshComponent->SetMaterial(0, Cast<UMaterialInterface>(StartingMaterial.Get()));

 	// Set this pawn to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;

	// initialize special effect zone status
	bInIceZone = false;
	bInExplosionZone = false;
	// second counter initialization
	SecondCounter = 0;
}

// Called when the game starts or when spawned
void AHopperEnemy::BeginPlay()
{
	Super::BeginPlay();
	
	UE_LOG(LogTemp, Log, TEXT("HopperEnermy: BeginPlay!"));
}

// Called every frame
void AHopperEnemy::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);
	if (!bTicked)
	{
		UE_LOG(LogTemp, Log, TEXT("HopperEnermy"), DeltaTime);
		bTicked = true;
	}

	// check zone damages apply
	SecondCounter += DeltaTime;
	if (SecondCounter > 1.f)
	{
		SecondCounter -= 1.f;
		ZoneDamage(10);
	}
}

// Called to bind functionality to input
void AHopperEnemy::SetupPlayerInputComponent(UInputComponent* PlayerInputComponent)
{
	Super::SetupPlayerInputComponent(PlayerInputComponent);
}

float AHopperEnemy::TakeDamage(float Damage, FDamageEvent const & DamageEvent, AController * EventInstigator, AActor * DamageCauser)
{
	Super::TakeDamage(Damage, DamageEvent, EventInstigator, DamageCauser);

	// Using log to test
	UE_LOG(LogHopperEnemy, Log, TEXT("Calculating Damage ...."));

	HealthTrackingComponent->HealthCheck(-Damage);

	return 0.0f;
}

void AHopperEnemy::ZoneDamage(float Damage)
{
	if (bInExplosionZone)
	{
		HealthTrackingComponent->HealthCheck(-Damage);
		if (GEngine)
		{
			GEngine->AddOnScreenDebugMessage(-1, 5.0f, FColor::Red, FString::Printf(TEXT("HopperEnemy Health: %f"), HealthTrackingComponent->Health));
		}
	}
}
