// Copyright 1998-2019 Epic Games, Inc. All Rights Reserved.

#include "HopperGameMode.h"
#include "Engine/World.h"
#include "Kismet/GameplayStatics.h"
#include "HopperPawn.h"

AHopperGameMode::AHopperGameMode()
{
	// set default pawn class to our character class
	DefaultPawnClass = AHopperPawn::StaticClass();
}

void AHopperGameMode::HandleMatchHasStarted()
{
	Super::HandleMatchHasStarted();

	// store match start times tamp as member
	m_StartTime = FDateTime::Now();

	// log the timestamp
	UE_LOG(LogTemp, Log, TEXT("Match started at : %s"), *m_StartTime.ToString())
}

void AHopperGameMode::Tick(float DeltaTime)
{
	//PowerUpManager.Tick(DeltaTime);
}

void AHopperGameMode::RestartPlayer(AController* NewPlayer)
{
	Super::RestartPlayer(NewPlayer);
}

void AHopperGameMode::HandlePawnRespawn(APawn* RespawningPawn, AController* PawnController)
{
	if (PawnController->IsPlayerController())
	{
		Cast<APlayerController>(PawnController)->ServerRestartPlayer();
		RespawningPawn->PawnClientRestart();
		// Don't allow pawn to be spawned with any pitch or roll
		UClass* PawnClass = RespawningPawn->GetClass();
		ESpawnActorCollisionHandlingMethod const CollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;
		APawn* ResultPawn = Cast<APawn>(UGameplayStatics::BeginDeferredActorSpawnFromClass(this, PawnClass, PlayerOriginalTranform, CollisionHandlingOverride));
		if (ResultPawn)
		{
			UGameplayStatics::FinishSpawningActor(ResultPawn, PlayerOriginalTranform);
		}
		PawnController->Possess(ResultPawn);
	}
	else
	{
		FActorSpawnParameters SpawnInfo;
		FTransform PawnTranform = RespawningPawn->GetTransform();
		SpawnInfo.Instigator = RespawningPawn->GetInstigator();
		SpawnInfo.ObjectFlags |= RF_Transient;	// We never want to save default player pawns into a map
		UClass* PawnClass = RespawningPawn->GetClass();
		APawn* ResultPawn = GetWorld()->SpawnActor<APawn>(PawnClass, PawnTranform, SpawnInfo);
		if (!ResultPawn)
		{
			UE_LOG(LogGameMode, Warning, TEXT("SpawnDefaultPawnAtTransform: Couldn't spawn Pawn of type %s at %s"), *GetNameSafe(PawnClass), *PawnTranform.ToHumanReadableString());
		}
		PawnController->SetPawn(ResultPawn);
		PawnController->Possess(ResultPawn);
	}
}

//TSharedPtr<FPowerUpManager> AHopperGameMode::GetPowerUpManager()
//{
//	return MakeShareable<FPowerUpManager>(&PowerUpManager);
//}
