// Fill out your copyright notice in the Description page of Project Settings.

#include "HopperWildCentaur.h"
#include "Engine/GameEngine.h"

// Sets default values
AHopperWildCentaur::AHopperWildCentaur()
{
	HealthTrackingComponent = CreateDefaultSubobject<UHealthTrackingComponent>(TEXT("Health Tracking"));

 	// Set this character to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;

	// initialize special effect zone status
	bInIceZone = false;
	bInExplosionZone = false;
	// second counter initialization
	SecondCounter = 0;
}

// Called when the game starts or when spawned
void AHopperWildCentaur::BeginPlay()
{
	Super::BeginPlay();
	
}

// Called every frame
void AHopperWildCentaur::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

	// check zone damages apply
	SecondCounter += DeltaTime;
	if (SecondCounter > 1.f)
	{
		SecondCounter -= 1.f;
		ZoneDamage(10);
	}

}

// Called to bind functionality to input
void AHopperWildCentaur::SetupPlayerInputComponent(UInputComponent* PlayerInputComponent)
{
	Super::SetupPlayerInputComponent(PlayerInputComponent);

}

float AHopperWildCentaur::TakeDamage(float Damage, FDamageEvent const & DamageEvent, AController * EventInstigator, AActor * DamageCauser)
{
	HealthTrackingComponent->HealthCheck(-Damage);

	return 0.0f;
}

void AHopperWildCentaur::ZoneDamage(float Damage)
{
	if (bInExplosionZone)
	{
		HealthTrackingComponent->HealthCheck(-Damage);
		if (GEngine)
		{
			GEngine->AddOnScreenDebugMessage(-1, 5.0f, FColor::Red, FString::Printf(TEXT("HopperCentaur Health: %f"), HealthTrackingComponent->Health));
		}
	}
}
