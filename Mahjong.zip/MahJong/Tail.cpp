#include "Tail.h"


Tail::Tail() {}

Tail::Tail(int rank, string suit)
	: m_FaceState(nullptr)
	, m_tailState(FaceDown)
	, m_tailRank(rank)
	, m_tailSuit(suit)
{
}

Tail::~Tail()
{
}

int Tail::GetRank()
{
	return m_tailRank;
}

string Tail::GetSuit()
{
	return m_tailSuit;
}

void Tail::SetTailState(TileState t)
{
	m_tailState = t;
}

void Tail::Show()
{
	if (m_tailState == FaceDown)
	{
		m_FaceState = FuncDown();
	}
	else if(m_tailState == FaceUp)
		m_FaceState = FuncUp();
}

auto Tail::FuncDown() -> tFaceState
{
		cout << " =";
		return m_FaceState;
}

auto Tail::FuncUp()-> tFaceState
{
	cout << m_tailSuit;
	cout << m_tailRank;
	return m_FaceState;
}

