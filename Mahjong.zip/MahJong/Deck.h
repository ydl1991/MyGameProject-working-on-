#pragma once
#include<iostream>
#include<vector>
#include<string>
#include<algorithm>
#include"Player.h"
#include"Tail.h"

enum WhereToDraw
{
	front,
	back
};
using namespace std;

class Deck
{
public:
	Deck();
	~Deck();

	void CreateTails();
	void Shuffle();
	void Draw(Player* player[], WhereToDraw);
	//void Show();

private:
	vector<Tail> m_tails;
};

