#include "Deck.h"

Deck::Deck()
	:m_tails{}
{
}

Deck::~Deck()
{
}

void Deck::CreateTails()
{
	int ranks[9] = { 1, 2, 3, 4, 5, 6, 7, 8, 9 };
	// the suits include "Bamboo", "Charactor" and "Dot", but for eazy reading I will just use "B","C","D" here instead.
	string suits[3] = { "B", "C", "D" };

	// each tile has a rank and suit, and there is 4 of each tile
	for (int i = 0; i < 9; ++i)
	{
		for (int j = 0; j < 3; ++j)
		{
			m_tails.emplace_back(Tail(ranks[i], suits[j]));
			m_tails.emplace_back(Tail(ranks[i], suits[j]));
			m_tails.emplace_back(Tail(ranks[i], suits[j]));
			m_tails.emplace_back(Tail(ranks[i], suits[j]));
		}
	}
}

void Deck::Shuffle()
{
	random_shuffle(this->m_tails.begin(), this->m_tails.end());
}

void Deck::Draw(Player* player[], WhereToDraw w)
{
	if (this->m_tails.size() == 108)
	{
		for (int i = 0; i < 48; ++i)
		{
			//at the begining, each player gets 4 tiles for 3 rounds
			int playerTerm = (i / 4) % 4;
			player[playerTerm]->DrawTail(this->m_tails[i]);
		}

		// each player collects one of the 4 tails after 3 rounds
		player[0]->DrawTail(this->m_tails[48]);
		player[1]->DrawTail(this->m_tails[49]);
		player[2]->DrawTail(this->m_tails[50]);
		player[3]->DrawTail(this->m_tails[51]);

		//erase the first 52 tails that have been assigned.
		this->m_tails.erase(this->m_tails.begin(), this->m_tails.begin() + 52);
	}
	else if (this->m_tails.size() == 0)
	{
		cout << "No more tails in stock!" << endl << endl;
	}
	else
	{
		if (w == front)
		{
			for (int i = 0; i < 4; ++i)
			{
				if (player[i]->GetPlayerState() == Active)
				{
					player[i]->DrawTail(this->m_tails[0]);
					cout << endl;
					cout << "Player " << player[i]->GetPlayerNumber() << " draws a tail from the deck!" << endl << endl;
				}
			}
			this->m_tails.erase(this->m_tails.begin());
		}
		else
		{
			for (int i = 0; i < 4; ++i)
			{
				if (player[i]->GetPlayerState() == Active)
				{
					size_t s = m_tails.size();
					player[i]->DrawTail(this->m_tails[s - 1]);
					cout << endl;
					cout << "Player " << player[i]->GetPlayerNumber() << " draws a tail from the deck!" << endl << endl;
				}
			}
			this->m_tails.pop_back();
		}
	}
}

