#pragma once
#include<iostream>
#include<vector>
#include<string>
#include<algorithm>

typedef void(*tFaceState)();

enum TileState
{
	FaceDown,
	FaceUp,
};

using namespace std;

class Tail
{
	tFaceState m_FaceState;
public:
	Tail();
	Tail(int rank, string suit);
	~Tail();

	int GetRank();
	string GetSuit();
	void SetTailState(TileState t);
	void Show();
	auto FuncDown()->tFaceState;
	auto FuncUp()->tFaceState;

	// member operator
	bool operator==(Tail rhs) 
	{ 
		if (this->m_tailSuit == rhs.m_tailSuit && this->m_tailRank == rhs.m_tailRank)
			return true;
		else
			return false;
	};

private:
	int m_tailRank;
	string m_tailSuit;
	TileState m_tailState;
};

