#pragma once
#include <array>
#include "Deck.h"
#include "Player.h"
#include "BotPlayer.h"
#include "Tail.h"
#include "TailOnTable.h"

class Game
{
public:
	//member
	Deck m_deck;
	Player *m_pPlayer[4];
	TailOnTable *m_pTable[20][20];

	//singlton function
	static Game* GetGame();

	//basic functions
	bool CheckWinner();
	void InitializingGame();
	void PrintTable();
	void ClearTable();
	void PlayerChange();
	void AssignPlayerHandOnTable();
	void ComparePlayerEventsCall();
	void ResetPlayerEvents();
	void ClearClaimedDiscardTail();

	//getters setters
	void SetAndAssignDiscardTail(Tail* t);
	Tail* GetDiscardTail();
	Player* GetActivePlayer();

private:
	//singlton game instance
	static Game* m_pGame;

	//private member
	Tail *m_pCurrentDiscardTail;
	Player *m_pActivePlayer;

	//private constructor
	Game();
	~Game();
};


