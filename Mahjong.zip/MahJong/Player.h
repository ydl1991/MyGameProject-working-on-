#pragma once
#include<iostream>
#include<vector>
#include<string>
#include<algorithm>
#include<utility>
#include<functional>
#include"KongSet.h"
#include"Combo3Set.h"
#include"Tail.h"

enum PlayerState
{
	Inactive,
	Active,
	Won
};

enum EventsName
{
	None = 0,
	Chow,
	Pong,
	Kong,
	MahJong
};

using namespace std;

class Player
{
protected:
	//basic protected member variable
	EventsName m_currentEventCalled;
	PlayerState m_playerState;
	int m_playerNumber;

	// member variable that triggers MahJONG (WIN), NOTE: 3 tail combo includes Pong and Chow
	size_t m_nKong;
	size_t m_n3TailCombo;
	int m_nPair;

	//Tail related protected variable
	Tail* m_pDiscardTail;
	vector<Tail> m_PlayerTails;

	// create a vector that store Events
	vector<pair<EventsName, function<void(vector<Tail>&, Tail*, vector<KongSet>&, vector<Combo3Set>&)>>> m_events;

public:
	//constructors and destructor
	Player();
	Player(int);
	~Player();

	//member variable
	vector<KongSet> m_vKong;
	vector<Combo3Set> m_v3TailCombo;

	//basic functions
	void SortTails();
	void DrawTail(Tail &tail);
	void ShowPlayerDeck();
	Tail RetrievePlayerDeckByIndex(int i);


	//getters
	EventsName GetCurrentEventCalled();
	PlayerState GetPlayerState();
	vector<Tail> GetPlayerHands();
	int GetPlayerNumber();

	//setters
	void SetCurrentEventCalled(EventsName);
	void SetPlayerState(PlayerState state);

	//Tail related functions
	virtual Tail* Discard();
	void Claim(Tail *currentDiscardTail);

	//controller related functions, eg. set what the controller can do and how it runs different events by user choice
	void SetController();
	virtual void EventController(Tail *currentDiscardTail, Player *currentActivePlayer);
	void EventExecutor(Tail *currentDiscardTail, int);

protected:
	//Win check related functions
	void CountHand();
	bool CheckChow(Tail *currentDiscardTail, Player *currentActivePlayer);
	bool CheckPong(Tail *currentDiscardTail);
	bool CheckKong(Tail *currentDiscardTail);
	bool CheckPair(Tail *currentDiscardTail);
	bool CheckMahJongWithDiscardTail(Tail *currentDiscardTail, Player *currentActivePlayer);
	bool CheckMahJongWithDrawTail();
};
