#pragma once
#include "Tail.h"
class TailOnTable
{
public:
	TailOnTable(Tail);
	~TailOnTable();

	Tail m_tail;
};

