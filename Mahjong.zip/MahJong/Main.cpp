////Objective of the Game
////tive of the game is to collect tiles to form a Mahjong hand. Players take turns picking one tile from the wall and discarding one tile. When a player picks up a tile that gives a valid Mahjong hand, the player wins.
//Tiles
//A easy version of mahjoon contains 108 tiles. There are three suits: Bamboo, Characters and Dots. Each suit has tiles numbered one to nine. There is four of each tile. 
//Game Flow
//Players start with 13 tiles each. East starts the game by picking a tile from the wall. Players then take counter-clockwise turns picking a tile from the wall and then discarding one tile from the hand. It is also possible to claim a tile discarded by another player under certain circumstances. In such cases, the player to the right of the claiming player becomes next in turn so some players may lose their turn in a go-around.
//Players shall always have a total of 13 tiles in hand and/or declared, until Mahjong is declared. (A Mahjong hand contains 14 tiles.)
//In games that consist of several hands, the concept of prevalent wind is used. The game will then consist of one to four rounds, each with a prevalent wind (starting with east). In a round, players switch winds after each hand (with some exceptions in some rule sets), i.e. the player who was east becomes south, south becomes west and so on until all players have played as east. When the round is finished, the prevalent wind is changed (from east to west, west to south, south to north) and a new round starts. The prevalent wind is shown in the middle of the table.
//Claiming Tiles
//A player may claim a discarded tile from the player to his left (i.e. if the claiming player is next in turn) to declare a chow (a three-tile same-suit straight).
//A player may claim a discarded tile from any other player to declare a kong (four-of-a-kind) or pong (three-of-a-kind).
//A player may claim a discarded tile from any other player to declare Mahjong.
//In case several players want to claim the same discard, the following priority list is used:
//Mahjong
//Kong
//Pong
//Chow
//If two players want to claim a tile for the same reason, the player who is closest to being next in turn gets the tile.
//Note that it is not always wise to claim discarded tiles. For example, sets that have not been declared are worth more than declared sets when going Mahjong.
//Mahjong Hands
//A Mahjong hand normally consists of four sets of three or four tiles and one pair. A set is a same-suit triplet (pong), a same-suit quadruplet (kong) or a same-suit straight (chow). Each rule set also has a number of special hands that allow Mahjong or score better than usual. Also, many rule sets have additional requirements for actually going Mahjong.

#include<iostream>
#include<vector>
#include<string>
#include<algorithm>
#include<time.h>
#include"Game.h"
#include"Deck.h"
#include"Player.h"
#include"BotPlayer.h"
#include"Combo3Set.h"
#include"KongSet.h"
#include"Tail.h"
#include"TailOnTable.h"

using namespace std;

//Singlton Global variables
Game *g_game = Game::GetGame();

int main()
{
	////seed Random for some botplayer action
	//srand(unsigned(time(nullptr)));

	//INITIALIZE GAME, CREATE TAILS, SHUFFLE, DRAW AND INITIALIZE TABLE
	g_game->InitializingGame();
	g_game->m_deck.Draw(g_game->m_pPlayer, front);

	do
	{
		system("cls");
		
		//print table
		g_game->AssignPlayerHandOnTable();
		g_game->PrintTable();
		
		//assign original tails from deck
		g_game->m_deck.Draw(g_game->m_pPlayer, front);
		
		//sort everyone's hand
		for (int i = 0; i < 4; ++i)
		{
			g_game->m_pPlayer[i]->SortTails();
		}
		
		//show player hand
		g_game->m_pPlayer[0]->ShowPlayerDeck();
		
		//player check if Mahjong and discard a tail if not
		g_game->GetActivePlayer()->EventController(g_game->GetDiscardTail(), g_game->GetActivePlayer());
		
		//if can MahJong after draw tile, call MahJong
		if (g_game->GetActivePlayer()->GetCurrentEventCalled() == MahJong)
		{
			g_game->GetActivePlayer()->EventExecutor(g_game->GetDiscardTail(), 3);
		}

		// set the discard tail on table
		g_game->SetAndAssignDiscardTail((g_game->GetActivePlayer()->Discard()));
		system("Pause");

		do
		{
			//Reset player events
			g_game->ResetPlayerEvents();

			// print new table
			system("cls");
			g_game->AssignPlayerHandOnTable();
			g_game->PrintTable();
			g_game->m_pPlayer[0]->ShowPlayerDeck();

			// check opponents' events regarding to the current discard tail
			for (int i = 0; i < 4; ++i)
			{
				int currentP = g_game->GetActivePlayer()->GetPlayerNumber();

				if (g_game->m_pPlayer[i]->GetPlayerNumber() == currentP)
				{
					continue;
				}
				else
				{
					g_game->m_pPlayer[i]->EventController(g_game->GetDiscardTail(), g_game->GetActivePlayer());
				}
			}

			// compare each player's event priority and determine the new active player
			g_game->ComparePlayerEventsCall();

			// call event executor, and the player with highest event priority will execute the event
			for (int i = 0; i < 4; ++i)
			{
				//execute Kong
				if (g_game->m_pPlayer[i]->GetCurrentEventCalled() == Kong)
				{
					g_game->GetActivePlayer()->SetPlayerState(Inactive);
					g_game->m_pPlayer[i]->SetPlayerState(Active);
					g_game->m_pPlayer[i]->EventExecutor(g_game->GetDiscardTail(), 0);
					g_game->ClearClaimedDiscardTail();
					g_game->m_deck.Draw(g_game->m_pPlayer, back);
					g_game->SetAndAssignDiscardTail((g_game->GetActivePlayer()->Discard()));
					system("pause");
					break;
				}
				//execute Pong
				else if (g_game->m_pPlayer[i]->GetCurrentEventCalled() == Pong)
				{
					g_game->GetActivePlayer()->SetPlayerState(Inactive);
					g_game->m_pPlayer[i]->SetPlayerState(Active);
					g_game->m_pPlayer[i]->EventExecutor(g_game->GetDiscardTail(), 1);
					g_game->ClearClaimedDiscardTail();
					g_game->SetAndAssignDiscardTail((g_game->GetActivePlayer()->Discard()));
					system("pause");
					break;
				}
				//execute Chow
				else if (g_game->m_pPlayer[i]->GetCurrentEventCalled() == Chow)
				{
					g_game->GetActivePlayer()->SetPlayerState(Inactive);
					g_game->m_pPlayer[i]->SetPlayerState(Active);
					g_game->m_pPlayer[i]->EventExecutor(g_game->GetDiscardTail(), 2);
					g_game->ClearClaimedDiscardTail();
					g_game->SetAndAssignDiscardTail((g_game->GetActivePlayer()->Discard()));
					system("pause");
					break;
				}
				//execute MahJong
				else if (g_game->m_pPlayer[i]->GetCurrentEventCalled() == MahJong)
				{
					g_game->GetActivePlayer()->SetPlayerState(Inactive);
					g_game->m_pPlayer[i]->SetPlayerState(Active);
					g_game->m_pPlayer[i]->EventExecutor(g_game->GetDiscardTail(), 3);				
					system("pause");
					return 0;
				}
			}

		// while no body execute any events, break loop
		} while (g_game->GetActivePlayer()->GetCurrentEventCalled() != None);

		//change player
		g_game->PlayerChange();
	
	// check if there appears a winner, if yes, break the loop;
	} while (!g_game->CheckWinner());

	system("pause");
	return 0;
}
