#include "KongSet.h"



KongSet::KongSet(Tail t1, Tail t2, Tail t3, Tail t4)
{
	m_tail1 = t1;
	m_tail2 = t2;
	m_tail3 = t3;
	m_tail4 = t4;
}


KongSet::~KongSet()
{
}
