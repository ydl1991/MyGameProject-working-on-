#include "BotPlayer.h"


BotPlayer::BotPlayer(int i)
{
	m_playerNumber = i;
	m_playerState = Inactive;
	m_PlayerTails = {};
	m_pDiscardTail = nullptr;
	m_n3TailCombo = 0;
	m_nPair = 0;
	m_nKong = 0;
	m_vKong = {};
	m_v3TailCombo = {};
	m_currentEventCalled = None;
}


BotPlayer::~BotPlayer()
{
}

Tail * BotPlayer::Discard()
{
	vector<Tail> temp;
	temp = m_PlayerTails;

	// check for same tails
	int i = 0;
	while (i < temp.size())
	{
		int index1 = -1;
		int index2 = -1;
		int index3 = -1;

		// loop to check only tails in hand
		int sameTailFound = 0;
		for (int j = i + 1; j < temp.size(); ++j)
		{
			if (temp[i] == temp[j])
			{
				++sameTailFound;
				if (index1 == -1)
				{
					index1 = j;
				}
				else if (index1 != -1 && index2 == -1)
				{
					index2 = j;
				}
				else if (index1 != -1 && index2 != -1 && index3 == -1)
				{
					index3 = j;
				}
			}
		}
		//Kong in hands
		if (sameTailFound == 3)
		{
			temp.erase(temp.begin() + index3);
			temp.erase(temp.begin() + index2);
			temp.erase(temp.begin() + index1);
			temp.erase(temp.begin() + i);
			i = 0;
		}
		//Pong in hands
		else if (sameTailFound == 2)
		{
			temp.erase(temp.begin() + index2);
			temp.erase(temp.begin() + index1);
			temp.erase(temp.begin() + i);
			i = 0;
		}
		// Pair in hands
		else if (sameTailFound == 1)
		{
			temp.erase(temp.begin() + index1);
			temp.erase(temp.begin() + i);
			i = 0;
		}
		else
			++i;
	}

	//check for straight
	int z = 0;
	while (temp.size() >= 3 && z < temp.size() - 2)
	{
		if (temp[z].GetSuit() == temp[z + 1].GetSuit() && temp[z].GetSuit() == temp[z + 2].GetSuit())
		{
			if (temp[z].GetRank() == (temp[z + 1].GetRank() - 1) && temp[z].GetRank() == (temp[z + 2].GetRank() - 2))
			{
				temp.erase(temp.begin() + z);
				temp.erase(temp.begin() + z);
				temp.erase(temp.begin() + z);
				z = 0;
			}
			else
				++z;
		}
		else
		{
			++z;
		}
	}

	// randomly select one of the single tail to discard
	int tailNumber = rand() % temp.size();
	m_pDiscardTail = new Tail(temp[tailNumber].GetRank(), temp[tailNumber].GetSuit());
	cout << "Player " << m_playerNumber << " chose to discard " << m_pDiscardTail->GetSuit() << m_pDiscardTail->GetRank() << endl << endl;
	int index;
	for (int i = 0; i < m_PlayerTails.size(); ++i)
	{
		if (m_PlayerTails[i] == *m_pDiscardTail)
		{
			index = i;
		}
	}
	// erase the single tail from hand
	m_PlayerTails.erase(m_PlayerTails.begin() + index);
	return m_pDiscardTail;
}

void BotPlayer::EventController(Tail * currentDiscardTail, Player *currentActivePlayer)
{
	//Declare mahjong bool
	bool canKong = false;
	bool canPong = false;
	bool canChow = false;
	bool canPair = false;
	bool canMahJong = false;

	//check hands
	//when check with a discarded tail
	if (currentDiscardTail->GetRank() > 0)
	{
		canKong = CheckKong(currentDiscardTail);
		canPong = CheckPong(currentDiscardTail);
		canChow = CheckChow(currentDiscardTail, currentActivePlayer);
		canPair = CheckPair(currentDiscardTail);
		canMahJong = CheckMahJongWithDiscardTail(currentDiscardTail, currentActivePlayer);
	}
	//when check after draw a tail
	else if (currentDiscardTail->GetRank() == 0)
		canMahJong = CheckMahJongWithDrawTail();

	if (!canKong && !canPong && !canChow && !canMahJong)
	{
		m_currentEventCalled = None;
		return;
	}

	//make choice by the event priority
	if (canMahJong)
	{
		m_currentEventCalled = MahJong;
		return;
	}
	else if (canKong)
	{
		m_currentEventCalled = Kong;
		return;
	}
	else if (canPong)
	{
		m_currentEventCalled = Pong;
		return;
	}
	else if (canChow)
	{
		m_currentEventCalled = Chow;
		return;
	}
}
