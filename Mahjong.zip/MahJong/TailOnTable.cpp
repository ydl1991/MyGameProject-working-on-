#include "TailOnTable.h"



TailOnTable::TailOnTable(Tail t)
{
	m_tail = t;
}


TailOnTable::~TailOnTable()
{
}
