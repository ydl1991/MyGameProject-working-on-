#include "Combo3Set.h"



Combo3Set::Combo3Set(Tail t1, Tail t2, Tail t3)
{
	m_tail1 = t1;
	m_tail2 = t2;
	m_tail3 = t3;
}


Combo3Set::~Combo3Set()
{
}
