#pragma once
#include "Player.h"
class BotPlayer :
	public Player
{
public:
	BotPlayer(int i);
	~BotPlayer();

	virtual Tail* Discard() override;
	virtual void EventController(Tail *currentDiscardTail, Player *currentActivePlayer) override;
};

