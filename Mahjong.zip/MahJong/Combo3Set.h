#pragma once
#include"Tail.h"
class Combo3Set
{
public:
	Combo3Set(Tail, Tail, Tail);
	~Combo3Set();

	Tail m_tail1;
	Tail m_tail2;
	Tail m_tail3;
};

