#include "Game.h"
#include <Windows.h>

using namespace std;


Game* Game::m_pGame = nullptr;

Game::Game()
	:m_pCurrentDiscardTail(new Tail(0,"Empty"))
	,m_pActivePlayer(nullptr)
	, m_pPlayer{}
	, m_pTable{}
{
}


Game::~Game()
{
}

//singlton to create game instance
Game * Game::GetGame()
{
	if (m_pGame == 0)
	{
		m_pGame = new Game();
	}
	return m_pGame;
}

//initialize everything
void Game::InitializingGame()
{
	//initialize tails and shuffle
	m_deck.CreateTails();
	m_deck.Shuffle();

	//initialize players
	this->m_pPlayer[0] = new Player(1);
	this->m_pPlayer[1] = new BotPlayer(2);
	this->m_pPlayer[2] = new BotPlayer(3);
	this->m_pPlayer[3] = new BotPlayer(4);

	// set controller for each players
	this->m_pPlayer[0]->SetController();
	this->m_pPlayer[1]->SetController();
	this->m_pPlayer[2]->SetController();
	this->m_pPlayer[3]->SetController();

	cout << "Generating play! Please wait ..." << endl << endl;
	Sleep(1500);

	//activate Player 0 who is the real player and the others are bot players
	m_pPlayer[0]->SetPlayerState(Active);
	m_pActivePlayer = GetActivePlayer();

	cout << "Player " << m_pActivePlayer->GetPlayerNumber() << " will go first!" << endl << endl;
	Sleep(1500);
}

// print the table
void Game::PrintTable()
{
	cout << "               Player 3              " << endl;
	for (int i = 0; i < 20; ++i)
	{
		if (i < 5 || i > 12)
		{
			cout << " ";
		}
		else if (i == 5)
			cout << "p";
		else if (i == 6)
			cout << "l";
		else if (i == 7)
			cout << "a";
		else if (i == 8)
			cout << "y";
		else if (i == 9)
			cout << "e";
		else if (i == 10)
			cout << "r";
		else if (i == 11)
			cout << " ";
		else if (i == 12)
			cout << "4";

		for (int j = 0; j < 20; ++j)
		{
			if (m_pTable[i][j])
			{
				m_pTable[i][j]->m_tail.Show();
			}
			else if (i == 3 && j >= 3 && j <= 15 || i == 15 && j >= 3 && j <= 15 )
			{
				cout << " +";
			}
			else if (j == 3 && i >= 3 && i <= 15 || j == 15 && i >= 3 && i <= 15)
			{
				cout << " +";
			}
			else
				cout << "  ";
		}

		if (i < 5 || i > 12)
		{
			cout << " ";
		}
		else if (i == 5)
			cout << "p";
		else if (i == 6)
			cout << "l";
		else if (i == 7)
			cout << "a";
		else if (i == 8)
			cout << "y";
		else if (i == 9)
			cout << "e";
		else if (i == 10)
			cout << "r";
		else if (i == 11)
			cout << " ";
		else if (i == 12)
			cout << "2";

		cout << endl;
	}
	cout << "               Player 1              " << endl;
}

//clear everything on table
void Game::ClearTable()
{
	for (int i = 0; i < 20; ++i)
	{
		for (int j = 0; j < 20; ++j)
		{
			m_pTable[i][j] = nullptr;
		}
	}
}

//switch player turns
void Game::PlayerChange()
{
	m_pPlayer[m_pActivePlayer->GetPlayerNumber() - 1]->SetPlayerState(Inactive);
	m_pActivePlayer = m_pPlayer[(m_pActivePlayer->GetPlayerNumber()) % 4];
	m_pPlayer[m_pActivePlayer->GetPlayerNumber() - 1]->SetPlayerState(Active);

	cout << "Player " << m_pActivePlayer->GetPlayerNumber() << "'s turn!" << endl << endl;

	//reset current Discard Tail
	m_pCurrentDiscardTail = new Tail(0, "Empty");
	system("pause");
}

// assign player's tiles on table
void Game::AssignPlayerHandOnTable()
{
	//clear row 2 row 17 and colume 2 colume 17
	for (int i = 0; i < 20; ++i)
	{
		for (int j = 2; j >= 0; --j)
		{
			m_pTable[i][j] = nullptr;
		}
		for (int j = 17; j < 20; ++j)
		{
			m_pTable[i][j] = nullptr;
		}
	}

	for (int j = 3; j < 17; ++j)
	{
		for (int i = 2; i >= 0; --i)
		{
			m_pTable[i][j] = nullptr;
		}
		for (int i = 17; i < 20; ++i)
		{
			m_pTable[i][j] = nullptr;
		}
	}

	// player 2 Kong and combo assign
	int row1 = 15;
	int i1 = 0;
	int j1 = 0;
	while (row1 >= 3)
	{
		if (m_pPlayer[1]->m_vKong.size() != 0)
		{
			for (i1 = 0; i1 < m_pPlayer[1]->m_vKong.size(); ++i1)
			{
				m_pTable[row1][18] = new TailOnTable(m_pPlayer[1]->m_vKong[i1].m_tail1);
				--row1;
				m_pTable[row1][18] = new TailOnTable(m_pPlayer[1]->m_vKong[i1].m_tail2);
				--row1;
				m_pTable[row1][18] = new TailOnTable(m_pPlayer[1]->m_vKong[i1].m_tail3);
				--row1;
				m_pTable[row1][18] = new TailOnTable(m_pPlayer[1]->m_vKong[i1].m_tail4);
				--row1;
			}
			break;
		}
		else if (m_pPlayer[1]->m_v3TailCombo.size() != 0)
		{
			for (j1 = 0; j1 < m_pPlayer[1]->m_v3TailCombo.size(); ++j1)
			{
				m_pTable[row1][18] = new TailOnTable(m_pPlayer[1]->m_v3TailCombo.at(j1).m_tail1);
				--row1;
				m_pTable[row1][18] = new TailOnTable(m_pPlayer[1]->m_v3TailCombo.at(j1).m_tail2);
				--row1;
				m_pTable[row1][18] = new TailOnTable(m_pPlayer[1]->m_v3TailCombo.at(j1).m_tail3);
				--row1;
			}
			break;
		}
		else
			break;
	}
	
	//player 4 kong and combo assign
	int row3 = 3;
	int i3 = 0;
	int j3 = 0;
	while (row3 < 16)
	{
		if (m_pPlayer[3]->m_vKong.size() != 0)
		{
			for (i3 = 0; i3 < m_pPlayer[3]->m_vKong.size(); ++i3)
			{
				m_pTable[row3][1] = new TailOnTable(m_pPlayer[3]->m_vKong[i3].m_tail1);
				++row3;
				m_pTable[row3][1] = new TailOnTable(m_pPlayer[3]->m_vKong[i3].m_tail2);
				++row3;
				m_pTable[row3][1] = new TailOnTable(m_pPlayer[3]->m_vKong[i3].m_tail3);
				++row3;
				m_pTable[row3][1] = new TailOnTable(m_pPlayer[3]->m_vKong[i3].m_tail4);
				++row3;
			}
			break;
		}
		else if (m_pPlayer[3]->m_v3TailCombo.size())
		{
			for (j3 = 0; j3 < m_pPlayer[3]->m_v3TailCombo.size(); ++j3)
			{
				m_pTable[row3][1] = new TailOnTable(m_pPlayer[3]->m_v3TailCombo.at(j3).m_tail1);
				++row3;
				m_pTable[row3][1] = new TailOnTable(m_pPlayer[3]->m_v3TailCombo.at(j3).m_tail2);
				++row3;
				m_pTable[row3][1] = new TailOnTable(m_pPlayer[3]->m_v3TailCombo.at(j3).m_tail3);
				++row3;
			}
			break;
		}
		else
			break;
	}
	
	//player 1 kong and combo assign
	int colume0 = 3;
	int i0 = 0;
	int j0 = 0;
	while (colume0 < 16)
	{
		if (m_pPlayer[0]->m_vKong.size() != 0)
		{
			for (i0 = 0; i0 < m_pPlayer[0]->m_vKong.size(); ++i0)
			{
				m_pTable[18][colume0] = new TailOnTable(m_pPlayer[0]->m_vKong[i0].m_tail1);
				++colume0;
				m_pTable[18][colume0] = new TailOnTable(m_pPlayer[0]->m_vKong[i0].m_tail2);
				++colume0;
				m_pTable[18][colume0] = new TailOnTable(m_pPlayer[0]->m_vKong[i0].m_tail3);
				++colume0;
				m_pTable[18][colume0] = new TailOnTable(m_pPlayer[0]->m_vKong[i0].m_tail4);
				++colume0;
			}
		}
		else if (m_pPlayer[0]->m_v3TailCombo.size() != 0)
		{
			for (j0 = 0; j0 < m_pPlayer[0]->m_v3TailCombo.size(); ++j0)
			{
				m_pTable[18][colume0] = new TailOnTable(m_pPlayer[0]->m_v3TailCombo.at(j0).m_tail1);
				++colume0;
				m_pTable[18][colume0] = new TailOnTable(m_pPlayer[0]->m_v3TailCombo.at(j0).m_tail2);
				++colume0;
				m_pTable[18][colume0] = new TailOnTable(m_pPlayer[0]->m_v3TailCombo.at(j0).m_tail3);
				++colume0;
			}
			break;
		}
		else
			break;
	}
	
	//player 3 kong and combo assign
	int colume2 = 15;
	int i2 = 0;
	int j2 = 0;
	while (colume2 >= 3)
	{
		if (m_pPlayer[2]->m_vKong.size() != 0)
		{
			for (i2 = 0; i2 < m_pPlayer[2]->m_vKong.size(); ++i2)
			{
				m_pTable[1][colume2] = new TailOnTable(m_pPlayer[2]->m_vKong[i2].m_tail1);
				--colume2;
				m_pTable[1][colume2] = new TailOnTable(m_pPlayer[2]->m_vKong[i2].m_tail2);
				--colume2;
				m_pTable[1][colume2] = new TailOnTable(m_pPlayer[2]->m_vKong[i2].m_tail3);
				--colume2;
				m_pTable[1][colume2] = new TailOnTable(m_pPlayer[2]->m_vKong[i2].m_tail4);
				--colume2;
			}
			break;
		}
		else if (m_pPlayer[2]->m_v3TailCombo.size() != 0)
		{
			for (j2 = 0; j2 < m_pPlayer[2]->m_v3TailCombo.size(); ++j2)
			{
				m_pTable[1][colume2] = new TailOnTable(m_pPlayer[2]->m_v3TailCombo.at(j2).m_tail1);
				--colume2;
				m_pTable[1][colume2] = new TailOnTable(m_pPlayer[2]->m_v3TailCombo.at(j2).m_tail2);
				--colume2;
				m_pTable[1][colume2] = new TailOnTable(m_pPlayer[2]->m_v3TailCombo.at(j2).m_tail3);
				--colume2;
			}
			break;
		}
		else
			break;
	}

	// row 18 colume 3-16 is the place for player 1's hand, 
	for (int j = 15; j > 15 - m_pPlayer[0]->GetPlayerHands().size(); --j)
	{
		m_pTable[18][j] = new TailOnTable(m_pPlayer[0]->RetrievePlayerDeckByIndex(15 - j));
	}
	//row 1 colume 3 - 16 is for player 3's hand
	for (int j = 3; j < m_pPlayer[2]->GetPlayerHands().size() + 3; ++j)
	{
		m_pTable[1][j] = new TailOnTable(m_pPlayer[2]->RetrievePlayerDeckByIndex(j - 3));
	}
	// row 3-16 colume 18 is the place for player 2's hand
	for (int i = 3; i < m_pPlayer[1]->GetPlayerHands().size() + 3; ++i)
	{
		m_pTable[i][18] = new TailOnTable(m_pPlayer[1]->RetrievePlayerDeckByIndex(i - 3));
	}
	// row 3-16 colume 1 is for player 4's hand
	for (int i = 15; i > 15 - m_pPlayer[3]->GetPlayerHands().size(); --i)
	{
		m_pTable[i][1] = new TailOnTable(m_pPlayer[3]->RetrievePlayerDeckByIndex(15 - i));
	}
}

// compare each player's event priority and determine the new active player
void Game::ComparePlayerEventsCall()
{
	// if player 1 has highest priority, if yes, player 1 becomes the new active player
	if (m_pPlayer[0]->GetCurrentEventCalled() > m_pPlayer[1]->GetCurrentEventCalled() && m_pPlayer[0]->GetCurrentEventCalled() > m_pPlayer[2]->GetCurrentEventCalled() && m_pPlayer[0]->GetCurrentEventCalled() > m_pPlayer[3]->GetCurrentEventCalled())
	{
		m_pPlayer[1]->SetCurrentEventCalled(None);
		m_pPlayer[2]->SetCurrentEventCalled(None);
		m_pPlayer[3]->SetCurrentEventCalled(None);
	}
	// if player 2 has highest priority, if yes, player 2 becomes the new active player
	else if (m_pPlayer[1]->GetCurrentEventCalled() > m_pPlayer[0]->GetCurrentEventCalled() && m_pPlayer[1]->GetCurrentEventCalled() > m_pPlayer[2]->GetCurrentEventCalled() && m_pPlayer[1]->GetCurrentEventCalled() > m_pPlayer[3]->GetCurrentEventCalled())
	{
		m_pPlayer[0]->SetCurrentEventCalled(None);
		m_pPlayer[2]->SetCurrentEventCalled(None);
		m_pPlayer[3]->SetCurrentEventCalled(None);
	}
	// if player 3 has highest priority, if yes, player 3 becomes the new active player
	else if (m_pPlayer[2]->GetCurrentEventCalled() > m_pPlayer[0]->GetCurrentEventCalled() && m_pPlayer[2]->GetCurrentEventCalled() > m_pPlayer[1]->GetCurrentEventCalled() && m_pPlayer[2]->GetCurrentEventCalled() > m_pPlayer[3]->GetCurrentEventCalled())
	{
		m_pPlayer[0]->SetCurrentEventCalled(None);
		m_pPlayer[1]->SetCurrentEventCalled(None);
		m_pPlayer[3]->SetCurrentEventCalled(None);
	}
	// if player 4 has highest priority, if yes, player 4 becomes the new active player
	else if (m_pPlayer[3]->GetCurrentEventCalled() > m_pPlayer[0]->GetCurrentEventCalled() && m_pPlayer[3]->GetCurrentEventCalled() > m_pPlayer[1]->GetCurrentEventCalled() && m_pPlayer[3]->GetCurrentEventCalled() > m_pPlayer[2]->GetCurrentEventCalled())
	{
		m_pPlayer[0]->SetCurrentEventCalled(None);
		m_pPlayer[1]->SetCurrentEventCalled(None);
		m_pPlayer[2]->SetCurrentEventCalled(None);
	}
	//nobody chose any events
	else
	{
		m_pPlayer[0]->SetCurrentEventCalled(None);
		m_pPlayer[1]->SetCurrentEventCalled(None);
		m_pPlayer[2]->SetCurrentEventCalled(None);
		m_pPlayer[3]->SetCurrentEventCalled(None);
	}
}

//Get the current active player
Player* Game::GetActivePlayer()
{
	for (int i = 0; i < 4; ++i)
	{
		if (m_pPlayer[i]->GetPlayerState() == Active)
		{
			m_pActivePlayer = m_pPlayer[i];
			break;
		}
	}
	return m_pActivePlayer;
}

//check if there is a winner
bool Game::CheckWinner()
{
	for (int i = 0; i < 4; ++i)
	{
		if (m_pPlayer[i]->GetPlayerState() == Won)
		{
			return true;
		}
	}
	return false;
}

// reset player's events status back to None
void Game::ResetPlayerEvents()
{
	for (int i = 0; i < 4; ++i)
	{
		m_pPlayer[i]->SetCurrentEventCalled(None);
	}
}

//clear the discarded tile being claimed by players for event
void Game::ClearClaimedDiscardTail()
{
	for (int i = 4; i < 15; ++i)
	{
		for (int j = 4; j < 15; ++j)
		{
			//if the discarded tile is not the last one on the horonzontal row
			if (m_pTable[i][j] == nullptr && j != 4)
			{
				m_pTable[i][j - 1] = nullptr;
				return;
			}
			//if the discarded tile is the last one on the horonzontal row
			else if (m_pTable[i][j] == nullptr && j == 4)
			{
				m_pTable[i - 1][14] = nullptr;
				return;
			}
		}
	}
}

// getter of discarded tail
Tail* Game::GetDiscardTail()
{
	return m_pCurrentDiscardTail;
}

// set discard tail and assign it to the discard area on table
void Game::SetAndAssignDiscardTail(Tail* t)
{
	if (t->GetRank() != 0)
	{
		m_pCurrentDiscardTail = t;
		for (int i = 4; i < 15; ++i)
		{
			for (int j = 4; j < 15; ++j)
			{
				if (!m_pTable[i][j])
				{
					m_pTable[i][j] = new TailOnTable(*m_pCurrentDiscardTail);
					m_pTable[i][j]->m_tail.SetTailState(FaceUp);
					return;
				}
			}
		}
	}
}
