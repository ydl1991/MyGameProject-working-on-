#include "Player.h"
#include <vector>
#include <algorithm>
#include <conio.h>
#include <Windows.h>

Player::Player()
{
}

Player::Player(int i)
	: m_playerState(Inactive)
	, m_PlayerTails{}
	, m_pDiscardTail(nullptr)
	, m_n3TailCombo(0)
	, m_nPair(0)
	, m_nKong(0)
	, m_playerNumber(i)
	, m_vKong{}
	, m_v3TailCombo{}
	, m_currentEventCalled(None)
{
}

Player::~Player()
{
}

// show player's activation status
PlayerState Player::GetPlayerState()
{
	return this->m_playerState;
}

vector<Tail> Player::GetPlayerHands()
{
	return m_PlayerTails;
}

int Player::GetPlayerNumber()
{
	return m_playerNumber;
}

//show player's hands
void Player::ShowPlayerDeck()
{
	cout << "Tails on hand:" << endl;
	for (int i = 0; i < this->m_PlayerTails.size(); ++i)
	{
		cout << i + 1 << ".";
		cout << m_PlayerTails[i].GetSuit() << m_PlayerTails[i].GetRank();
		cout << " ";
	}
	cout << endl << endl;
}

//function to show each tail
Tail Player::RetrievePlayerDeckByIndex(int i)
{
	return m_PlayerTails[i];
}

EventsName Player::GetCurrentEventCalled()
{
	return m_currentEventCalled;
}

//sort player hands by suit and rank
void Player::SortTails()
{
	//create vectors for different suits
	vector<Tail> Bamboo;
	vector<Tail> Charactor;
	vector<Tail> Dot;

	//sort by primary and secondary keys
	for (int i = 0; i < this->m_PlayerTails.size(); ++i)
	{
		//sort ranks
		for (int j = i + 1; j < this->m_PlayerTails.size(); ++j)
		{
			if (this->m_PlayerTails[j].GetRank() < this->m_PlayerTails[i].GetRank())
			{
				Tail temp = this->m_PlayerTails[i];
				this->m_PlayerTails[i] = this->m_PlayerTails[j];
				this->m_PlayerTails[j] = temp;
			}
		}
		//sort suits
		if (m_PlayerTails[i].GetSuit() == "B")
		{
			Bamboo.push_back(m_PlayerTails[i]);
		}
		else if (m_PlayerTails[i].GetSuit() == "C")
		{
			Charactor.push_back(m_PlayerTails[i]);
		}
		else
			Dot.push_back(m_PlayerTails[i]);
	}

	//clear out the vector
	m_PlayerTails.clear();
	//rebuild the vector
	m_PlayerTails.reserve(Bamboo.size() + Charactor.size() + Dot.size());
	m_PlayerTails.insert(m_PlayerTails.end(), Bamboo.begin(), Bamboo.end());
	m_PlayerTails.insert(m_PlayerTails.end(), Charactor.begin(), Charactor.end());
	m_PlayerTails.insert(m_PlayerTails.end(), Dot.begin(), Dot.end());
}

// draw a tail from deck and save in the player hand
void Player::DrawTail(Tail &tail)
{
	this->m_PlayerTails.push_back(tail);
}

void Player::SetCurrentEventCalled(EventsName e)
{
	m_currentEventCalled = e;
}

//change player activation status
void Player::SetPlayerState(PlayerState state)
{
	this->m_playerState = state;
}

//claim a discarded tail by other players, all the discarded tails should be faced up and show to everyone.
void Player::Claim(Tail *currentDiscardTail)
{
	currentDiscardTail->SetTailState(FaceUp);
	m_PlayerTails.push_back(*currentDiscardTail);
}

//discard a tail to the table
Tail* Player::Discard()
{
	cout << "Please discard a tile!" << endl;
	do
	{
		string i;
		int j;

		cout << "Enter Suit: ";
		cin >> i;
		cout << "Enter Rank: ";
		cin >> j;
		cout << endl;

		for (int z = 0; z < m_PlayerTails.size(); ++z)
		{
			if (i == m_PlayerTails[z].GetSuit() && j == m_PlayerTails[z].GetRank())
			{
				m_pDiscardTail = new Tail(j, i);
				cout << "You chose to discard " << m_pDiscardTail->GetSuit() << m_pDiscardTail->GetRank() << endl << endl;
				m_PlayerTails.erase(m_PlayerTails.begin() + z);
				return m_pDiscardTail;
			}
		}

		cout << "invalid choice!" << endl;

	} while (true);
}

//check hands if there are any 3 tails that can form 3-tail straight with the current discarded tail
bool Player::CheckChow(Tail *currentDiscardTail, Player *currentActivePlayer)
{
	if (currentActivePlayer->GetPlayerNumber() % 4 == (m_playerNumber -1))
	{
		Tail *left = nullptr;
		Tail *right = nullptr;
		Tail *lLeft = nullptr;
		Tail *rRight = nullptr;

		for (int i = 0; i < m_PlayerTails.size(); ++i)
		{
			if (m_PlayerTails[i].GetSuit() == currentDiscardTail->GetSuit())
			{
				//checking for tails that are 1 or 2 ranks smaller than current discard tail
				if (m_PlayerTails[i].GetRank() == (currentDiscardTail->GetRank() - 1))
				{
					left = &m_PlayerTails[i];
				}
				else if (m_PlayerTails[i].GetRank() == (currentDiscardTail->GetRank() - 2))
				{
					lLeft = &m_PlayerTails[i];
				}
				//checking for tails that are 1 or 2 ranks smaller than current discard tail
				else if (m_PlayerTails[i].GetRank() == (currentDiscardTail->GetRank() + 1))
				{
					right = &m_PlayerTails[i];
				}
				else if (m_PlayerTails[i].GetRank() == (currentDiscardTail->GetRank() + 2))
				{
					rRight = &m_PlayerTails[i];
				}
			}
		}
		//check for 3-tail combo
		if ((left && right) || (left && lLeft) || (right && rRight))
		{
			return true;
		}
		else
			return false;
	}
	else
		return false;
}

//check hands if can form a 3-tail clone (Pong) with current discard tail
bool Player::CheckPong(Tail *currentDiscardTail)
{
		int count = 0;
		for (int i = 0; i < m_PlayerTails.size(); ++i)
		{
			if (m_PlayerTails[i] == *currentDiscardTail)
			{
				++count;
			}
		}
		if (count == 2)
		{
			return true;
		}
		else
			return false;
}

//check hands if can form a 4-tail clone (Kong) with current discard tail
bool Player::CheckKong(Tail *currentDiscardTail)
{
		int count = 0;
		for (int i = 0; i < m_PlayerTails.size(); ++i)
		{
			if (m_PlayerTails[i] == *currentDiscardTail)
			{
				++count;
			}
		}
		if (count == 3)
		{
			return true;
		}
		else
			return false;
}

// check pairs
bool Player::CheckPair(Tail *currentDiscardTail)
{
	//local variables
	vector<Tail> temp;
	temp = m_PlayerTails;

	// check for same tails
	int i = 0;
	while (i < temp.size())
	{
		int index1 = -1;
		int index2 = -1;
		int index3 = -1;

		// loop to check only tails in hand
		int sameTailFound = 0;
		for (int j = i + 1; j < temp.size(); ++j)
		{
			if (temp[i] == temp[j])
			{
				++sameTailFound;
				if (index1 == -1)
				{
						index1 = j;
				}
				else if (index1 != -1 && index2 == -1)
				{
					index2 = j;
				}
				else if (index1 != -1 && index2 != -1 && index3 == -1)
				{
					index3 = j;
				}
			}
		}
		//Kong in hands
		if (sameTailFound == 3)
		{
			temp.erase(temp.begin() + index3);
			temp.erase(temp.begin() + index2);
			temp.erase(temp.begin() + index1);
			temp.erase(temp.begin() + i);
			i = 0;
		}
		//Pong in hands
		else if (sameTailFound == 2)
		{
			temp.erase(temp.begin() + index2);
			temp.erase(temp.begin() + index1);
			temp.erase(temp.begin() + i);
			i = 0;
		}
		// Pair in hands
		else if (sameTailFound == 1)
		{
			temp.erase(temp.begin() + index1);
			temp.erase(temp.begin() + i);
			i = 0;
		}
		else
			++i;
	}

	//check for straight
	int z = 0;
	while (temp.size() >= 3 && z < temp.size() - 2)
	{
		if (temp[z].GetSuit() == temp[z + 1].GetSuit() && temp[z].GetSuit() == temp[z + 2].GetSuit())
		{
			if (temp[z].GetRank() == (temp[z + 1].GetRank() - 1) && temp[z].GetRank() == (temp[z + 2].GetRank() - 2))
			{
				temp.erase(temp.begin() + z);
				temp.erase(temp.begin() + z);
				temp.erase(temp.begin() + z);
				z = 0;
			}
			else
				++z;
		}
		else
		{
			++z;
		}
	}

	// check if rest of the tails in hands can pair with discarded tail
	for (int i = 0; i < temp.size(); ++i)
	{
		// check hands with the current discard tail
		if (temp[i] == *currentDiscardTail)
		{
			return true;
		}
	}
	
	return false;
}

void Player::CountHand()
{
	vector<Tail> temp;
	temp = m_PlayerTails;

	// check for same tails
	int i = 0;
	while (i < temp.size())
	{
		int index1 = -1;
		int index2 = -1;
		int index3 = -1;

		// loop to check only tails in hand
		int sameTailFound = 0;
		for (int j = i + 1; j < temp.size(); ++j)
		{
			if (temp[i] == temp[j])
			{
				++sameTailFound;
				if (index1 == -1)
				{
					index1 = j;
				}
				else if (index1 != -1 && index2 == -1)
				{
					index2 = j;
				}
				else if (index1 != -1 && index2 != -1 && index3 == -1)
				{
					index3 = j;
				}
			}
		}
		//Kong in hands
		if (sameTailFound == 3)
		{
			++m_nKong;
			temp.erase(temp.begin() + index3);
			temp.erase(temp.begin() + index2);
			temp.erase(temp.begin() + index1);
			temp.erase(temp.begin() + i);
			i = 0;
		}
		//Pong in hands
		else if (sameTailFound == 2)
		{
			++m_n3TailCombo;
			temp.erase(temp.begin() + index2);
			temp.erase(temp.begin() + index1);
			temp.erase(temp.begin() + i);
			i = 0;
		}
		// Pair in hands
		else if (sameTailFound == 1)
		{
			++m_nPair;
			temp.erase(temp.begin() + index1);
			temp.erase(temp.begin() + i);
			i = 0;
		}
		else
			++i;
	}

	//check for straight
	int z = 0;
	while ((z + 2) < temp.size())
	{
		if (temp[z].GetSuit() == temp[z + 1].GetSuit() && temp[z].GetSuit() == temp[z + 2].GetSuit())
		{
			if (temp[z].GetRank() == (temp[z + 1].GetRank() - 1) && temp[z].GetRank() == (temp[z + 2].GetRank() - 2))
			{
				++m_n3TailCombo;
				temp.erase(temp.begin() + z);
				temp.erase(temp.begin() + z);
				temp.erase(temp.begin() + z);
				z = 0;
			}
			else
				++z;
		}
		else
		{
			++z;
		}
	}
}

//check for win
bool Player::CheckMahJongWithDiscardTail(Tail *currentDiscardTail, Player *currentActivePlayer)
{
	// check existing sets
	size_t kongSet = m_vKong.size();
	size_t comboSet = m_v3TailCombo.size();
	CountHand();
	m_nKong += kongSet;
	m_n3TailCombo += comboSet;

	//check hands
	bool canKong = CheckKong(currentDiscardTail);
	bool canPong = CheckPong(currentDiscardTail);
	bool canChow = CheckChow(currentDiscardTail, currentActivePlayer);
	bool canPair = CheckPair(currentDiscardTail);

	// Special MahJong (Win) : 7 pairs, waiting for the last pair
	if (m_nPair == 6 && canPair)
	{
			return true;
	}
	// normal MahJong : 2 pair with 3 sets of 3-tail combo or Kong, waiting for the last pong
	else if (m_nPair == 2)
	{
		if (m_nKong == 3)
		{
			if (canPong)
			{
				return true;
			}
			else
			{
				m_n3TailCombo = 0;
				m_nKong = 0;
				m_nPair = 0;
				return false;
			}
		}
		else if (m_n3TailCombo == 3)
		{
			if (canPong)
			{
				return true;
			}
			else
			{
				m_n3TailCombo = 0;
				m_nKong = 0;
				m_nPair = 0;
				return false;
			}
		}
		else
		{
			m_n3TailCombo = 0;
			m_nKong = 0;
			m_nPair = 0;
			return false;
		}
	}
	// normal MahJong : 1 pair with 3 sets of 3-tail combo or Kong, waiting for the last chow
	else if (m_nPair == 1)
	{
		if (m_nKong == 3)
		{
			if (canChow)
			{
				return true;
			}
			else
			{
				m_n3TailCombo = 0;
				m_nKong = 0;
				m_nPair = 0;
				return false;
			}
		}
		else if (m_n3TailCombo == 3)
		{
			if (canChow)
			{
				return true;
			}
			else
			{
				m_n3TailCombo = 0;
				m_nKong = 0;
				m_nPair = 0;
				return false;
			}
		}
		else
		{
			m_n3TailCombo = 0;
			m_nKong = 0;
			m_nPair = 0;
			return false;
		}
	}
	// normal MahJong : 1 pair with 4 sets of 3-tail combo or Kong, waiting for the pair
	else if (m_nPair == 0)
	{
		if (m_nKong == 4)
		{
			if (canPair)
			{
				return true;
			}
			else
			{
				m_n3TailCombo = 0;
				m_nKong = 0;
				m_nPair = 0;
				return false;
			}
		}
		else if (m_n3TailCombo == 4)
		{
			if (canPair)
			{
				return true;
			}
			else
			{
				m_n3TailCombo = 0;
				m_nKong = 0;
				m_nPair = 0;
				return false;
			}
		}
		else
		{
			m_n3TailCombo = 0;
			m_nKong = 0;
			m_nPair = 0;
			return false;
		}
	}
	else
	{
		m_n3TailCombo = 0;
		m_nKong = 0;
		m_nPair = 0;
		return false;
	}
}

bool Player::CheckMahJongWithDrawTail()
{
	// check existing sets
	size_t kongSet = m_vKong.size();
	size_t comboSet = m_v3TailCombo.size();
	CountHand();
	m_nKong += kongSet;
	m_n3TailCombo += comboSet;

	// Special MahJong (Win) : 7 pairs, waiting for the last pair
	if (m_nPair == 7)
	{
		return true;
	}
	// normal MahJong : 1 pair with 4 sets of 3-tail combo or Kong, waiting for the last combo or Kong
	else if (m_nPair == 1)
	{
		if (m_nKong == size_t(4))
		{	
			return true;
		}
		else if (m_n3TailCombo == size_t(4))
		{
			return true;
		}
		else
		{
			m_n3TailCombo = 0;
			m_nKong = 0;
			m_nPair = 0;
			return false;
		}
	}
	else
	{
		m_n3TailCombo = 0;
		m_nKong = 0;
		m_nPair = 0;
		return false;
	}
}

// set what the controller can do
void Player::SetController()
{
	//declare the lambda ExecuteKong
	auto ExecuteKong = [this](vector<Tail> &playerHand, Tail *currentDiscardTail, vector<KongSet>& k, vector<Combo3Set>& c)
	{
		//declare, and index
		int index = 0;

		//claim the tail into player hand
		this->Claim(currentDiscardTail);

		//loop to find the start of the clone tial
		for (int j = 0; j < playerHand.size(); ++j)
		{
			if (playerHand[j] == *currentDiscardTail)
			{
				//change the tail to faceup and store in array
				playerHand[j].SetTailState(FaceUp);
				//push into vector
				k.emplace_back(KongSet(playerHand[j], playerHand[j], playerHand[j], playerHand[j]));
				index = j;
				break;
			}
		}
		//remove the 3 clons in hand and the last element claimed which is also a clone
		playerHand.erase(playerHand.begin() + index);
		playerHand.erase(playerHand.begin() + index);
		playerHand.erase(playerHand.begin() + index);
		playerHand.pop_back();
	};

	//declare the lambda Execute Pong
	auto ExecutePong = [this](vector<Tail> &playerHand, Tail *currentDiscardTail, vector<KongSet>& k, vector<Combo3Set>& c)
	{
		//declare and index
		int index = 0;

		//claim the tail into player hand
		this->Claim(currentDiscardTail);

		//loop to find clone tial
		for (int j = 0; j < playerHand.size(); ++j)
		{
			if (playerHand[j] == *currentDiscardTail)
			{
				//change the tail to faceup and store in array
				playerHand[j].SetTailState(FaceUp);
				//push into vector
				c.emplace_back(Combo3Set(playerHand[j], playerHand[j], playerHand[j]));
				index = j;
				break;
			}
		}
		//remove the 2 clons in hand and the last element claimed which is also a clone
		playerHand.erase(playerHand.begin() + index);
		playerHand.erase(playerHand.begin() + index);
		playerHand.pop_back();
	};

	//declare the lambda Execute Chow
	auto ExecuteChow = [this](vector<Tail> &playerHand, Tail *currentDiscardTail, vector<KongSet>& k, vector<Combo3Set>& c)
	{
		//declare and index
		int index = 0;

		//claim the tail into player hand
		this->Claim(currentDiscardTail);

		//pointers to store related tails
		Tail *left = nullptr;
		Tail *right = nullptr;
		Tail *lLeft = nullptr;
		Tail *rRight = nullptr;

		//search for the straight matches
		for (int i = 0; i < playerHand.size(); ++i)
		{
			if (m_PlayerTails[i].GetSuit() == currentDiscardTail->GetSuit())
			{
				//checking for tails that are 1 or 2 ranks smaller than current discard tail
				if (playerHand[i].GetRank() == (currentDiscardTail->GetRank() - 2))
				{
					lLeft = &playerHand[i];
				}
				else if (playerHand[i].GetRank() == (currentDiscardTail->GetRank() - 1))
				{
					left = &playerHand[i];
					index = i;
				}
				//checking for tails that are 1 or 2 ranks smaller than current discard tail
				else if (playerHand[i].GetRank() == (currentDiscardTail->GetRank() + 1))
				{
					right = &playerHand[i];
					index = i;
				}
				else if (playerHand[i].GetRank() == (currentDiscardTail->GetRank() + 2))
				{
					rRight = &playerHand[i];
				}
			}
		}
		//check for 3-tail combo
		//if it's L-X-R
		if (left && right)
		{
			left->SetTailState(FaceUp);
			right->SetTailState(FaceUp);

			//push into vector
			c.emplace_back(Combo3Set(*left, playerHand.back(), *right));

			//remove the 2 tails in hand and the last element, which can form a straight
			playerHand.erase(playerHand.begin() + index);
			playerHand.erase(playerHand.begin() + index - 1);
			playerHand.pop_back();
		}
		//if it's L-L-X
		else if (left && lLeft)
		{
			left->SetTailState(FaceUp);
			lLeft->SetTailState(FaceUp);

			//push into vector
			c.emplace_back(Combo3Set(*lLeft, *left, playerHand.back()));

			//remove the 2 tails in hand and the last element, which can form a straight
			playerHand.erase(playerHand.begin() + index);
			playerHand.erase(playerHand.begin() + index - 1);
			playerHand.pop_back();
		}
		// if it's X-R-R
		else if (right && rRight)
		{
			right->SetTailState(FaceUp);
			rRight->SetTailState(FaceUp);

			//push into vector
			c.emplace_back(Combo3Set(playerHand.back(), *right, *rRight));

			//remove the 2 tails in hand and the last element, which can form a straight
			playerHand.erase(playerHand.begin() + index);
			playerHand.erase(playerHand.begin() + index);
			playerHand.pop_back();
		}
	};

	//declare the lambda Execute MahJong
	auto ExecuteMahJong = [this](vector<Tail> &playerHand, Tail *currentDiscardTail, vector<KongSet>& k, vector<Combo3Set>& c)
	{
		if (currentDiscardTail->GetRank() > 0)
		{
			//claim the tail into player hand
			this->Claim(currentDiscardTail);

			//Changing status
			this->SetPlayerState(Won);

			//Winning Message
			cout << "Player " << this->GetPlayerNumber() << " is the WINNER!" << endl;
			cout << "Full hands:" << endl;

			//show all the Kong
			for (int i = 0; i < k.size(); ++i)
			{
				k[i].m_tail1.Show();
				k[i].m_tail2.Show();
				k[i].m_tail3.Show();
				k[i].m_tail4.Show();
				cout << " ";
			}
			//show all the combo set
			for (int i = 0; i < c.size(); ++i)
			{
				c[i].m_tail1.Show();
				c[i].m_tail2.Show();
				c[i].m_tail3.Show();
				cout << " ";
			}
			//show rest of the tails on hand
			for (int i = 0; i < playerHand.size(); ++i)
			{
				playerHand[i].SetTailState(FaceUp);
				playerHand[i].Show();
			}

			cout << endl << endl;
		}
		else if (currentDiscardTail->GetRank() == 0)
		{
			//Changing status
			this->SetPlayerState(Won);

			//Winning Message
			cout << "Player " << this->GetPlayerNumber() << " is the WINNER!" << endl;
			cout << "Full hands:" << endl;

			//show all the Kong
			for (int i = 0; i < k.size(); ++i)
			{
				k[i].m_tail1.Show();
				k[i].m_tail2.Show();
				k[i].m_tail3.Show();
				k[i].m_tail4.Show();
				cout << " ";
			}
			//show all the combo set
			for (int i = 0; i < c.size(); ++i)
			{
				c[i].m_tail1.Show();
				c[i].m_tail2.Show();
				c[i].m_tail3.Show();
				cout << " ";
			}
			//show rest of the tails on hand
			for (int i = 0; i < playerHand.size(); ++i)
			{
				playerHand[i].SetTailState(FaceUp);
				playerHand[i].Show();
			}

			cout << endl << endl;
		}
	};

	//declare events pairs for Kong, Pong, Chow and MahJong
	pair<EventsName, function<void(vector<Tail>&, Tail*, vector<KongSet>&, vector<Combo3Set>&)>> Kong(Kong, ExecuteKong);
	pair<EventsName, function<void(vector<Tail>&, Tail*, vector<KongSet>&, vector<Combo3Set>&)>> Pong(Pong, ExecutePong);
	pair<EventsName, function<void(vector<Tail>&, Tail*, vector<KongSet>&, vector<Combo3Set>&)>> Chow(Chow, ExecuteChow);
	pair<EventsName, function<void(vector<Tail>&, Tail*, vector<KongSet>&, vector<Combo3Set>&)>> MahJong(MahJong, ExecuteMahJong);

	//push it back to the events vector
	m_events.push_back(Kong);
	m_events.push_back(Pong);
	m_events.push_back(Chow);
	m_events.push_back(MahJong);
}

// a controll console for player to trigger events
void Player::EventController(Tail *currentDiscardTail, Player *currentActivePlayer)
{
	//Declare mahjong bool
	bool canKong = false;
	bool canPong = false;
	bool canChow = false;
	bool canPair = false;
	bool canMahJong = false;

	//check hands
	//when check with a discarded tail
	if (currentDiscardTail->GetRank() > 0)
	{
		canKong = CheckKong(currentDiscardTail);
		canPong = CheckPong(currentDiscardTail);
		canChow = CheckChow(currentDiscardTail, currentActivePlayer);
		canPair = CheckPair(currentDiscardTail);
		canMahJong = CheckMahJongWithDiscardTail(currentDiscardTail, currentActivePlayer);
	}
	//when check after draw a tail
	else if (currentDiscardTail->GetRank() == 0)
		canMahJong = CheckMahJongWithDrawTail();

	//form options menu
	if (!canKong && !canPong && !canChow && !canMahJong)
	{
		m_currentEventCalled = None;
		cout << "Cannot Trigger Any Events!" << endl<<endl;
		return;
	}

	if (canKong)
	{
		cout << "1. " << "Kong" << endl;
	}
	if (canPong)
	{
		cout << "2. " << "Pong" << endl;
	}
	if (canChow)
	{
		cout << "3. " << "Chow" << endl;
	}
	if (canMahJong)
	{
		cout << "4. " << "MahJong" << endl;
	}
	// command option for choosing to not trigger any events
	cout << "5. Skip" << endl;

	//get user choice and execute
	int c;
	do
	{	
		cout << "Please select a event: ";

		cin >> c;
		
		if (c == 1)
		{
			if (canKong)
			{
				m_currentEventCalled = Kong;
				break;
			}
			else
				cout << "Invalid Choice! Try again:" << endl;
		}
		else if (c == 2)
		{
			if (canPong)
			{
				m_currentEventCalled = Pong;
				break;
			}
			else
				cout << "Invalid Choice! Try again:" << endl;
		}
		else if (c == 3)
		{
			if (canChow)
			{
				m_currentEventCalled = Chow;
				break;
			}
			else
				cout << "Invalid Choice! Try again:" << endl;
		}
		else if (c == 4)
		{
			if (canMahJong)
			{
				m_currentEventCalled = MahJong;
				break;
			}
			else
				cout << "Invalid Choice! Try again:" << endl;
		}
		else if (c == 5)
		{
			break;

		}
		else
			cout << "Invalid input! Try again:" << endl;
		
	} while (true);
}

void Player::EventExecutor(Tail * currentDiscardTail, int i)
{
	// Event statement after triggerring
	switch (i)
	{
		case 0:
		cout << "Player " << this->GetPlayerNumber() << " Kong!" << endl;
		break;
		case 1:
		cout << "Player " << this->GetPlayerNumber() << " Pong!" << endl;
		break;
		case 2:
		cout << "Player " << this->GetPlayerNumber() << " Chow!" << endl;
		break;
	}
	
	//execute the events
	m_events[i].second(m_PlayerTails, currentDiscardTail, m_vKong, m_v3TailCombo);
}
