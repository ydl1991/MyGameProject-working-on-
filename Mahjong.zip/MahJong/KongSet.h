#pragma once
#include"Tail.h"
class KongSet
{
public:
	KongSet(Tail, Tail, Tail, Tail);
	~KongSet();

	Tail m_tail1;
	Tail m_tail2;
	Tail m_tail3;
	Tail m_tail4;
};

